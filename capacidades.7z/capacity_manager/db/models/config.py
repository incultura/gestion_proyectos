"""
db/models/config.py — CRUD para parámetros de configuración.
"""
from db.database import get_connection

def get_config(key: str, default: str = "") -> str:
    conn = get_connection()
    try:
        row = conn.execute("SELECT value FROM config WHERE key = ?", (key,)).fetchone()
        return row["value"] if row else default
    finally:
        conn.close()

def set_config(key: str, value: str):
    conn = get_connection()
    try:
        conn.execute("INSERT OR REPLACE INTO config (key, value) VALUES (?, ?)", (key, value))
        conn.commit()
    finally:
        conn.close()

def get_all_configs() -> list:
    conn = get_connection()
    try:
        rows = conn.execute("SELECT key, value FROM config ORDER BY key").fetchall()
        return [dict(row) for row in rows]
    finally:
        conn.close()

def delete_config(key: str):
    conn = get_connection()
    try:
        conn.execute("DELETE FROM config WHERE key = ?", (key,))
        conn.commit()
    finally:
        conn.close()
