"""
db/models/capacity_snapshots.py — CRUD para snapshots de planificación mensual.

Almacena la "foto" de horas planificadas por proyecto/equipo/mes
para preservar la planificación histórica ante cambios de fechas.
"""
from db.database import get_connection


def has_snapshot(year: int, month: int, team_id: int) -> bool:
    """Verifica si ya existe snapshot para un equipo en un mes."""
    conn = get_connection()
    try:
        row = conn.execute(
            "SELECT COUNT(*) as cnt FROM capacity_snapshots WHERE year = ? AND month = ? AND team_id = ?",
            (year, month, team_id)
        ).fetchone()
        return row["cnt"] > 0
    finally:
        conn.close()


def save_snapshots(year: int, month: int, snapshots_list: list):
    """
    Guarda batch de snapshots. Cada item: {team_id, project_id, planned_hours, typology}.
    Usa INSERT OR IGNORE para no sobreescribir snapshots existentes.
    """
    conn = get_connection()
    try:
        conn.executemany("""
            INSERT OR IGNORE INTO capacity_snapshots
                (year, month, team_id, project_id, planned_hours, typology)
            VALUES
                (:year, :month, :team_id, :project_id, :planned_hours, :typology)
        """, [
            {**s, "year": year, "month": month}
            for s in snapshots_list
        ])
        conn.commit()
    finally:
        conn.close()


def get_snapshots_for_team_month(team_id: int, year: int, month: int) -> list:
    """Devuelve los snapshots de un equipo para un mes."""
    conn = get_connection()
    try:
        rows = conn.execute("""
            SELECT * FROM capacity_snapshots
            WHERE team_id = ? AND year = ? AND month = ?
        """, (team_id, year, month)).fetchall()
        return [dict(r) for r in rows]
    finally:
        conn.close()


def get_team_month_planned(team_id: int, year: int, month: int) -> dict:
    """
    Devuelve las horas planificadas de un equipo en un mes, desglosadas por tipología.
    Returns: {ops_hours, non_ops_hours, total_hours}
    """
    snapshots = get_snapshots_for_team_month(team_id, year, month)
    ops = 0.0
    non_ops = 0.0
    for s in snapshots:
        if (s["typology"] or "").lower() == "operacion":
            ops += s["planned_hours"]
        else:
            non_ops += s["planned_hours"]
    return {"ops_hours": ops, "non_ops_hours": non_ops, "total_hours": ops + non_ops}
