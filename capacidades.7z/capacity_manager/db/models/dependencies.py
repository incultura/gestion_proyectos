"""
models/dependencies.py — CRUD para dependencias y asociaciones con proyectos.
"""
from db.database import get_connection

def get_all_dependencies():
    conn = get_connection()
    try:
        rows = conn.execute("SELECT * FROM dependencies ORDER BY name").fetchall()
        return [dict(r) for r in rows]
    finally:
        conn.close()

def create_dependency(name: str) -> int:
    conn = get_connection()
    try:
        cur = conn.execute("INSERT INTO dependencies (name) VALUES (?)", (name,))
        new_id = cur.lastrowid
        conn.commit()
        return int(new_id) if new_id is not None else 0
    finally:
        conn.close()

def update_dependency(dep_id: int, name: str):
    conn = get_connection()
    try:
        conn.execute("UPDATE dependencies SET name = ? WHERE id = ?", (name, dep_id))
        conn.commit()
    finally:
        conn.close()

def delete_dependency(dep_id: int):
    conn = get_connection()
    try:
        conn.execute("DELETE FROM dependencies WHERE id = ?", (dep_id,))
        conn.commit()
    finally:
        conn.close()

# --- Relaciones con proyectos ---

def get_project_dependencies(project_id: int):
    conn = get_connection()
    try:
        rows = conn.execute("""
            SELECT d.* 
            FROM dependencies d
            JOIN project_dependencies pd ON d.id = pd.dependency_id
            WHERE pd.project_id = ?
            ORDER BY d.name
        """, (project_id,)).fetchall()
        return [dict(r) for r in rows]
    finally:
        conn.close()

def associate_project_dependency(project_id: int, dependency_id: int):
    conn = get_connection()
    try:
        conn.execute("""
            INSERT OR IGNORE INTO project_dependencies (project_id, dependency_id)
            VALUES (?, ?)
        """, (project_id, dependency_id))
        conn.commit()
    finally:
        conn.close()

def remove_project_dependency(project_id: int, dependency_id: int):
    conn = get_connection()
    try:
        conn.execute("""
            DELETE FROM project_dependencies 
            WHERE project_id = ? AND dependency_id = ?
        """, (project_id, dependency_id))
        conn.commit()
    finally:
        conn.close()
