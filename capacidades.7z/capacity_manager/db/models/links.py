import sqlite3
from db.database import get_connection

def create_link(title, url):
    conn = get_connection()
    try:
        cur = conn.execute(
            "INSERT INTO links (title, url) VALUES (?, ?)",
            (title, url)
        )
        conn.commit()
        return cur.lastrowid
    finally:
        conn.close()

def get_all_links():
    conn = get_connection()
    try:
        rows = conn.execute("SELECT * FROM links ORDER BY created_date DESC").fetchall()
        return [dict(r) for r in rows]
    finally:
        conn.close()

def search_links(query):
    """Búsqueda solo por título en los enlaces, como solicitó el usuario."""
    conn = get_connection()
    try:
        search_term = f"%{query}%"
        rows = conn.execute(
            "SELECT * FROM links WHERE title LIKE ? ORDER BY created_date DESC",
            (search_term,)
        ).fetchall()
        return [dict(r) for r in rows]
    finally:
        conn.close()

def update_link(link_id, title, url):
    conn = get_connection()
    try:
        conn.execute(
            "UPDATE links SET title = ?, url = ? WHERE id = ?",
            (title, url, link_id)
        )
        conn.commit()
    finally:
        conn.close()

def delete_link(link_id):
    conn = get_connection()
    try:
        conn.execute("DELETE FROM links WHERE id = ?", (link_id,))
        conn.commit()
    finally:
        conn.close()
