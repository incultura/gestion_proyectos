"""
models/dedications.py — CRUD para dedicaciones de equipos a proyectos.
"""
from db.database import get_connection

def get_dedications_by_project(project_id: int):
    conn = get_connection()
    try:
        rows = conn.execute("""
            SELECT d.*, t.name as team_name, s.name as status_name
            FROM dedications d
            JOIN teams t ON d.team_id = t.id
            LEFT JOIN statuses s ON d.status_id = s.id
            WHERE d.project_id = ?
            ORDER BY t.name
        """, (project_id,)).fetchall()
        return [dict(r) for r in rows]
    finally:
        conn.close()

def get_dedications_by_team(team_id: int):
    conn = get_connection()
    try:
        rows = conn.execute("""
            SELECT d.*, p.title as project_title, p.id_proyecto, sol.title as solicitud_title, 
                   sol.typology, t.name as team_name, s.name as status_name
            FROM dedications d
            JOIN projects p ON d.project_id = p.id
            JOIN solicitudes sol ON p.solicitud_id = sol.id
            JOIN teams t ON d.team_id = t.id
            LEFT JOIN statuses s ON d.status_id = s.id
            WHERE d.team_id = ?
            ORDER BY d.start_date
        """, (team_id,)).fetchall()
        return [dict(r) for r in rows]
    finally:
        conn.close()

def get_all_active_dedications():
    conn = get_connection()
    try:
        rows = conn.execute("""
            SELECT d.*, p.title as project_title, p.id_proyecto, sol.title as solicitud_title, 
                   sol.typology, t.name as team_name, s.name as status_name
            FROM dedications d
            JOIN projects p ON d.project_id = p.id
            JOIN solicitudes sol ON p.solicitud_id = sol.id
            JOIN teams t ON d.team_id = t.id
            LEFT JOIN statuses s ON d.status_id = s.id
            WHERE s.name NOT IN ('Finalizado', 'Descartado') OR s.name IS NULL
        """).fetchall()
        return [dict(r) for r in rows]
    finally:
        conn.close()

def get_dedication(dedication_id: int):
    conn = get_connection()
    try:
        row = conn.execute("""
            SELECT d.*, p.title as project_title, p.id_proyecto, p.entregable,
                   sol.id as solicitud_id, sol.title as solicitud_title, sol.typology, 
                   t.name as team_name, s.name as status_name
            FROM dedications d
            JOIN projects p ON d.project_id = p.id
            JOIN solicitudes sol ON p.solicitud_id = sol.id
            JOIN teams t ON d.team_id = t.id
            LEFT JOIN statuses s ON d.status_id = s.id
            WHERE d.id = ?
        """, (dedication_id,)).fetchone()
        return dict(row) if row else None
    finally:
        conn.close()

def create_dedication(data: dict) -> int:
    """data: {project_id, team_id, status_id, start_date, end_date, estimated_hours}"""
    conn = get_connection()
    try:
        cur = conn.execute("""
            INSERT INTO dedications
                (project_id, team_id, status_id, start_date, end_date, estimated_hours)
            VALUES
                (:project_id, :team_id, :status_id, :start_date, :end_date, :estimated_hours)
        """, data)
        new_id = cur.lastrowid
        conn.commit()
        return int(new_id) if new_id is not None else 0
    finally:
        conn.close()

def update_dedication(dedication_id: int, data: dict):
    conn = get_connection()
    try:
        conn.execute("""
            UPDATE dedications SET
                status_id       = :status_id,
                start_date      = :start_date,
                end_date        = :end_date,
                estimated_hours = :estimated_hours
            WHERE id = :id
        """, {**data, "id": dedication_id})
        conn.commit()
    finally:
        conn.close()

def delete_dedication(dedication_id: int):
    conn = get_connection()
    try:
        conn.execute("DELETE FROM dedications WHERE id = ?", (dedication_id,))
        conn.commit()
    finally:
        conn.close()

def get_imputed_hours(dedication_id: int) -> float:
    conn = get_connection()
    try:
        row = conn.execute(
            "SELECT COALESCE(SUM(hours), 0) as total FROM hours_log WHERE dedication_id = ?",
            (dedication_id,)
        ).fetchone()
        if row:
            return float(row["total"])
        return 0.0
    finally:
        conn.close()

def get_remaining_hours(dedication_id: int, estimated_hours: float) -> float:
    return max(0.0, estimated_hours - get_imputed_hours(dedication_id))
