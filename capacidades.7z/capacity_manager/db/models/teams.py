"""
models/teams.py — CRUD para la tabla teams.
Incluye recuento de personas y horas anuales agregadas.
"""
from db.database import get_connection


def get_all_teams():
    conn = get_connection()
    try:
        rows = conn.execute("SELECT * FROM teams ORDER BY name").fetchall()
        return [dict(r) for r in rows]
    finally:
        conn.close()


def get_team(team_id: int):
    conn = get_connection()
    try:
        row = conn.execute("SELECT * FROM teams WHERE id = ?", (team_id,)).fetchone()
        return dict(row) if row else None
    finally:
        conn.close()


def get_team_by_name(name: str):
    conn = get_connection()
    try:
        row = conn.execute("SELECT * FROM teams WHERE name = ?", (name,)).fetchone()
        return dict(row) if row else None
    finally:
        conn.close()


def create_team(data: dict) -> int:
    conn = get_connection()
    try:
        cur = conn.execute("""
            INSERT INTO teams
                (name, 
                 internal_people, internal_annual_hours, 
                 baseline_people, baseline_annual_hours,
                 reinforce_people, reinforce_annual_hours, 
                 ops_percentage)
            VALUES
                (:name, 
                 :internal_people, :internal_annual_hours, 
                 :baseline_people, :baseline_hours,
                 :reinforce_people, :reinforce_annual_hours, 
                 :ops_percentage)
        """, data)
        new_id = cur.lastrowid
        conn.commit()
        return new_id
    finally:
        conn.close()


def update_team(team_id: int, data: dict):
    conn = get_connection()
    try:
        conn.execute("""
            UPDATE teams SET
                name                   = :name,
                internal_people        = :internal_people,
                internal_annual_hours  = :internal_annual_hours,
                baseline_people        = :baseline_people,
                baseline_annual_hours  = :baseline_hours,
                reinforce_people       = :reinforce_people,
                reinforce_annual_hours = :reinforce_annual_hours,
                ops_percentage         = :ops_percentage
            WHERE id = :id
        """, {**data, "id": team_id})
        conn.commit()
    finally:
        conn.close()


def delete_team(team_id: int):
    conn = get_connection()
    try:
        conn.execute("DELETE FROM teams WHERE id = ?", (team_id,))
        conn.commit()
    finally:
        conn.close()


def team_total_annual_hours(team: dict) -> float:
    return (
        team.get("internal_annual_hours", 0)
        + team.get("baseline_annual_hours", 0)
        + team.get("reinforce_annual_hours", 0)
    )
