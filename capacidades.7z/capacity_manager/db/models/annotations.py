"""
models/annotations.py — CRUD para anotaciones de solicitudes (antes proyectos).
"""
from db.database import get_connection

def get_annotations_by_solicitud(solicitud_id: int):
    conn = get_connection()
    try:
        rows = conn.execute("""
            SELECT * FROM solicitud_annotations
            WHERE solicitud_id = ?
            ORDER BY annotation_number ASC
        """, (solicitud_id,)).fetchall()
        return [dict(r) for r in rows]
    finally:
        conn.close()

def create_annotation(solicitud_id: int, content: str, date_str: str) -> int:
    conn = get_connection()
    try:
        # Calcular el siguiente número de anotación para esta solicitud
        row = conn.execute("""
            SELECT COALESCE(MAX(annotation_number), 0) + 1 as next_num
            FROM solicitud_annotations
            WHERE solicitud_id = ?
        """, (solicitud_id,)).fetchone()
        next_num = row["next_num"]

        cur = conn.execute("""
            INSERT INTO solicitud_annotations (solicitud_id, annotation_number, date, content)
            VALUES (?, ?, ?, ?)
        """, (solicitud_id, next_num, date_str, content))
        new_id = cur.lastrowid
        conn.commit()
        return new_id
    finally:
        conn.close()

def delete_annotation(annotation_id: int):
    conn = get_connection()
    try:
        conn.execute("DELETE FROM solicitud_annotations WHERE id = ?", (annotation_id,))
        conn.commit()
    finally:
        conn.close()

def update_annotation(annotation_id: int, content: str):
    conn = get_connection()
    try:
        conn.execute("""
            UPDATE solicitud_annotations SET content = ? WHERE id = ?
        """, (content, annotation_id))
        conn.commit()
    finally:
        conn.close()
