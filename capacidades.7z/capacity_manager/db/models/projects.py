"""
models/projects.py — CRUD para Definiciones de Proyectos (v7).
"""
from db.database import get_connection

def get_projects_by_solicitud(solicitud_id: int):
    conn = get_connection()
    try:
        rows = conn.execute("""
            SELECT p.*
            FROM projects p
            WHERE p.solicitud_id = ?
            ORDER BY p.id_proyecto
        """, (solicitud_id,)).fetchall()
        return [dict(r) for r in rows]
    finally:
        conn.close()

def get_project(project_id: int):
    conn = get_connection()
    try:
        row = conn.execute("""
            SELECT p.*, sol.title as solicitud_title, sol.typology as solicitud_typology, sol.id_solicitud
            FROM projects p
            JOIN solicitudes sol ON p.solicitud_id = sol.id
            WHERE p.id = ?
        """, (project_id,)).fetchone()
        return dict(row) if row else None
    finally:
        conn.close()

def create_project(data: dict) -> int:
    """data: {solicitud_id, id_proyecto, title, description, entregable}"""
    conn = get_connection()
    try:
        cur = conn.execute("""
            INSERT INTO projects
                (solicitud_id, id_proyecto, title, description, entregable)
            VALUES
                (:solicitud_id, :id_proyecto, :title, :description, :entregable)
        """, data)
        new_id = cur.lastrowid
        conn.commit()
        return int(new_id) if new_id is not None else 0
    finally:
        conn.close()

def update_project(project_id: int, data: dict):
    conn = get_connection()
    try:
        conn.execute("""
            UPDATE projects SET
                id_proyecto = :id_proyecto,
                title       = :title,
                description = :description,
                entregable  = :entregable
            WHERE id = :id
        """, {**data, "id": project_id})
        conn.commit()
    finally:
        conn.close()

def delete_project(project_id: int):
    conn = get_connection()
    try:
        conn.execute("DELETE FROM projects WHERE id = ?", (project_id,))
        conn.commit()
    finally:
        conn.close()

def get_project_by_id_pry(solicitud_id: int, id_proyecto: int):
    conn = get_connection()
    try:
        row = conn.execute("""
            SELECT * FROM projects 
            WHERE solicitud_id = ? AND id_proyecto = ?
        """, (solicitud_id, id_proyecto)).fetchone()
        return dict(row) if row else None
    finally:
        conn.close()
