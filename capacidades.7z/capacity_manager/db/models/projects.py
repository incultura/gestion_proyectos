"""
models/projects.py — CRUD para proyectos.
"""
from db.database import get_connection

TYPOLOGIES = ["Operacion", "PIPE", "Regulatorio", "TTM"]


def get_all_projects():
    conn = get_connection()
    try:
        rows = conn.execute("""
            SELECT p.*, s.name as status_name
            FROM projects p
            LEFT JOIN statuses s ON p.status_id = s.id
            ORDER BY p.title
        """).fetchall()
        return [dict(r) for r in rows]
    finally:
        conn.close()


def get_project(project_id: int):
    conn = get_connection()
    try:
        row = conn.execute("""
            SELECT p.*, s.name as status_name
            FROM projects p
            LEFT JOIN statuses s ON p.status_id = s.id
            WHERE p.id = ?
        """, (project_id,)).fetchone()
        if row:
            return dict(row)
        return None
    finally:
        conn.close()


def create_project(data: dict) -> int:
    """data: {title, typology, description, request_link, status_id, start_date, end_date, detention_date, id_solicitud}"""
    conn = get_connection()
    try:
        cur = conn.execute("""
            INSERT INTO projects (title, typology, description, request_link, status_id, start_date, end_date, detention_date, id_solicitud)
            VALUES (:title, :typology, :description, :request_link, :status_id, :start_date, :end_date, :detention_date, :id_solicitud)
        """, data)
        new_id = cur.lastrowid
        conn.commit()
        return int(new_id) if new_id is not None else 0
    finally:
        conn.close()


def update_project(project_id: int, data: dict):
    conn = get_connection()
    try:
        conn.execute("""
            UPDATE projects SET
                title = :title,
                typology = :typology,
                description = :description,
                request_link = :request_link,
                status_id = :status_id,
                start_date = :start_date,
                end_date = :end_date,
                detention_date = :detention_date,
                id_solicitud = :id_solicitud
            WHERE id = :id
        """, {**data, "id": project_id})
        conn.commit()
    finally:
        conn.close()


def delete_project(project_id: int):
    conn = get_connection()
    try:
        conn.execute("DELETE FROM projects WHERE id = ?", (project_id,))
        conn.commit()
    finally:
        conn.close()
