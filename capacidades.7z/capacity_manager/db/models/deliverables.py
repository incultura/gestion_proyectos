"""
db/models/deliverables.py — CRUD para entregables de solicitud (antes proyecto).
"""
from db.database import get_connection

def get_deliverables_by_solicitud(solicitud_id: int):
    conn = get_connection()
    try:
        rows = conn.execute("SELECT * FROM solicitud_deliverables WHERE solicitud_id = ? ORDER BY name", (solicitud_id,)).fetchall()
        return [dict(r) for r in rows]
    finally:
        conn.close()

def add_deliverable(solicitud_id: int, name: str):
    conn = get_connection()
    try:
        conn.execute("INSERT INTO solicitud_deliverables (solicitud_id, name) VALUES (?, ?)", (solicitud_id, name))
        conn.commit()
    finally:
        conn.close()

def delete_deliverable(deliverable_id: int):
    conn = get_connection()
    try:
        conn.execute("DELETE FROM solicitud_deliverables WHERE id = ?", (deliverable_id,))
        conn.commit()
    finally:
        conn.close()
