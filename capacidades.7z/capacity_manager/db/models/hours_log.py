"""
models/hours_log.py — Registro de horas imputadas con fecha (v7).
"""
from db.database import get_connection

def get_logs_by_dedication(dedication_id: int):
    conn = get_connection()
    try:
        rows = conn.execute("""
            SELECT * FROM hours_log
            WHERE dedication_id = ?
            ORDER BY log_date DESC
        """, (dedication_id,)).fetchall()
        return [dict(r) for r in rows]
    finally:
        conn.close()

def add_log(data: dict) -> int:
    """data: {dedication_id, log_date, hours, comment}"""
    conn = get_connection()
    try:
        cur = conn.execute("""
            INSERT INTO hours_log (dedication_id, log_date, hours, comment)
            VALUES (:dedication_id, :log_date, :hours, :comment)
        """, data)
        new_id = cur.lastrowid
        conn.commit()
        return new_id
    finally:
        conn.close()

def update_log(log_id: int, log_date: str, hours: float, comment: str = ""):
    conn = get_connection()
    try:
        conn.execute("""
            UPDATE hours_log SET log_date = ?, hours = ?, comment = ? WHERE id = ?
        """, (log_date, hours, comment, log_id))
        conn.commit()
    finally:
        conn.close()

def delete_log(log_id: int):
    conn = get_connection()
    try:
        conn.execute("DELETE FROM hours_log WHERE id = ?", (log_id,))
        conn.commit()
    finally:
        conn.close()

def get_total_imputed(dedication_id: int) -> float:
    conn = get_connection()
    try:
        row = conn.execute(
            "SELECT COALESCE(SUM(hours), 0) as total FROM hours_log WHERE dedication_id = ?",
            (dedication_id,)
        ).fetchone()
        return row["total"] if row else 0.0
    finally:
        conn.close()

def get_total_solicitud_imputed(solicitud_id: int) -> float:
    conn = get_connection()
    try:
        row = conn.execute("""
            SELECT COALESCE(SUM(hl.hours), 0) as total 
            FROM hours_log hl
            JOIN dedications d ON hl.dedication_id = d.id
            JOIN projects p ON d.project_id = p.id
            WHERE p.solicitud_id = ?
        """, (solicitud_id,)).fetchone()
        return row["total"] if row else 0.0
    finally:
        conn.close()

def get_last_imputation_date(dedication_id: int) -> str:
    conn = get_connection()
    try:
        row = conn.execute(
            "SELECT MAX(log_date) as last_date FROM hours_log WHERE dedication_id = ?",
            (dedication_id,)
        ).fetchone()
        return row["last_date"] if row and row["last_date"] else "-"
    finally:
        conn.close()

def get_team_month_imputed(team_id: int, year: int, month: int) -> dict:
    import calendar
    _, last_day = calendar.monthrange(year, month)
    start_date = f"{year}-{month:02d}-01"
    end_date = f"{year}-{month:02d}-{last_day}"

    conn = get_connection()
    try:
        rows = conn.execute("""
            SELECT sol.typology, COALESCE(SUM(hl.hours), 0) as total
            FROM hours_log hl
            JOIN dedications d ON hl.dedication_id = d.id
            JOIN projects p ON d.project_id = p.id
            JOIN solicitudes sol ON p.solicitud_id = sol.id
            WHERE d.team_id = ?
              AND hl.log_date >= ? AND hl.log_date <= ?
            GROUP BY sol.typology
        """, (team_id, start_date, end_date)).fetchall()

        ops = 0.0
        non_ops = 0.0
        for r in rows:
            if (r["typology"] or "").lower() == "operacion":
                ops += r["total"]
            else:
                non_ops += r["total"]
        return {"ops_hours": ops, "non_ops_hours": non_ops, "total_hours": ops + non_ops}
    finally:
        conn.close()
