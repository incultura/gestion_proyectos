"""
models/hours_log.py — Registro de horas imputadas con fecha.
"""
from db.database import get_connection


def get_logs_by_dedication(project_team_id: int):
    conn = get_connection()
    try:
        rows = conn.execute("""
            SELECT * FROM hours_log
            WHERE project_team_id = ?
            ORDER BY log_date DESC
        """, (project_team_id,)).fetchall()
        return [dict(r) for r in rows]
    finally:
        conn.close()


def get_logs_by_team_month(team_id: str, year: int, month: int):
    """Devuelve todos los logs de un equipo en un mes concreto."""
    start_date = f"{year}-{month:02d}-01"
    import calendar
    _, last_day = calendar.monthrange(year, month)
    end_date = f"{year}-{month:02d}-{last_day}"

    conn = get_connection()
    try:
        rows = conn.execute("""
            SELECT hl.*, pt.project_id, pt.team_id, p.typology
            FROM hours_log hl
            JOIN project_teams pt ON hl.project_team_id = pt.id
            JOIN projects p ON pt.project_id = p.id
            WHERE pt.team_id = ?
              AND hl.log_date >= ? AND hl.log_date <= ?
        """, (team_id, start_date, end_date)).fetchall()
        return [dict(r) for r in rows]
    finally:
        conn.close()


def add_log(data: dict) -> int:
    conn = get_connection()
    try:
        cur = conn.execute("""
            INSERT INTO hours_log (project_team_id, log_date, hours)
            VALUES (:project_team_id, :log_date, :hours)
        """, data)
        new_id = cur.lastrowid
        conn.commit()
        return new_id
    finally:
        conn.close()


def update_log(log_id: int, log_date: str, hours: float):
    conn = get_connection()
    try:
        conn.execute("""
            UPDATE hours_log SET log_date = ?, hours = ? WHERE id = ?
        """, (log_date, hours, log_id))
        conn.commit()
    finally:
        conn.close()


def delete_log(log_id: int):
    conn = get_connection()
    try:
        conn.execute("DELETE FROM hours_log WHERE id = ?", (log_id,))
        conn.commit()
    finally:
        conn.close()


def get_total_imputed(project_team_id: int) -> float:
    conn = get_connection()
    try:
        row = conn.execute(
            "SELECT COALESCE(SUM(hours), 0) as total FROM hours_log WHERE project_team_id = ?",
            (project_team_id,)
        ).fetchone()
        return row["total"] if row else 0.0
    finally:
        conn.close()


def get_total_project_imputed(project_id: int) -> float:
    """Suma todas las imputaciones de todos los equipos asignados a un proyecto."""
    conn = get_connection()
    try:
        row = conn.execute("""
            SELECT COALESCE(SUM(hl.hours), 0) as total 
            FROM hours_log hl
            JOIN project_teams pt ON hl.project_team_id = pt.id
            WHERE pt.project_id = ?
        """, (project_id,)).fetchone()
        return row["total"] if row else 0.0
    finally:
        conn.close()


def get_last_imputation_date(project_team_id: int) -> str:
    """Devuelve la fecha de la última imputación registrada para una dedicación."""
    conn = get_connection()
    try:
        row = conn.execute(
            "SELECT MAX(log_date) as last_date FROM hours_log WHERE project_team_id = ?",
            (project_team_id,)
        ).fetchone()
        return row["last_date"] if row and row["last_date"] else "-"
    finally:
        conn.close()
