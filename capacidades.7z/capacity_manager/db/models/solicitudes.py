"""
models/solicitudes.py — CRUD para solicitudes (antes proyectos).
"""
from db.database import get_connection

TYPOLOGIES = ["Operacion", "PIPE", "Regulatorio", "TTM"]


def get_all_solicitudes():
    conn = get_connection()
    try:
        rows = conn.execute("""
            SELECT sol.*, s.name as status_name
            FROM solicitudes sol
            LEFT JOIN statuses s ON sol.status_id = s.id
            ORDER BY sol.title
        """).fetchall()
        return [dict(r) for r in rows]
    finally:
        conn.close()


def get_solicitud(solicitud_id: int):
    conn = get_connection()
    try:
        row = conn.execute("""
            SELECT sol.*, s.name as status_name
            FROM solicitudes sol
            LEFT JOIN statuses s ON sol.status_id = s.id
            WHERE sol.id = ?
        """, (solicitud_id,)).fetchone()
        if row:
            return dict(row)
        return None
    finally:
        conn.close()


def create_solicitud(data: dict) -> int:
    """data: {title, typology, description, request_link, status_id, start_date, end_date, detention_date, id_solicitud}"""
    conn = get_connection()
    try:
        cur = conn.execute("""
            INSERT INTO solicitudes (title, typology, description, request_link, status_id, start_date, end_date, detention_date, id_solicitud)
            VALUES (:title, :typology, :description, :request_link, :status_id, :start_date, :end_date, :detention_date, :id_solicitud)
        """, data)
        new_id = cur.lastrowid
        conn.commit()
        return int(new_id) if new_id is not None else 0
    finally:
        conn.close()


def update_solicitud(solicitud_id: int, data: dict):
    conn = get_connection()
    try:
        conn.execute("""
            UPDATE solicitudes SET
                title = :title,
                typology = :typology,
                description = :description,
                request_link = :request_link,
                status_id = :status_id,
                start_date = :start_date,
                end_date = :end_date,
                detention_date = :detention_date,
                id_solicitud = :id_solicitud
            WHERE id = :id
        """, {**data, "id": solicitud_id})
        conn.commit()
    finally:
        conn.close()


def delete_solicitud(solicitud_id: int):
    conn = get_connection()
    try:
        conn.execute("DELETE FROM solicitudes WHERE id = ?", (solicitud_id,))
        conn.commit()
    finally:
        conn.close()
