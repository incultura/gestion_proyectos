"""
models/calendar_config.py — Festivos y disponibilidad mensual.
"""
from db.database import get_connection


# ── Festivos ────────────────────────────────────────────────────────────────

def get_holidays(year: int) -> list:
    conn = get_connection()
    try:
        rows = conn.execute(
            "SELECT * FROM holidays WHERE year = ? ORDER BY date", (year,)
        ).fetchall()
        if rows:
            return [dict(r) for r in rows]
        return []
    finally:
        conn.close()


def get_holiday_dates(year: int) -> set:
    return {r["date"] for r in get_holidays(year)}


def add_holiday(year: int, date: str, name: str) -> int:
    conn = get_connection()
    try:
        cur = conn.execute(
            "INSERT OR IGNORE INTO holidays (year, date, name) VALUES (?, ?, ?)",
            (year, date, name)
        )
        new_id = cur.lastrowid
        conn.commit()
        return int(new_id) if new_id is not None else 0
    finally:
        conn.close()


def delete_holiday(holiday_id: int):
    conn = get_connection()
    try:
        conn.execute("DELETE FROM holidays WHERE id = ?", (holiday_id,))
        conn.commit()
    finally:
        conn.close()


# ── Disponibilidad mensual ───────────────────────────────────────────────────

def get_month_availability(year: int, month: int) -> float:
    conn = get_connection()
    try:
        row = conn.execute(
            "SELECT availability_pct FROM month_availability WHERE year = ? AND month = ?",
            (year, month)
        ).fetchone()
        if row:
            return float(row["availability_pct"])
        return 100.0
    finally:
        conn.close()


def set_month_availability(year: int, month: int, pct: float):
    conn = get_connection()
    try:
        conn.execute("""
            INSERT INTO month_availability (year, month, availability_pct)
            VALUES (?, ?, ?)
            ON CONFLICT(year, month) DO UPDATE SET availability_pct = excluded.availability_pct
        """, (year, month, pct))
        conn.commit()
    finally:
        conn.close()


def get_all_month_availability(year: int):
    conn = get_connection()
    try:
        rows = conn.execute(
            "SELECT * FROM month_availability WHERE year = ? ORDER BY month",
            (year,)
        ).fetchall()
        result = {r["month"]: r["availability_pct"] for r in rows}
        # Fill missing months with 100%
        for m in range(1, 13):
            result.setdefault(m, 100.0)
        return result
    finally:
        conn.close()
