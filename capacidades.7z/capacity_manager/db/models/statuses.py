"""
models/statuses.py — Gestión de la tabla maestra de estados.
"""
from db.database import get_connection

def get_all_statuses():
    conn = get_connection()
    try:
        rows = conn.execute("SELECT * FROM statuses ORDER BY id").fetchall()
        return [dict(r) for r in rows]
    finally:
        conn.close()

def get_status_by_id(status_id: int):
    conn = get_connection()
    try:
        row = conn.execute("SELECT * FROM statuses WHERE id = ?", (status_id,)).fetchone()
        return dict(row) if row else None
    finally:
        conn.close()

def get_status_id_by_name(name: str) -> int:
    conn = get_connection()
    try:
        row = conn.execute("SELECT id FROM statuses WHERE name = ?", (name,)).fetchone()
        if row:
            return int(row["id"])
        return 1 # Default to Idea
    finally:
        conn.close()
