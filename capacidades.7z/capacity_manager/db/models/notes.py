import sqlite3
from db.database import get_connection

def create_note(title, content="", is_area_meeting=False):
    conn = get_connection()
    try:
        cur = conn.execute(
            "INSERT INTO notes (title, content, is_area_meeting) VALUES (?, ?, ?)",
            (title, content, int(is_area_meeting))
        )
        conn.commit()
        return cur.lastrowid
    finally:
        conn.close()

def get_all_notes():
    conn = get_connection()
    try:
        rows = conn.execute("SELECT * FROM notes ORDER BY created_date DESC").fetchall()
        return [dict(r) for r in rows]
    finally:
        conn.close()

def search_notes(query):
    """Búsqueda por contenido en las notas."""
    conn = get_connection()
    try:
        # Buscamos la cadena en el campo content o title
        search_term = f"%{query}%"
        rows = conn.execute(
            "SELECT * FROM notes WHERE title LIKE ? OR content LIKE ? ORDER BY created_date DESC",
            (search_term, search_term)
        ).fetchall()
        return [dict(r) for r in rows]
    finally:
        conn.close()

def update_note(note_id, title, content="", is_area_meeting=False):
    conn = get_connection()
    try:
        conn.execute(
            "UPDATE notes SET title = ?, content = ?, is_area_meeting = ? WHERE id = ?",
            (title, content, int(is_area_meeting), note_id)
        )
        conn.commit()
    finally:
        conn.close()

def get_notes_for_report(start_date, end_date, only_area_meeting=False):
    """Obtiene las notas estructuradas para el informe."""
    conn = get_connection()
    try:
        # start_date y end_date vendrán en 'YYYY-MM-DD'
        # created_date es 'YYYY-MM-DD HH:MM:SS'
        query = "SELECT * FROM notes WHERE date(created_date) >= ? AND date(created_date) <= ?"
        params = [start_date, end_date]
        if only_area_meeting:
            query += " AND is_area_meeting = 1"
        query += " ORDER BY created_date DESC"
        
        rows = conn.execute(query, params).fetchall()
        return [dict(r) for r in rows]
    finally:
        conn.close()

def delete_note(note_id):
    conn = get_connection()
    try:
        conn.execute("DELETE FROM notes WHERE id = ?", (note_id,))
        conn.commit()
    finally:
        conn.close()
