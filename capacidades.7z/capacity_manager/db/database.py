"""
database.py — Conexión SQLite y creación de tablas.
Schema v5: Añadido UNIQUE(project_team_id, log_date) a hours_log.
"""
import sqlite3
import os

DB_PATH = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "capacity.db")


def get_connection() -> sqlite3.Connection:
    conn = sqlite3.connect(DB_PATH, timeout=20)  # Aumentar timeout para evitar 'locked'
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    conn.execute("PRAGMA journal_mode = WAL")  # Modo WAL mejora la concurrencia
    conn.execute("PRAGMA synchronous = NORMAL") # Optimización recomendada para WAL
    return conn


def initialize_db():
    conn = get_connection()
    try:
        cur = conn.cursor()
        cur.executescript("""
            CREATE TABLE IF NOT EXISTS teams (
                id                     INTEGER PRIMARY KEY AUTOINCREMENT,
                name                   TEXT    NOT NULL UNIQUE,
                internal_people        INTEGER NOT NULL DEFAULT 0,
                internal_annual_hours  REAL    NOT NULL DEFAULT 0,
                baseline_people        INTEGER NOT NULL DEFAULT 0,
                baseline_annual_hours  REAL    NOT NULL DEFAULT 0,
                reinforce_people       INTEGER NOT NULL DEFAULT 0,
                reinforce_annual_hours REAL    NOT NULL DEFAULT 0,
                ops_percentage         REAL    NOT NULL DEFAULT 0
            );

            CREATE TABLE IF NOT EXISTS projects (
                id             INTEGER PRIMARY KEY AUTOINCREMENT,
                title          TEXT    NOT NULL UNIQUE,
                typology       TEXT    NOT NULL,
                description    TEXT    NOT NULL DEFAULT '',
                request_link   TEXT    NOT NULL DEFAULT '',
                start_date     TEXT,
                end_date       TEXT,
                detention_date TEXT,
                id_solicitud   INTEGER NOT NULL DEFAULT 0
            );

            CREATE TABLE IF NOT EXISTS project_teams (
                id              INTEGER PRIMARY KEY AUTOINCREMENT,
                project_id      INTEGER NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
                team_id         INTEGER NOT NULL REFERENCES teams(id)    ON DELETE CASCADE,
                status          TEXT    NOT NULL DEFAULT 'en estimacion',
                start_date      TEXT,
                end_date        TEXT,
                estimated_hours REAL    NOT NULL DEFAULT 0,
                id_proyecto     INTEGER NOT NULL DEFAULT 0,
                UNIQUE(project_id, team_id)
            );

            CREATE TABLE IF NOT EXISTS loads_log (
                id             INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp      DATETIME DEFAULT CURRENT_TIMESTAMP,
                filename       TEXT    NOT NULL,
                file_path      TEXT    NOT NULL,
                total_rows     INTEGER NOT NULL DEFAULT 0,
                total_hours    REAL    NOT NULL DEFAULT 0
            );

            CREATE TABLE IF NOT EXISTS imputations_raw (
                id             INTEGER PRIMARY KEY AUTOINCREMENT,
                load_id        INTEGER NOT NULL REFERENCES loads_log(id),
                rol            TEXT,
                tipo_actividad TEXT,
                cod_actividad  TEXT,
                nom_actividad  TEXT,
                nom_tarea      TEXT,
                empresa        TEXT,
                cod_usuario    TEXT,
                nom_usuario    TEXT,
                area           TEXT,
                departamento   TEXT,
                anio_mes       TEXT,
                horas          REAL,
                subtipo        TEXT,
                prioridad      TEXT,
                solicitud      TEXT,
                fecha_suspension TEXT,
                fecha_replan   TEXT,
                aplicacion_cgdn TEXT,
                entregable     TEXT,
                entidad        TEXT,
                calculated_team TEXT
            );

            CREATE TABLE IF NOT EXISTS hours_log (
                id              INTEGER PRIMARY KEY AUTOINCREMENT,
                project_team_id INTEGER NOT NULL REFERENCES project_teams(id),
                log_date        TEXT    NOT NULL,
                hours           REAL    NOT NULL DEFAULT 0,
                comment         TEXT,
                load_id         INTEGER REFERENCES loads_log(id)
            );

            CREATE TABLE IF NOT EXISTS holidays (
                id   INTEGER PRIMARY KEY AUTOINCREMENT,
                year INTEGER NOT NULL,
                date TEXT    NOT NULL UNIQUE,
                name TEXT    NOT NULL DEFAULT ''
            );

            CREATE TABLE IF NOT EXISTS notes (
                id              INTEGER PRIMARY KEY AUTOINCREMENT,
                title           TEXT    NOT NULL,
                content         TEXT,
                is_area_meeting BOOLEAN DEFAULT 0,
                created_date    DATETIME DEFAULT CURRENT_TIMESTAMP
            );

            CREATE TABLE IF NOT EXISTS links (
                id           INTEGER PRIMARY KEY AUTOINCREMENT,
                title        TEXT    NOT NULL,
                url          TEXT    NOT NULL,
                created_date DATETIME DEFAULT CURRENT_TIMESTAMP
            );

            CREATE TABLE IF NOT EXISTS month_availability (
                id               INTEGER PRIMARY KEY AUTOINCREMENT,
                year             INTEGER NOT NULL,
                month            INTEGER NOT NULL,
                availability_pct REAL    NOT NULL DEFAULT 100,
                UNIQUE(year, month)
            );

            CREATE TABLE IF NOT EXISTS project_annotations (
                id                INTEGER PRIMARY KEY AUTOINCREMENT,
                project_id        INTEGER NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
                annotation_number INTEGER NOT NULL,
                date              TEXT    NOT NULL,
                content           TEXT    NOT NULL,
                UNIQUE(project_id, annotation_number)
            );

            CREATE TABLE IF NOT EXISTS statuses (
                id   INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL UNIQUE
            );

            CREATE TABLE IF NOT EXISTS dependencies (
                id   INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL UNIQUE
            );

            CREATE TABLE IF NOT EXISTS project_dependencies (
                project_id    INTEGER NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
                dependency_id INTEGER NOT NULL REFERENCES dependencies(id) ON DELETE CASCADE,
                PRIMARY KEY (project_id, dependency_id)
            );
        """)

        # Insertar estados por defecto si la tabla está vacía
        cur = conn.execute("SELECT COUNT(*) as count FROM statuses")
        if cur.fetchone()["count"] == 0:
            default_statuses = [
                "Idea", "En estimación", "En desarrollo", 
                "Finalizado", "Detenido", "Descartado"
            ]
            conn.executemany("INSERT INTO statuses (name) VALUES (?)", [(s,) for s in default_statuses])

        # Migración: Añadir status_id a projects si no existe
        cur = conn.execute("PRAGMA table_info(projects)")
        cols = [row["name"] for row in cur.fetchall()]
        if "status_id" not in cols:
            conn.execute("ALTER TABLE projects ADD COLUMN status_id INTEGER REFERENCES statuses(id)")
            # Asignar estado "Idea" (ID 1) por defecto
            conn.execute("UPDATE projects SET status_id = 1")

        # Migración: Añadir fechas de ciclo de vida a projects si no existen (en caso de actualización)
        if "start_date" not in cols:
            conn.execute("ALTER TABLE projects ADD COLUMN start_date TEXT")
        if "end_date" not in cols:
            conn.execute("ALTER TABLE projects ADD COLUMN end_date TEXT")
        if "detention_date" not in cols:
            conn.execute("ALTER TABLE projects ADD COLUMN detention_date TEXT")
        if "id_solicitud" not in cols:
            conn.execute("ALTER TABLE projects ADD COLUMN id_solicitud INTEGER NOT NULL DEFAULT 0")

        # Migración: Añadir status_id/id_proyecto a project_teams si no existe
        cur = conn.execute("PRAGMA table_info(project_teams)")
        cols = [row["name"] for row in cur.fetchall()]
        if "id_proyecto" not in cols:
            conn.execute("ALTER TABLE project_teams ADD COLUMN id_proyecto INTEGER NOT NULL DEFAULT 0")

        if "status_id" not in cols:
            conn.execute("ALTER TABLE project_teams ADD COLUMN status_id INTEGER REFERENCES statuses(id)")
            
        # Migración: Añadir load_id y comment a hours_log si no existen
        cur = conn.execute("PRAGMA table_info(hours_log)")
        cols_h = [row["name"] for row in cur.fetchall()]
        if "load_id" not in cols_h:
            conn.execute("ALTER TABLE hours_log ADD COLUMN load_id INTEGER REFERENCES loads_log(id)")
        if "comment" not in cols_h:
            conn.execute("ALTER TABLE hours_log ADD COLUMN comment TEXT")

        # Migración: Añadir is_area_meeting a notes
        cur = conn.execute("PRAGMA table_info(notes)")
        cols_n = [row["name"] for row in cur.fetchall()]
        if "is_area_meeting" not in cols_n:
            conn.execute("ALTER TABLE notes ADD COLUMN is_area_meeting BOOLEAN DEFAULT 0")

        if "status_id" not in cols:
            # Mapeo de texto antiguo a nuevos IDs
            status_map = {
                "propuesto": 1,    # Idea
                "estimando": 2,    # En estimación
                "en desarrollo": 3, # En desarrollo
                "finalizado": 4,   # Finalizado
                "detenido": 5,     # Detenido
                "descartado": 6    # Descartado
            }
            for old, new_id in status_map.items():
                conn.execute("UPDATE project_teams SET status_id = ? WHERE status = ?", (new_id, old))
            
            # Valores por defecto para el resto
            conn.execute("UPDATE project_teams SET status_id = 1 WHERE status_id IS NULL")

        # --- OPTIMIZACIÓN: Índices ---
        conn.execute("CREATE INDEX IF NOT EXISTS idx_project_teams_team_id ON project_teams(team_id)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_project_teams_status_id ON project_teams(status_id)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_projects_status_id ON projects(status_id)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_hours_log_log_date ON hours_log(log_date)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_hours_log_load_id ON hours_log(load_id)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_imputations_raw_load_id ON imputations_raw(load_id)")

        # Índices Únicos Parciales (permitir múltiples 0, pero no repetidos > 0)
        conn.execute("CREATE UNIQUE INDEX IF NOT EXISTS idx_projects_id_solicitud ON projects(id_solicitud) WHERE id_solicitud > 0")
        conn.execute("CREATE UNIQUE INDEX IF NOT EXISTS idx_project_teams_id_proyecto ON project_teams(id_proyecto) WHERE id_proyecto > 0")

        conn.commit()
    finally:
        conn.close()
