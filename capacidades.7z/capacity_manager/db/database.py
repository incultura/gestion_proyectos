"""
database.py — Conexión SQLite y creación de tablas.
Schema v6: Renombrado Projects -> Solicitudes y Project_Teams -> Projects.
"""
import sqlite3
import os

DB_PATH = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "capacity.db")


def get_connection() -> sqlite3.Connection:
    conn = sqlite3.connect(DB_PATH, timeout=20)  # Aumentar timeout para evitar 'locked'
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    conn.execute("PRAGMA journal_mode = WAL")  # Modo WAL mejora la concurrencia
    conn.execute("PRAGMA synchronous = NORMAL") # Optimización recomendada para WAL
    return conn


def initialize_db():
    conn = get_connection()
    try:
        cur = conn.cursor()
        
        # --- MIGRACIÓN PROFUNDA v6 ---
        # Detectamos si existe la tabla 'project_teams' (denota esquema antiguo v5)
        cur.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='project_teams'")
        if cur.fetchone():
            print("Iniciando migración profunda v6 (Projects -> Solicitudes)...")
            conn.execute("PRAGMA foreign_keys=OFF")
            
            # 1. Renombrar tablas principales (si existen con nombres antiguos)
            conn.execute("DROP TABLE IF EXISTS solicitudes")
            conn.execute("ALTER TABLE projects RENAME TO solicitudes")
            
            conn.execute("DROP TABLE IF EXISTS projects_v6")
            conn.execute("ALTER TABLE project_teams RENAME TO projects")
            
            # 2. Renombrar tablas secundarias
            conn.execute("DROP TABLE IF EXISTS solicitud_annotations")
            conn.execute("ALTER TABLE project_annotations RENAME TO solicitud_annotations")
            conn.execute("DROP TABLE IF EXISTS solicitud_dependencies")
            conn.execute("ALTER TABLE project_dependencies RENAME TO solicitud_dependencies")
            conn.execute("DROP TABLE IF EXISTS solicitud_deliverables")
            conn.execute("ALTER TABLE project_deliverables RENAME TO solicitud_deliverables")
            
            # 3. Corregir columnas en 'projects' (ex project_teams)
            conn.execute("""
                CREATE TABLE projects_v6 (
                    id              INTEGER PRIMARY KEY AUTOINCREMENT,
                    solicitud_id    INTEGER NOT NULL REFERENCES solicitudes(id) ON DELETE CASCADE,
                    team_id         INTEGER NOT NULL REFERENCES teams(id)    ON DELETE CASCADE,
                    status_id       INTEGER REFERENCES statuses(id),
                    start_date      TEXT,
                    end_date        TEXT,
                    estimated_hours REAL    NOT NULL DEFAULT 0,
                    id_proyecto     INTEGER NOT NULL DEFAULT 0,
                    entregable      TEXT    NOT NULL DEFAULT '',
                    project_title   TEXT    NOT NULL DEFAULT ''
                )
            """)
            conn.execute("INSERT INTO projects_v6 (id, solicitud_id, team_id, status_id, start_date, end_date, estimated_hours, id_proyecto, entregable, project_title) "
                         "SELECT id, project_id, team_id, status_id, start_date, end_date, estimated_hours, id_proyecto, entregable, '' FROM projects")
            conn.execute("DROP TABLE projects")
            conn.execute("ALTER TABLE projects_v6 RENAME TO projects")
            conn.execute("CREATE UNIQUE INDEX IF NOT EXISTS idx_projects_unique_v6 ON projects(solicitud_id, team_id, id_proyecto)")

            # 4. Corregir columnas en tablas que referenciaban projects (ahora solicitudes)
            # solicitud_annotations
            conn.execute("""
                CREATE TABLE solicitud_annotations_v6 (
                    id                INTEGER PRIMARY KEY AUTOINCREMENT,
                    solicitud_id     INTEGER NOT NULL REFERENCES solicitudes(id) ON DELETE CASCADE,
                    annotation_number INTEGER NOT NULL,
                    date              TEXT    NOT NULL,
                    content           TEXT    NOT NULL,
                    UNIQUE(solicitud_id, annotation_number)
                )
            """)
            conn.execute("INSERT INTO solicitud_annotations_v6 SELECT * FROM solicitud_annotations")
            conn.execute("DROP TABLE solicitud_annotations")
            conn.execute("ALTER TABLE solicitud_annotations_v6 RENAME TO solicitud_annotations")

            # solicitud_dependencies
            conn.execute("""
                CREATE TABLE solicitud_dependencies_v6 (
                    solicitud_id  INTEGER NOT NULL REFERENCES solicitudes(id) ON DELETE CASCADE,
                    dependency_id INTEGER NOT NULL REFERENCES dependencies(id) ON DELETE CASCADE,
                    PRIMARY KEY (solicitud_id, dependency_id)
                )
            """)
            conn.execute("INSERT INTO solicitud_dependencies_v6 SELECT * FROM solicitud_dependencies")
            conn.execute("DROP TABLE solicitud_dependencies")
            conn.execute("ALTER TABLE solicitud_dependencies_v6 RENAME TO solicitud_dependencies")

            # solicitud_deliverables
            conn.execute("""
                CREATE TABLE solicitud_deliverables_v6 (
                    id           INTEGER PRIMARY KEY AUTOINCREMENT,
                    solicitud_id INTEGER NOT NULL REFERENCES solicitudes(id) ON DELETE CASCADE,
                    name         TEXT    NOT NULL,
                    UNIQUE(solicitud_id, name)
                )
            """)
            conn.execute("INSERT INTO solicitud_deliverables_v6 SELECT * FROM solicitud_deliverables")
            conn.execute("DROP TABLE solicitud_deliverables")
            conn.execute("ALTER TABLE solicitud_deliverables_v6 RENAME TO solicitud_deliverables")

            # 5. Corregir tablas que referenciaban project_teams (ahora projects)
            # hours_log
            conn.execute("""
                CREATE TABLE hours_log_v6 (
                    id              INTEGER PRIMARY KEY AUTOINCREMENT,
                    project_id      INTEGER NOT NULL REFERENCES projects(id),
                    log_date        TEXT    NOT NULL,
                    hours           REAL    NOT NULL DEFAULT 0,
                    comment         TEXT,
                    load_id         INTEGER REFERENCES loads_log(id)
                )
            """)
            conn.execute("INSERT INTO hours_log_v6 (id, project_id, log_date, hours, comment, load_id) "
                         "SELECT id, project_team_id, log_date, hours, comment, load_id FROM hours_log")
            conn.execute("DROP TABLE hours_log")
            conn.execute("ALTER TABLE hours_log_v6 RENAME TO hours_log")

            # capacity_snapshots
            conn.execute("""
                CREATE TABLE capacity_snapshots_v6 (
                    id              INTEGER PRIMARY KEY AUTOINCREMENT,
                    year            INTEGER NOT NULL,
                    month           INTEGER NOT NULL,
                    team_id         INTEGER NOT NULL REFERENCES teams(id) ON DELETE CASCADE,
                    project_id      INTEGER NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
                    planned_hours   REAL    NOT NULL DEFAULT 0,
                    typology        TEXT    NOT NULL DEFAULT '',
                    snapshot_date   DATETIME DEFAULT CURRENT_TIMESTAMP,
                    UNIQUE(year, month, project_id)
                )
            """)
            conn.execute("INSERT INTO capacity_snapshots_v6 (id, year, month, team_id, project_id, planned_hours, typology, snapshot_date) "
                         "SELECT id, year, month, team_id, dedication_id, planned_hours, typology, snapshot_date FROM capacity_snapshots")
            conn.execute("DROP TABLE capacity_snapshots")
            conn.execute("ALTER TABLE capacity_snapshots_v6 RENAME TO capacity_snapshots")

            conn.execute("PRAGMA foreign_keys=ON")
            print("Migración profunda v6 completada con éxito.")

        # --- MIGRACIÓN v8 (Dependencies associated to projects instead of solicitudes) ---
        cur.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='solicitud_dependencies'")
        if cur.fetchone():
            print("Iniciando migración v8 (Dependencies: Solicidudes -> Proyectos)...")
            conn.execute("PRAGMA foreign_keys=OFF")
            
            # 1. Crear nueva tabla de dependencias de proyectos
            conn.execute("""
                CREATE TABLE project_dependencies (
                    project_id    INTEGER NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
                    dependency_id INTEGER NOT NULL REFERENCES dependencies(id) ON DELETE CASCADE,
                    PRIMARY KEY (project_id, dependency_id)
                )
            """)
            
            # 2. Intentar migrar datos existentes: para cada solicitud, asociar sus dependencias a todos sus proyectos actuales
            conn.execute("""
                INSERT OR IGNORE INTO project_dependencies (project_id, dependency_id)
                SELECT p.id, sd.dependency_id
                FROM solicitud_dependencies sd
                JOIN projects p ON sd.solicitud_id = p.solicitud_id
            """)
            
            # 3. Eliminar tabla antigua
            conn.execute("DROP TABLE solicitud_dependencies")
            conn.execute("PRAGMA foreign_keys=ON")
            print("Migración v8 completada con éxito.")

        # --- MIGRACIÓN v9 (Allow multiple id_proyecto=0 in projects) ---
        cur.execute("SELECT sql FROM sqlite_master WHERE type='table' AND name='projects'")
        row_sql = cur.fetchone()
        if row_sql:
            sql_projects = row_sql[0]
            if "UNIQUE(solicitud_id, id_proyecto)" in sql_projects or "UNIQUE (solicitud_id, id_proyecto)" in sql_projects:
                print("Iniciando migración v9 (Projects: allow multiple id_proyecto=0)...")
                conn.execute("PRAGMA foreign_keys=OFF")
                conn.execute("ALTER TABLE projects RENAME TO projects_old_v9")
                conn.execute("""
                    CREATE TABLE projects (
                        id             INTEGER PRIMARY KEY AUTOINCREMENT,
                        solicitud_id   INTEGER NOT NULL REFERENCES solicitudes(id) ON DELETE CASCADE,
                        id_proyecto    INTEGER NOT NULL,
                        title          TEXT    NOT NULL,
                        description    TEXT    NOT NULL DEFAULT '',
                        entregable     TEXT    NOT NULL DEFAULT ''
                    )
                """)
                conn.execute("INSERT INTO projects (id, solicitud_id, id_proyecto, title, description, entregable) "
                             "SELECT id, solicitud_id, id_proyecto, title, description, entregable FROM projects_old_v9")
                
                # --- REPARACIÓN DE REFERENCIAS ---
                # Al renombrar 'projects', las FK de 'dedications' y 'project_dependencies' 
                # ahora apuntan a 'projects_old_v9'. Debemos recrearlas.
                
                # 1. dedications
                conn.execute("ALTER TABLE dedications RENAME TO dedications_old_v9")
                conn.execute("""
                    CREATE TABLE dedications (
                        id              INTEGER PRIMARY KEY AUTOINCREMENT,
                        project_id      INTEGER NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
                        team_id         INTEGER NOT NULL REFERENCES teams(id)    ON DELETE CASCADE,
                        status_id       INTEGER REFERENCES statuses(id),
                        start_date      TEXT,
                        end_date        TEXT,
                        estimated_hours REAL    NOT NULL DEFAULT 0,
                        UNIQUE(project_id, team_id)
                    )
                """)
                conn.execute("INSERT INTO dedications SELECT * FROM dedications_old_v9")
                conn.execute("DROP TABLE dedications_old_v9")

                # 2. project_dependencies
                conn.execute("ALTER TABLE project_dependencies RENAME TO proj_deps_old_v9")
                conn.execute("""
                    CREATE TABLE project_dependencies (
                        project_id    INTEGER NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
                        dependency_id INTEGER NOT NULL REFERENCES dependencies(id) ON DELETE CASCADE,
                        PRIMARY KEY (project_id, dependency_id)
                    )
                """)
                conn.execute("INSERT INTO project_dependencies SELECT * FROM proj_deps_old_v9")
                conn.execute("DROP TABLE proj_deps_old_v9")

                conn.execute("CREATE UNIQUE INDEX IF NOT EXISTS idx_projects_sol_id_v9 ON projects(solicitud_id, id_proyecto) WHERE id_proyecto != 0")
                conn.execute("DROP TABLE projects_old_v9")
                conn.execute("PRAGMA foreign_keys=ON")
                print("Migración v9 (con reparación de FKs) completada con éxito.")

        cur.executescript("""
            CREATE TABLE IF NOT EXISTS teams (
                id                     INTEGER PRIMARY KEY AUTOINCREMENT,
                name                   TEXT    NOT NULL UNIQUE,
                internal_people        INTEGER NOT NULL DEFAULT 0,
                internal_annual_hours  REAL    NOT NULL DEFAULT 0,
                baseline_people        INTEGER NOT NULL DEFAULT 0,
                baseline_annual_hours  REAL    NOT NULL DEFAULT 0,
                reinforce_people       INTEGER NOT NULL DEFAULT 0,
                reinforce_annual_hours REAL    NOT NULL DEFAULT 0,
                ops_percentage         REAL    NOT NULL DEFAULT 0
            );

            CREATE TABLE IF NOT EXISTS solicitudes (
                id             INTEGER PRIMARY KEY AUTOINCREMENT,
                title          TEXT    NOT NULL UNIQUE,
                typology       TEXT    NOT NULL,
                description    TEXT    NOT NULL DEFAULT '',
                request_link   TEXT    NOT NULL DEFAULT '',
                start_date     TEXT,
                end_date       TEXT,
                detention_date TEXT,
                id_solicitud   INTEGER NOT NULL DEFAULT 0,
                status_id      INTEGER REFERENCES statuses(id)
            );

            CREATE TABLE IF NOT EXISTS projects (
                id             INTEGER PRIMARY KEY AUTOINCREMENT,
                solicitud_id   INTEGER NOT NULL REFERENCES solicitudes(id) ON DELETE CASCADE,
                id_proyecto    INTEGER NOT NULL,
                title          TEXT    NOT NULL,
                description    TEXT    NOT NULL DEFAULT '',
                entregable     TEXT    NOT NULL DEFAULT ''
            );

            CREATE TABLE IF NOT EXISTS dedications (
                id              INTEGER PRIMARY KEY AUTOINCREMENT,
                project_id      INTEGER NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
                team_id         INTEGER NOT NULL REFERENCES teams(id)    ON DELETE CASCADE,
                status_id       INTEGER REFERENCES statuses(id),
                start_date      TEXT,
                end_date        TEXT,
                estimated_hours REAL    NOT NULL DEFAULT 0,
                UNIQUE(project_id, team_id)
            );

            CREATE TABLE IF NOT EXISTS loads_log (
                id             INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp      DATETIME DEFAULT CURRENT_TIMESTAMP,
                filename       TEXT    NOT NULL,
                file_path      TEXT    NOT NULL,
                total_rows     INTEGER NOT NULL DEFAULT 0,
                total_hours    REAL    NOT NULL DEFAULT 0
            );

            CREATE TABLE IF NOT EXISTS hours_log (
                id              INTEGER PRIMARY KEY AUTOINCREMENT,
                dedication_id   INTEGER NOT NULL REFERENCES dedications(id) ON DELETE CASCADE,
                log_date        TEXT    NOT NULL,
                hours           REAL    NOT NULL DEFAULT 0,
                comment         TEXT,
                load_id         INTEGER REFERENCES loads_log(id)
            );

            CREATE TABLE IF NOT EXISTS holidays (
                id   INTEGER PRIMARY KEY AUTOINCREMENT,
                year INTEGER NOT NULL,
                date TEXT    NOT NULL UNIQUE,
                name TEXT    NOT NULL DEFAULT ''
            );

            CREATE TABLE IF NOT EXISTS notes (
                id              INTEGER PRIMARY KEY AUTOINCREMENT,
                title           TEXT    NOT NULL,
                content         TEXT,
                is_area_meeting BOOLEAN DEFAULT 0,
                created_date    DATETIME DEFAULT CURRENT_TIMESTAMP
            );

            CREATE TABLE IF NOT EXISTS month_availability (
                id               INTEGER PRIMARY KEY AUTOINCREMENT,
                year             INTEGER NOT NULL,
                month            INTEGER NOT NULL,
                availability_pct REAL    NOT NULL DEFAULT 100,
                UNIQUE(year, month)
            );

            CREATE TABLE IF NOT EXISTS solicitud_annotations (
                id                INTEGER PRIMARY KEY AUTOINCREMENT,
                solicitud_id     INTEGER NOT NULL REFERENCES solicitudes(id) ON DELETE CASCADE,
                annotation_number INTEGER NOT NULL,
                date              TEXT    NOT NULL,
                content           TEXT    NOT NULL,
                UNIQUE(solicitud_id, annotation_number)
            );

            CREATE TABLE IF NOT EXISTS statuses (
                id   INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL UNIQUE
            );

            CREATE TABLE IF NOT EXISTS dependencies (
                id   INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL UNIQUE
            );

            CREATE TABLE IF NOT EXISTS project_dependencies (
                project_id    INTEGER NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
                dependency_id INTEGER NOT NULL REFERENCES dependencies(id) ON DELETE CASCADE,
                PRIMARY KEY (project_id, dependency_id)
            );

            CREATE TABLE IF NOT EXISTS capacity_snapshots (
                id              INTEGER PRIMARY KEY AUTOINCREMENT,
                year            INTEGER NOT NULL,
                month           INTEGER NOT NULL,
                team_id         INTEGER NOT NULL REFERENCES teams(id) ON DELETE CASCADE,
                dedication_id   INTEGER NOT NULL REFERENCES dedications(id) ON DELETE CASCADE,
                planned_hours   REAL    NOT NULL DEFAULT 0,
                typology        TEXT    NOT NULL DEFAULT '',
                snapshot_date   DATETIME DEFAULT CURRENT_TIMESTAMP,
                UNIQUE(year, month, dedication_id)
            );
            CREATE TABLE IF NOT EXISTS solicitud_deliverables (
                id           INTEGER PRIMARY KEY AUTOINCREMENT,
                solicitud_id INTEGER NOT NULL REFERENCES solicitudes(id) ON DELETE CASCADE,
                name         TEXT    NOT NULL,
                UNIQUE(solicitud_id, name)
            );

            CREATE TABLE IF NOT EXISTS config (
                key   TEXT PRIMARY KEY,
                value TEXT NOT NULL
            );
        """)

        # --- OPTIMIZACIÓN: Índices ---
        conn.execute("CREATE INDEX IF NOT EXISTS idx_dedications_team_id ON dedications(team_id)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_dedications_status_id ON dedications(status_id)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_projects_solicitud_id ON projects(solicitud_id)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_hours_log_date ON hours_log(log_date)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_hours_log_dedication_id ON hours_log(dedication_id)")

        # Índices Únicos Parciales
        conn.execute("CREATE UNIQUE INDEX IF NOT EXISTS idx_solicitudes_id_solicitud ON solicitudes(id_solicitud) WHERE id_solicitud > 0")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_projects_id_proyecto_v7 ON projects(id_proyecto) WHERE id_proyecto > 0")

        # --- SEGURIDAD: Reparar FKs rotas por migración v9 ---
        for table_name in ["dedications", "project_dependencies"]:
            cur.execute(f"SELECT sql FROM sqlite_master WHERE name='{table_name}'")
            row = cur.fetchone()
            if row:
                sql_schema = row[0]
                if "projects_old_v9" in sql_schema:
                    print(f"Reparando FK rota en tabla '{table_name}'...")
                    new_sql = sql_schema.replace("projects_old_v9", "projects")
                    conn.execute("PRAGMA foreign_keys=OFF")
                    conn.execute(f"ALTER TABLE {table_name} RENAME TO {table_name}_repair")
                    conn.execute(new_sql)
                    conn.execute(f"INSERT INTO {table_name} SELECT * FROM {table_name}_repair")
                    conn.execute(f"DROP TABLE {table_name}_repair")
                    conn.execute("PRAGMA foreign_keys=ON")
                    print(f"Tabla '{table_name}' reparada con éxito.")

        conn.commit()
    finally:
        conn.close()

