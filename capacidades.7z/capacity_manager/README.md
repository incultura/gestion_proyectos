# Capacity Manager - Guía de Instalación

Esta aplicación está diseñada para gestionar la capacidad de los equipos, proyectos y dedicaciones. Sigue estos pasos para instalarla en un nuevo equipo (Windows).

## Requisitos Previos
- **Python 3.10 o superior**: Descárgalo de [python.org](https://www.python.org/downloads/windows/). Durante la instalación, asegúrate de marcar la casilla **"Add Python to PATH"**.

## Pasos de Instalación

### 1. Copiar el Proyecto
Copia la carpeta del proyecto `capacity_manager` a la ubicación deseada en el nuevo equipo.

### 2. Crear Entorno Virtual (Recomendado)
Abre una terminal (PowerShell o CMD) dentro de la carpeta del proyecto y ejecuta:
```bash
python -m venv venv
```

### 3. Activar el Entorno
- En **PowerShell**:
  ```powershell
  .\venv\Scripts\Activate.ps1
  ```
- En **CMD**:
  ```cmd
  .\venv\Scripts\activate.bat
  ```

### 4. Instalar Dependencias
Con el entorno activado, instala las librerías necesarias:
```bash
pip install -r requirements.txt
```

### 5. Ejecutar la Aplicación
Para iniciar el programa:
```bash
python main.py
```

---

## Solución de Problemas
- **Base de Datos**: El archivo `capacity.db` se creará automáticamente en la carpeta `capacity_manager` la primera vez que inicies la aplicación. No necesitas configurarla manualmente.
- **Exportación PDF**: Asegúrate de tener permisos de escritura en la carpeta del proyecto para generar los informes.
  