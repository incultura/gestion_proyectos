"""
utils/gui_utils.py — Utilidades para la interfaz gráfica.
"""
import tkinter as tk
import customtkinter as ctk

class Tooltip:
    def __init__(self, widget, text):
        self.widget = widget
        self.text = text
        self.tooltip_window = None
        self.after_id = None
        self.widget.bind("<Enter>", self.schedule_tooltip)
        self.widget.bind("<Leave>", self.hide_tooltip)

    def schedule_tooltip(self, event=None):
        if self.after_id:
            self.widget.after_cancel(self.after_id)
        self.after_id = self.widget.after(1000, self.show_tooltip)

    def show_tooltip(self, event=None):
        if self.tooltip_window or not self.text:
            return
        
        # Obtener posición del widget
        x = self.widget.winfo_rootx() + 20
        y = self.widget.winfo_rooty() + self.widget.winfo_height() + 5
        
        # Crear ventana toplevel
        self.tooltip_window = tw = tk.Toplevel(self.widget)
        tw.wm_overrideredirect(True)
        tw.wm_geometry(f"+{x}+{y}")
        
        label = tk.Label(tw, text=self.text, justify='left',
                         background="#ffffe0", relief='solid', borderwidth=1,
                         font=("tahoma", "13", "bold"), padx=12, pady=6)
        label.pack(ipadx=1)

    def hide_tooltip(self, event=None):
        if self.after_id:
            self.widget.after_cancel(self.after_id)
            self.after_id = None
        tw = self.tooltip_window
        self.tooltip_window = None
        if tw:
            tw.destroy()

class DateEntry(ctk.CTkEntry):
    """
    Subclase de CTkEntry que convierte automáticamente '/' en '-' 
    mientras el usuario escribe.
    """
    def __init__(self, master, **kwargs):
        super().__init__(master, **kwargs)
        self.bind("<KeyRelease>", self._on_key_release)

    def _on_key_release(self, event):
        val = self.get()
        if "/" in val:
            new_val = val.replace("/", "-")
            # Guardar la posición del cursor
            pos = self.index("insert")
            self.delete(0, "end")
            self.insert(0, new_val)
            # Restaurar la posición del cursor
            self.icursor(pos)

    def set_date(self, text):
        self.delete(0, "end")
        self.insert(0, text or "")

class TableFrame(ctk.CTkFrame):
    def __init__(self, master, columns=None, headers=None, **kwargs):
        super().__init__(master, **kwargs)
        self.columns = columns or headers or []
        self.rows = []
        self._build_header()

    def _build_header(self):
        for i, col in enumerate(self.columns):
            ctk.CTkLabel(self, text=col, font=ctk.CTkFont(weight="bold")).grid(
                row=0, column=i, padx=10, pady=5, sticky="ew")

    def add_row(self, values, widgets=None):
        row_idx = len(self.rows) + 1
        row_widgets = []
        for i, val in enumerate(values):
            lbl = ctk.CTkLabel(self, text=val)
            lbl.grid(row=row_idx, column=i, padx=10, pady=2, sticky="ew")
            row_widgets.append(lbl)
        
        if widgets:
            for i, widget_func in widgets.items():
                w = widget_func(self)
                w.grid(row=row_idx, column=i, padx=10, pady=2)
                row_widgets.append(w)
                
        self.rows.append(row_widgets)
        return row_widgets
