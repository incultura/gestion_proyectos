"""
utils/date_utils.py — Conversiones de formato de fecha.
GUI: DD-MM-YYYY
DB:  YYYY-MM-DD (ISO)
"""
from datetime import date

def gui_to_db(date_str: str) -> str:
    """Convierte 'DD-MM-YYYY' a 'YYYY-MM-DD'. Retorna None si está vacío o es inválido."""
    if not date_str or not date_str.strip():
        return None
    try:
        # Intentar parsear DD-MM-YYYY
        parts = date_str.strip().split("-")
        if len(parts) != 3:
            return date_str # Devolver tal cual si no coincide, para que falle el validador de fecha
        d, m, y = parts
        return date(int(y), int(m), int(d)).isoformat()
    except (ValueError, TypeError):
        return date_str

def db_to_gui(date_str: str) -> str:
    """Convierte 'YYYY-MM-DD' a 'DD-MM-YYYY'."""
    if not date_str or not date_str.strip():
        return ""
    try:
        d = date.fromisoformat(date_str)
        return d.strftime("%d-%m-%Y")
    except (ValueError, TypeError):
        return date_str

def get_today_gui() -> str:
    """Retorna la fecha de hoy en formato DD-MM-YYYY."""
    return date.today().strftime("%d-%m-%Y")
