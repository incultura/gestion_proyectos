
import customtkinter as ctk
from tkinter import filedialog, messagebox
import pandas as pd
from logic.imputations_logic import (
    read_and_process_file, generate_summary, apply_bulk_load, 
    get_load_history, rollback_load
)
from utils.gui_utils import Tooltip, TableFrame

class ImputationsLoadTab(ctk.CTkFrame):
    def __init__(self, parent):
        super().__init__(parent)
        self.parent = parent
        self.file_path = None
        self.df = None
        
        # Upper section: Guided flow
        self.flow_frame = ctk.CTkFrame(self)
        self.flow_frame.pack(fill="x", pady=(0, 20))
        
        ctk.CTkLabel(self.flow_frame, text="📥 Carga Masiva de Imputaciones", 
                     font=ctk.CTkFont(size=20, weight="bold")).pack(pady=10)
        
        # Step 1: Selection
        self.step1_frame = ctk.CTkFrame(self.flow_frame, fg_color="transparent")
        self.step1_frame.pack(fill="x", padx=20, pady=10)
        
        self.btn_select = ctk.CTkButton(self.step1_frame, text="📁 Seleccionar Excel (.xlsx)", 
                                        command=self._select_file)
        self.btn_select.pack(side="left", padx=5)
        
        self.lbl_file = ctk.CTkLabel(self.step1_frame, text="Ningún archivo seleccionado", text_color="gray")
        self.lbl_file.pack(side="left", padx=10)
        
        # Step 2: Summary (Initally hidden)
        self.step2_frame = ctk.CTkFrame(self)
        # We will pack this when file is loaded
        
        # Lower section: History
        self.history_frame = ctk.CTkFrame(self)
        self.history_frame.pack(fill="both", expand=True)
        
        ctk.CTkLabel(self.history_frame, text="📜 Historial de Cargas", 
                     font=ctk.CTkFont(size=16, weight="bold")).pack(pady=10)
        
        self.table_container = ctk.CTkFrame(self.history_frame, fg_color="transparent")
        self.table_container.pack(fill="both", expand=True, padx=10, pady=10)
        
        self.refresh_history()

    def _select_file(self):
        path = filedialog.askopenfilename(filetypes=[("Excel files", "*.xlsx")])
        if path:
            self.file_path = path
            self.lbl_file.configure(text=os.path.basename(path), text_color="white")
            self._process_file()

    def _process_file(self):
        try:
            self.df = read_and_process_file(self.file_path)
            summary_df = generate_summary(self.df)
            self._show_summary(summary_df)
        except Exception as e:
            messagebox.showerror("Error", f"Error al procesar el archivo:\n{str(e)}")

    def _show_summary(self, summary_df):
        # Clear previous summary if any
        for widget in self.step2_frame.winfo_children():
            widget.destroy()
            
        self.step2_frame.pack(fill="both", expand=True, before=self.history_frame, pady=10)
        
        ctk.CTkLabel(self.step2_frame, text="📊 Resumen de Carga (Previsualización)", 
                     font=ctk.CTkFont(weight="bold")).pack(pady=5)
        
        # Create table for summary
        cols = ["Equipo", "Tipo", "Subtipo", "Horas", "%"]
        table = TableFrame(self.step2_frame, cols)
        table.pack(fill="both", expand=True, padx=10, pady=5)
        
        for _, row in summary_df.iterrows():
            values = [
                row['Equipo'], row['Tipo'], row['Subtipo'], 
                f"{row['Horas']:.1f}", f"{row['Porcentaje']:.1f}%"
            ]
            table.add_row(values)
            
        # Action buttons
        btn_frame = ctk.CTkFrame(self.step2_frame, fg_color="transparent")
        btn_frame.pack(pady=10)
        
        ctk.CTkButton(btn_frame, text="✅ Confirmar y Cargar", fg_color="#27ae60", hover_color="#2ecc71",
                      command=self._confirm_load).pack(side="left", padx=10)
        ctk.CTkButton(btn_frame, text="❌ Cancelar", fg_color="#c0392b", hover_color="#e74c3c",
                      command=self._cancel_load).pack(side="left", padx=10)

    def _confirm_load(self):
        if messagebox.askyesno("Confirmar", "¿Deseas proceder con la carga masiva?"):
            try:
                apply_bulk_load(self.df, self.file_path)
                messagebox.showinfo("OK", "Carga completada con éxito.")
                self._cancel_load() # Reset UI
                self.refresh_history()
            except Exception as e:
                messagebox.showerror("Error", f"Error durante la carga:\n{str(e)}")

    def _cancel_load(self):
        self.file_path = None
        self.df = None
        self.lbl_file.configure(text="Ningún archivo seleccionado", text_color="gray")
        self.step2_frame.pack_forget()

    def refresh_history(self):
        for widget in self.table_container.winfo_children():
            widget.destroy()
            
        history = get_load_history(10)
        if not history:
            ctk.CTkLabel(self.table_container, text="No hay cargas registradas").pack(pady=20)
            return
            
        cols = ["ID", "Fecha", "Archivo", "Filas", "Horas", "Acciones"]
        table = TableFrame(self.table_container, cols)
        table.pack(fill="both", expand=True)
        
        for load in history:
            load_id = load['id']
            values = [
                str(load_id), load['timestamp'], load['filename'], 
                str(load['total_rows']), f"{load['total_hours']:.1f}", ""
            ]
            
            # Action button widget
            def make_del_btn(master, lid=load_id):
                return ctk.CTkButton(master, text="🗑️", width=30, fg_color="#c0392b",
                                     hover_color="#e74c3c", command=lambda: self._delete_load(lid))
            
            table.add_row(values, widgets={5: make_del_btn})
            
    def _delete_load(self, load_id):
        if messagebox.askyesno("Confirmar", f"¿Seguro que deseas eliminar la carga #{load_id}?\nSe borrarán todas las imputaciones asociadas."):
            try:
                rollback_load(load_id)
                messagebox.showinfo("OK", "Carga eliminada correctamente.")
                self.refresh_history()
            except Exception as e:
                messagebox.showerror("Error", f"Error al eliminar:\n{str(e)}")

import os # For os.path.basename in _select_file
