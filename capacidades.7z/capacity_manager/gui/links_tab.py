import customtkinter as ctk
from tkinter import messagebox
import webbrowser
import urllib.parse
from db.models.links import create_link, get_all_links, update_link, delete_link, search_links
from utils.gui_utils import TableFrame

class LinksTab(ctk.CTkFrame):
    def __init__(self, parent):
        super().__init__(parent)
        self.parent = parent
        self.current_link_id = None
        
        # --- TOP SECTION: Search & Form ---
        self.top_frame = ctk.CTkFrame(self)
        self.top_frame.pack(fill="x", padx=10, pady=10)
        
        # Search Sub-frame
        self.search_frame = ctk.CTkFrame(self.top_frame, fg_color="transparent")
        self.search_frame.pack(fill="x", pady=(0, 10))
        
        ctk.CTkLabel(self.search_frame, text="Buscar Enlaces:").pack(side="left", padx=5)
        self.search_entry = ctk.CTkEntry(self.search_frame, width=300, placeholder_text="Buscar por título...")
        self.search_entry.pack(side="left", padx=5)
        self.search_button = ctk.CTkButton(self.search_frame, text="Buscar", command=self._search_links, width=80)
        self.search_button.pack(side="left", padx=5)
        self.clear_search_btn = ctk.CTkButton(self.search_frame, text="Limpiar", command=self._clear_search, width=80, fg_color="gray")
        self.clear_search_btn.pack(side="left", padx=5)
        
        # Form Sub-frame
        self.form_frame = ctk.CTkFrame(self.top_frame)
        self.form_frame.pack(fill="x", pady=10, padx=5)
        
        ctk.CTkLabel(self.form_frame, text="Título:").grid(row=0, column=0, padx=5, pady=5, sticky="e")
        self.title_entry = ctk.CTkEntry(self.form_frame, width=400)
        self.title_entry.grid(row=0, column=1, padx=5, pady=5, sticky="w")
        
        ctk.CTkLabel(self.form_frame, text="URL:").grid(row=1, column=0, padx=5, pady=5, sticky="e")
        self.url_entry = ctk.CTkEntry(self.form_frame, width=400)
        self.url_entry.grid(row=1, column=1, padx=5, pady=5, sticky="w")
        
        self.btn_frame = ctk.CTkFrame(self.form_frame, fg_color="transparent")
        self.btn_frame.grid(row=2, column=1, pady=10, sticky="w")
        
        self.save_btn = ctk.CTkButton(self.btn_frame, text="Guardar Enlace", command=self._save_link)
        self.save_btn.pack(side="left", padx=5)
        
        self.cancel_btn = ctk.CTkButton(self.btn_frame, text="Cancelar Edición", command=self._clear_form, fg_color="gray")
        self.cancel_btn.pack(side="left", padx=5)
        self.cancel_btn.pack_forget() # Hide initially
        
        # --- BOTTOM SECTION: Table ---
        self.table_container = ctk.CTkFrame(self)
        self.table_container.pack(fill="both", expand=True, padx=10, pady=10)
        
        self.table = None
        self.refresh()

    def _save_link(self):
        title = self.title_entry.get().strip()
        url = self.url_entry.get().strip()
        
        if not title or not url:
            messagebox.showwarning("Aviso", "El título y la URL son obligatorios.")
            return
            
        # Validación de URL
        parsed = urllib.parse.urlparse(url)
        if not (parsed.scheme in ('http', 'https') and parsed.netloc):
            messagebox.showwarning("Aviso", "Por favor, introduce una URL válida con protocolo (ej. https://ejemplo.com).")
            return
            
        if self.current_link_id:
            update_link(self.current_link_id, title, url)
            messagebox.showinfo("Éxito", "Enlace actualizado correctamente.")
        else:
            create_link(title, url)
            messagebox.showinfo("Éxito", "Enlace creado correctamente.")
            
        self._clear_form()
        self.refresh()

    def _clear_form(self):
        self.current_link_id = None
        self.title_entry.delete(0, 'end')
        self.url_entry.delete(0, 'end')
        self.save_btn.configure(text="Guardar Enlace")
        self.cancel_btn.pack_forget()

    def _search_links(self):
        query = self.search_entry.get().strip()
        if query:
            links = search_links(query)
            self._display_links(links)
        else:
            self.refresh()
            
    def _clear_search(self):
        self.search_entry.delete(0, 'end')
        self.refresh()

    def refresh(self):
        """Loads all links from db and displays them."""
        links = get_all_links()
        self._display_links(links)

    def _display_links(self, links):
        if self.table:
            self.table.destroy()
            
        headers = ["ID", "Fecha", "Título", "URL"]
        self.table = TableFrame(self.table_container, headers=headers)
        self.table.pack(fill="both", expand=True)
        
        for l in links:
            date_str = ""
            if l['created_date']:
                date_part = l['created_date'][:10]
                if '-' in date_part:
                    y, m, d = date_part.split('-')
                    date_str = f"{d}-{m}-{y}"
                else:
                    date_str = date_part
                    
            row_data = [
                str(l['id']),
                date_str,
                l['title'],
                l['url']
            ]
            row_widgets = self.table.add_row(row_data)
            
            # Make URL clickable directly
            url_label = row_widgets[3]
            url_label.configure(text_color="#4da6ff", cursor="hand2", font=ctk.CTkFont(underline=True))
            url_label.bind("<Button-1>", lambda e, u=l['url']: webbrowser.open(u))
            
            # Add Action buttons
            # Note: the parent of the Action buttons could just be row_widgets[0].master (which is TableFrame) 
            # or we create a frame in row_widgets but TableFrame.add_row already packs things.
            # Here we just pass the master to CTkFrame
            btn_frame = ctk.CTkFrame(row_widgets[0].master, fg_color="transparent")
            btn_frame.grid(row=len(self.table.rows), column=4, padx=5, pady=2)
            
            edit_btn = ctk.CTkButton(btn_frame, text="✏️", width=30, command=lambda link=l: self._load_link_for_edit(link))
            edit_btn.pack(side="left", padx=2)
            
            del_btn = ctk.CTkButton(btn_frame, text="🗑️", width=30, fg_color="red", hover_color="#8b0000",
                                    command=lambda lid=l['id']: self._delete_link(lid))
            del_btn.pack(side="left", padx=2)

    def _load_link_for_edit(self, link):
        self._clear_form()
        self.current_link_id = link['id']
        self.title_entry.insert(0, link['title'])
        self.url_entry.insert(0, link['url'])
        self.save_btn.configure(text="Actualizar Enlace")
        self.cancel_btn.pack(side="left", padx=5)

    def _delete_link(self, link_id):
        if messagebox.askyesno("Confirmar", "¿Seguro que quieres borrar este enlace?"):
            delete_link(link_id)
            self.refresh()
