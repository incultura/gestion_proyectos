"""
gui/config_tab.py — Pestaña de configuración de parámetros generales.
"""
import customtkinter as ctk
from tkinter import messagebox
from db.models.config import get_all_configs, set_config, delete_config

class ConfigTab(ctk.CTkFrame):
    def __init__(self, master, **kwargs):
        super().__init__(master, **kwargs)
        self._build_ui()
        self.refresh()

    def _build_ui(self):
        self.grid_columnconfigure(0, weight=1)
        self.grid_rowconfigure(1, weight=1)

        # Título
        header = ctk.CTkFrame(self, fg_color="transparent")
        header.grid(row=0, column=0, sticky="ew", padx=20, pady=(20, 10))
        ctk.CTkLabel(header, text="⚙️ Configuración del Sistema", 
                     font=ctk.CTkFont(size=20, weight="bold")).pack(side="left")

        # Lista de parámetros
        self.scroll = ctk.CTkScrollableFrame(self)
        self.scroll.grid(row=1, column=0, sticky="nsew", padx=20, pady=10)
        self.scroll.grid_columnconfigure(1, weight=1)

        # Formulario para añadir nuevo
        footer = ctk.CTkFrame(self)
        footer.grid(row=2, column=0, sticky="ew", padx=20, pady=(10, 20))
        
        ctk.CTkLabel(footer, text="Nuevo Parámetro:").grid(row=0, column=0, padx=10, pady=10)
        self.key_entry = ctk.CTkEntry(footer, placeholder_text="Nombre (p.ej. base_url_solicitud)")
        self.key_entry.grid(row=0, column=1, padx=5, pady=10, sticky="ew")
        
        self.value_entry = ctk.CTkEntry(footer, placeholder_text="Valor")
        self.value_entry.grid(row=0, column=2, padx=5, pady=10, sticky="ew")
        
        ctk.CTkButton(footer, text="➕ Añadir", command=self._add_config, width=100).grid(row=0, column=3, padx=10, pady=10)
        footer.grid_columnconfigure(1, weight=1)
        footer.grid_columnconfigure(2, weight=2)

    def refresh(self):
        # Limpiar scroll
        for child in self.scroll.winfo_children():
            child.destroy()
        
        configs = get_all_configs()
        
        # Cabecera de tabla
        ctk.CTkLabel(self.scroll, text="Parámetro", font=ctk.CTkFont(weight="bold")).grid(row=0, column=0, padx=10, pady=5, sticky="w")
        ctk.CTkLabel(self.scroll, text="Valor", font=ctk.CTkFont(weight="bold")).grid(row=0, column=1, padx=10, pady=5, sticky="ew")
        ctk.CTkLabel(self.scroll, text="Acciones", font=ctk.CTkFont(weight="bold")).grid(row=0, column=2, padx=10, pady=5)

        for i, cfg in enumerate(configs, 1):
            key = cfg["key"]
            val = cfg["value"]
            
            ctk.CTkLabel(self.scroll, text=key).grid(row=i, column=0, padx=10, pady=2, sticky="w")
            
            # Entry para editar directamente
            v_var = ctk.StringVar(value=val)
            entry = ctk.CTkEntry(self.scroll, textvariable=v_var)
            entry.grid(row=i, column=1, padx=10, pady=2, sticky="ew")
            
            # Botones
            btn_row = ctk.CTkFrame(self.scroll, fg_color="transparent")
            btn_row.grid(row=i, column=2, padx=10, pady=2)
            
            ctk.CTkButton(btn_row, text="💾", width=30, 
                          command=lambda k=key, v=v_var: self._update_config(k, v.get())).pack(side="left", padx=2)
            ctk.CTkButton(btn_row, text="🗑", width=30, fg_color="#c0392b", hover_color="#922b21",
                          command=lambda k=key: self._delete_config(k)).pack(side="left", padx=2)

    def _add_config(self):
        k = self.key_entry.get().strip()
        v = self.value_entry.get().strip()
        if not k:
            messagebox.showwarning("Error", "El nombre del parámetro es obligatorio")
            return
        set_config(k, v)
        self.key_entry.delete(0, 'end')
        self.value_entry.delete(0, 'end')
        self.refresh()

    def _update_config(self, key, val):
        set_config(key, val)
        messagebox.showinfo("Éxito", f"Parámetro '{key}' actualizado")
        self.refresh()

    def _delete_config(self, key):
        if messagebox.askyesno("Confirmar", f"¿Eliminar el parámetro '{key}'?"):
            delete_config(key)
            self.refresh()
