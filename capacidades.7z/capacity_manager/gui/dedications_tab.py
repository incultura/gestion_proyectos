"""
gui/dedications_tab.py — Asignación de equipos a proyectos.
Muestra el nombre del equipo; internamente usa team_id (INTEGER).
"""
import customtkinter as ctk
from tkinter import messagebox
from db.models.projects import get_all_projects
from db.models.teams import get_all_teams
from db.models.project_teams import (
    get_dedications_by_project, create_dedication,
    update_dedication, delete_dedication,
    get_imputed_hours
)
from db.models.statuses import get_all_statuses, get_status_id_by_name
from utils.date_utils import gui_to_db, db_to_gui
from utils.gui_utils import Tooltip, DateEntry


class DedicationsTab(ctk.CTkFrame):
    def __init__(self, master, **kwargs):
        super().__init__(master, **kwargs)
        self.selected_project_id = None
        self.selected_dedication_id = None
        self.proj_buttons = {} # Para resaltar selección proyectos
        self.ded_buttons = {}  # Para resaltar selección dedicaciones
        # Mapas para conversión nombre ↔ id
        self._team_name_to_id = {}
        self._team_id_to_name = {}
        self._build_ui()
        self.refresh_projects()

    def _build_ui(self):
        self.grid_columnconfigure(0, weight=1)
        self.grid_columnconfigure(1, weight=1)
        self.grid_columnconfigure(2, weight=2)
        self.grid_rowconfigure(0, weight=1)

        # ── Columna 1: Proyectos ───────────────────────────────────────
        col1 = ctk.CTkFrame(self)
        col1.grid(row=0, column=0, sticky="nsew", padx=(10, 4), pady=10)
        col1.grid_rowconfigure(1, weight=1)
        col1.grid_columnconfigure(0, weight=1)
        ctk.CTkLabel(col1, text="Proyectos", font=ctk.CTkFont(size=14, weight="bold")).grid(
            row=0, column=0, sticky="w", padx=8, pady=(8, 4))
        self.proj_frame = ctk.CTkScrollableFrame(col1)
        self.proj_frame.grid(row=1, column=0, sticky="nsew", padx=4, pady=4)
        self.proj_frame.grid_columnconfigure(0, weight=1)

        # Filtros y Búsqueda
        filter_frame = ctk.CTkFrame(col1, fg_color="transparent")
        filter_frame.grid(row=2, column=0, sticky="ew", padx=8, pady=2)
        
        self.search_var = ctk.StringVar()
        self.search_var.trace_add("write", lambda *args: self.refresh_projects_list())
        
        search_row = ctk.CTkFrame(filter_frame, fg_color="transparent")
        search_row.pack(fill="x", pady=(2, 5))
        
        self.search_entry = ctk.CTkEntry(search_row, placeholder_text="🔍 Buscar...", textvariable=self.search_var)
        self.search_entry.pack(side="left", fill="x", expand=True)
        
        ctk.CTkButton(search_row, text="🧹", width=30, command=lambda: self.search_var.set("")).pack(side="left", padx=(5, 0))

        self.show_finished = ctk.BooleanVar(value=False)
        self.show_discarded = ctk.BooleanVar(value=False)
        self.show_stopped = ctk.BooleanVar(value=False)

        checks = ctk.CTkFrame(filter_frame, fg_color="transparent")
        checks.pack(fill="x")
        ctk.CTkCheckBox(checks, text="Fin.", variable=self.show_finished, command=self.refresh_projects_list, 
                        font=ctk.CTkFont(size=10), width=50).pack(side="left", padx=1)
        ctk.CTkCheckBox(checks, text="Desc.", variable=self.show_discarded, command=self.refresh_projects_list, 
                        font=ctk.CTkFont(size=10), width=50).pack(side="left", padx=1)
        ctk.CTkCheckBox(checks, text="Det.", variable=self.show_stopped, command=self.refresh_projects_list, 
                        font=ctk.CTkFont(size=10), width=50).pack(side="left", padx=1)

        # ── Columna 2: Dedicaciones del proyecto ───────────────────────
        col2 = ctk.CTkFrame(self)
        col2.grid(row=0, column=1, sticky="nsew", padx=4, pady=10)
        col2.grid_rowconfigure(1, weight=1)
        col2.grid_columnconfigure(0, weight=1)
        ctk.CTkLabel(col2, text="Equipos asignados", font=ctk.CTkFont(size=14, weight="bold")).grid(
            row=0, column=0, sticky="w", padx=8, pady=(8, 4))
        self.ded_frame = ctk.CTkScrollableFrame(col2)
        self.ded_frame.grid(row=1, column=0, sticky="nsew", padx=4, pady=4)
        self.ded_frame.grid_columnconfigure(0, weight=1)
        ded_btns = ctk.CTkFrame(col2, fg_color="transparent")
        ded_btns.grid(row=2, column=0, sticky="ew", padx=4, pady=4)
        ctk.CTkButton(ded_btns, text="＋ Asignar equipo", command=self._new_dedication).pack(side="left", padx=3)
        ctk.CTkButton(ded_btns, text="🗑", fg_color="#c0392b", hover_color="#922b21",
                      command=self._delete_dedication, width=40).pack(side="left", padx=3)

        # ── Columna 3: Detalle dedicación ──────────────────────────────
        col3 = ctk.CTkFrame(self)
        col3.grid(row=0, column=2, sticky="nsew", padx=(4, 10), pady=10)
        col3.grid_columnconfigure(1, weight=1)

        ctk.CTkLabel(col3, text="Detalle de Dedicación",
                     font=ctk.CTkFont(size=14, weight="bold")).grid(
            row=0, column=0, columnspan=2, sticky="w", padx=15, pady=(15, 2))
        
        self.lbl_selected_project = ctk.CTkLabel(col3, text="Selecciona un proyecto", 
                                                text_color="#3498db", font=ctk.CTkFont(size=12, slant="italic"))
        self.lbl_selected_project.grid(row=1, column=0, columnspan=2, sticky="w", padx=15, pady=(0, 10))

        ctk.CTkLabel(col3, text="Equipo").grid(row=2, column=0, sticky="w", padx=12, pady=4)
        self.team_var = ctk.StringVar()
        self.team_menu = ctk.CTkOptionMenu(col3, variable=self.team_var, values=["—"])
        self.team_menu.grid(row=2, column=1, sticky="ew", padx=(4, 12), pady=4)

        ctk.CTkLabel(col3, text="Estado").grid(row=3, column=0, sticky="w", padx=12, pady=4)
        self.status_var = ctk.StringVar()
        self.status_menu = ctk.CTkOptionMenu(col3, variable=self.status_var, values=["—"])
        self.status_menu.grid(row=3, column=1, sticky="ew", padx=(4, 12), pady=4)

        ctk.CTkLabel(col3, text="Fecha inicio").grid(row=4, column=0, sticky="w", padx=12, pady=4)
        self.start_entry = DateEntry(col3, placeholder_text="DD-MM-YYYY")
        self.start_entry.grid(row=4, column=1, sticky="ew", padx=(4, 12), pady=4)

        ctk.CTkLabel(col3, text="Fecha fin").grid(row=5, column=0, sticky="w", padx=12, pady=4)
        self.end_entry = DateEntry(col3, placeholder_text="DD-MM-YYYY")
        self.end_entry.grid(row=5, column=1, sticky="ew", padx=(4, 12), pady=4)

        ctk.CTkLabel(col3, text="Horas estimadas").grid(row=6, column=0, sticky="w", padx=12, pady=4)
        self.est_hours_entry = ctk.CTkEntry(col3)
        self.est_hours_entry.grid(row=6, column=1, sticky="ew", padx=(4, 12), pady=4)

        ctk.CTkLabel(col3, text="ID Proyecto").grid(row=7, column=0, sticky="w", padx=12, pady=4)
        self.id_proj_entry = ctk.CTkEntry(col3)
        self.id_proj_entry.grid(row=7, column=1, sticky="ew", padx=(4, 12), pady=4)

        ctk.CTkLabel(col3, text="Horas imputadas").grid(row=8, column=0, sticky="w", padx=12, pady=4)
        self.lbl_imputed = ctk.CTkLabel(col3, text="—")
        self.lbl_imputed.grid(row=8, column=1, sticky="w", padx=(4, 12), pady=4)

        ctk.CTkLabel(col3, text="Horas restantes").grid(row=9, column=0, sticky="w", padx=12, pady=4)
        self.lbl_remaining = ctk.CTkLabel(col3, text="—", font=ctk.CTkFont(weight="bold"))
        self.lbl_remaining.grid(row=9, column=1, sticky="w", padx=(4, 12), pady=4)

        ctk.CTkButton(col3, text="💾 Guardar", command=self._save_dedication).grid(
            row=10, column=0, columnspan=2, pady=15)

    def refresh_projects(self):
        self.projects_raw = get_all_projects()
        
        # Actualizar dropdown de equipos
        teams = get_all_teams()
        self._team_name_to_id = {t["name"]: t["id"] for t in teams}
        self._team_id_to_name = {t["id"]: t["name"] for t in teams}
        names = [t["name"] for t in teams] or ["—"]
        self.team_menu.configure(values=names)
        if names:
            self.team_var.set(names[0])

        # Actualizar dropdown de estados
        self.statuses_list = get_all_statuses()
        status_names = [s["name"] for s in self.statuses_list]
        self.status_menu.configure(values=status_names)
        if not self.status_var.get() and status_names:
            self.status_var.set(status_names[0])
            
        self.refresh_projects_list()

    def refresh_projects_list(self):
        for w in self.proj_frame.winfo_children():
            w.destroy()
        self.proj_buttons = {} # Limpiar mapa
        
        search_text = self.search_var.get().lower()
        
        filtered = []
        for proj in self.projects_raw:
            status = proj.get("status_name", "Idea")
            
            # Filtro por estado
            if status == "Finalizado" and not self.show_finished.get(): continue
            if status == "Descartado" and not self.show_discarded.get(): continue
            if status == "Detenido" and not self.show_stopped.get(): continue
            
            # Filtro por búsqueda
            if search_text and search_text not in proj["title"].lower():
                continue
                
            filtered.append(proj)

            # Truncado estricto para asegurar que la tipología siempre se vea (38 chars total)
            prefix = f"[{proj['typology']}] "
            max_total = 38
            max_title = max_total - len(prefix)
            
            display_title = proj['title']
            if len(display_title) > max_title:
                display_title = display_title[:max_title-3] + "..."
            lbl = prefix + display_title
            
            btn = ctk.CTkButton(
                self.proj_frame, text=lbl, anchor="w",
                fg_color="transparent", text_color=("black", "white"),
                hover_color=("gray80", "gray30"),
                font=ctk.CTkFont(size=12),
                command=lambda p=proj["id"]: self._select_project(p)
            )
            btn.grid(sticky="ew", pady=1, padx=2)
            self.proj_buttons[proj["id"]] = btn
            
            # Tooltip
            Tooltip(btn, proj["title"])
            
        # Restaurar resaltado
        if self.selected_project_id:
            self._highlight_selection(self.selected_project_id)

    def _select_project(self, project_id):
        self.selected_project_id = project_id
        self._highlight_selection(project_id)
        self.selected_dedication_id = None
        
        proj = next((p for p in self.projects_raw if p["id"] == project_id), None)
        if proj:
            self.lbl_selected_project.configure(text=f"Proyecto: {proj['title']}")
        
        self._refresh_dedications()
        self._clear_form()

    def _highlight_selection(self, project_id):
        # Restablecer todos
        for pid, btn in self.proj_buttons.items():
            btn.configure(fg_color="transparent")
        
        # Resaltar seleccinado
        if project_id in self.proj_buttons:
            self.proj_buttons[project_id].configure(fg_color="#34495e")

    def _refresh_dedications(self):
        for w in self.ded_frame.winfo_children():
            w.destroy()
        self.ded_buttons = {} # Limpiar mapa
        if not self.selected_project_id:
            return
        self.dedications = get_dedications_by_project(self.selected_project_id)
        for ded in self.dedications:
            team_name = ded.get("team_name", str(ded["team_id"]))
            status_name = ded.get("status_name", "Idea")
            lbl = f"{team_name}  |  {status_name}"
            btn = ctk.CTkButton(
                self.ded_frame, text=lbl, anchor="w",
                fg_color="transparent", text_color=("black", "white"),
                hover_color=("gray80", "gray30"),
                command=lambda d=ded["id"]: self._select_dedication(d)
            )
            btn.grid(sticky="ew", pady=1)
            self.ded_buttons[ded["id"]] = btn
            Tooltip(btn, lbl) # Tooltip con equipo y estado
            
        # Restaurar resaltado si aplica
        if self.selected_dedication_id:
            self._highlight_ded_selection(self.selected_dedication_id)

    def _select_dedication(self, ded_id):
        self.selected_dedication_id = ded_id
        self._highlight_ded_selection(ded_id)
        ded = next((d for d in self.dedications if d["id"] == ded_id), None)
        if not ded:
            return
        team_name = ded.get("team_name", "")
        self.team_var.set(team_name)
        self.team_menu.configure(state="disabled")
        self.status_var.set(ded.get("status_name", "Idea"))
        self.start_entry.delete(0, "end")
        self.start_entry.insert(0, db_to_gui(ded["start_date"]) if ded["start_date"] else "")
        self.end_entry.delete(0, "end")
        self.end_entry.insert(0, db_to_gui(ded["end_date"]) if ded["end_date"] else "")
        self.est_hours_entry.delete(0, "end")
        self.est_hours_entry.insert(0, str(ded["estimated_hours"]))
        self.id_proj_entry.delete(0, "end")
        self.id_proj_entry.insert(0, str(ded.get("id_proyecto", 0)))
        imputed = get_imputed_hours(ded_id)
        remaining = max(0.0, ded["estimated_hours"] - imputed)
        self.lbl_imputed.configure(text=f"{imputed:.1f} h")
        self.lbl_remaining.configure(text=f"{remaining:.1f} h")

    def _new_dedication(self):
        if not self.selected_project_id:
            messagebox.showwarning("Aviso", "Selecciona un proyecto primero.")
            return
        self.selected_dedication_id = None
        self.team_menu.configure(state="normal")
        self._clear_form()

    def _clear_form(self):
        if hasattr(self, "statuses_list") and self.statuses_list:
            self.status_var.set(self.statuses_list[0]["name"])
        else:
            self.status_var.set("—")
        self.start_entry.delete(0, "end")
        self.end_entry.delete(0, "end")
        self.est_hours_entry.delete(0, "end")
        self.id_proj_entry.delete(0, "end")
        self.id_proj_entry.insert(0, "0")
        self.lbl_imputed.configure(text="—")
        self.lbl_remaining.configure(text="—")
        self.team_menu.configure(state="normal")

    def _save_dedication(self):
        if not self.selected_project_id:
            messagebox.showwarning("Aviso", "Selecciona un proyecto.")
            return
        team_name = self.team_var.get()
        team_id = self._team_name_to_id.get(team_name)
        if not team_id:
            messagebox.showerror("Error", "Selecciona un equipo válido.")
            return
        try:
            est = float(self.est_hours_entry.get() or 0)
        except ValueError:
            messagebox.showerror("Error", "Las horas estimadas deben ser un número.")
            return

        try:
            id_proj_str = self.id_proj_entry.get().strip() or "0"
            id_proyecto = int(id_proj_str)
        except ValueError:
            messagebox.showerror("Error", "El ID Proyecto debe ser un número entero.")
            return

        status_name = self.status_var.get()
        if status_name in ["En desarrollo", "Finalizado", "Detenido"]:
            if id_proyecto <= 0:
                messagebox.showerror("Error", f"Para mover la dedicación a '{status_name}' se requiere un ID Proyecto válido (> 0).")
                return
            
            start_date_str = self.start_entry.get().strip()
            end_date_str = self.end_entry.get().strip()
            
            if not start_date_str or not end_date_str:
                messagebox.showerror("Error", f"El estado '{status_name}' requiere Fecha Inicio y Fecha Fin.")
                return
                
            if est <= 0:
                messagebox.showerror("Error", f"El estado '{status_name}' requiere más de 0 Horas Estimadas.")
                return


        status_id = get_status_id_by_name(self.status_var.get())
        
        data = {
            "project_id": self.selected_project_id,
            "team_id": team_id,
            "status_id": status_id,
            "start_date": gui_to_db(self.start_entry.get().strip()),
            "end_date": gui_to_db(self.end_entry.get().strip()),
            "estimated_hours": est,
            "id_proyecto": id_proyecto,
        }
        try:
            if self.selected_dedication_id:
                update_dedication(self.selected_dedication_id, data)
            else:
                self.selected_dedication_id = create_dedication(data)
        except Exception as e:
            if "UNIQUE" in str(e):
                messagebox.showerror("Error", "Este equipo ya está asignado a este proyecto.")
            else:
                messagebox.showerror("Error", str(e))
            return
        self._refresh_dedications()
        messagebox.showinfo("OK", "Dedicación guardada.")

    def _delete_dedication(self):
        if not self.selected_dedication_id:
            messagebox.showwarning("Aviso", "Selecciona una dedicación.")
            return
        if messagebox.askyesno("Confirmar", "¿Borrar esta dedicación y sus imputaciones?"):
            delete_dedication(self.selected_dedication_id)
            self.selected_dedication_id = None
            self._clear_form()
            self._refresh_dedications()

    def _highlight_ded_selection(self, ded_id):
        # Resaltar la dedicación seleccionada (lista central)
        for did, btn in self.ded_buttons.items():
            btn.configure(fg_color="transparent")
        
        if ded_id in self.ded_buttons:
            self.ded_buttons[ded_id].configure(fg_color="#34495e")
