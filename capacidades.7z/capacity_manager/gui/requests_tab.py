"""
gui/requests_tab.py — Inventario de solicitudes (antes proyectos) con título obligatorio y único.
"""
import customtkinter as ctk
from tkinter import messagebox
import webbrowser
from datetime import date
from db.models.solicitudes import get_all_solicitudes, create_solicitud, update_solicitud, delete_solicitud, TYPOLOGIES
from db.models.annotations import get_annotations_by_solicitud, create_annotation, delete_annotation
from db.models.statuses import get_all_statuses, get_status_id_by_name
from db.models.dependencies import get_all_dependencies
from db.models.deliverables import get_deliverables_by_solicitud, add_deliverable, delete_deliverable
from db.models.config import get_config
from utils.date_utils import get_today_gui, db_to_gui, gui_to_db
from logic.report_logic import generate_solicitud_pdf
import os
from tkinter import filedialog
from utils.gui_utils import Tooltip, DateEntry


class RequestsTab(ctk.CTkFrame):
    def __init__(self, master, **kwargs):
        super().__init__(master, **kwargs)
        self.selected_solicitud_id = None
        self.annotations = []
        self.sol_buttons = {}  # Para resaltar selección
        self._build_ui()
        self.refresh()

    def _build_ui(self):
        self.grid_columnconfigure(0, weight=1)
        self.grid_columnconfigure(1, weight=1)
        self.grid_columnconfigure(2, weight=1)
        self.grid_rowconfigure(0, weight=1)

        # ── Lista ──────────────────────────────────────────────────────
        left = ctk.CTkFrame(self)
        left.grid(row=0, column=0, sticky="nsew", padx=(10, 5), pady=10)
        left.grid_rowconfigure(1, weight=1)
        left.grid_columnconfigure(0, weight=1)

        ctk.CTkLabel(left, text="Solicitudes", font=ctk.CTkFont(size=16, weight="bold")).grid(
            row=0, column=0, sticky="w", padx=10, pady=(10, 5))

        self.list_frame = ctk.CTkScrollableFrame(left)
        self.list_frame.grid(row=1, column=0, sticky="nsew", padx=5, pady=5)
        self.list_frame.grid_columnconfigure(0, weight=1)

        # Filtros y Búsqueda
        filter_frame = ctk.CTkFrame(left, fg_color="transparent")
        filter_frame.grid(row=2, column=0, sticky="ew", padx=10, pady=2)
        
        self.search_var = ctk.StringVar()
        self.search_var.trace_add("write", lambda *args: self.refresh_list())
        
        search_row = ctk.CTkFrame(filter_frame, fg_color="transparent")
        search_row.pack(fill="x", pady=(2, 5))
        
        self.search_entry = ctk.CTkEntry(search_row, placeholder_text="🔍 Buscar solicitud...", textvariable=self.search_var)
        self.search_entry.pack(side="left", fill="x", expand=True)
        
        ctk.CTkButton(search_row, text="🧹", width=30, command=lambda: self.search_var.set("")).pack(side="left", padx=(5, 0))

        check_row = ctk.CTkFrame(filter_frame, fg_color="transparent")
        check_row.pack(fill="x")
        
        self.show_finished = ctk.BooleanVar(value=False)
        self.show_discarded = ctk.BooleanVar(value=False)
        self.show_stopped = ctk.BooleanVar(value=False)
        self.show_no_id = ctk.BooleanVar(value=False)

        ctk.CTkCheckBox(check_row, text="Finalizado", variable=self.show_finished, command=self.refresh_list, 
                        font=ctk.CTkFont(size=10), width=80).pack(side="left", padx=1)
        ctk.CTkCheckBox(check_row, text="Descartado", variable=self.show_discarded, command=self.refresh_list, 
                        font=ctk.CTkFont(size=10), width=80).pack(side="left", padx=1)
        ctk.CTkCheckBox(check_row, text="Detenido", variable=self.show_stopped, command=self.refresh_list, 
                        font=ctk.CTkFont(size=10), width=70).pack(side="left", padx=1)
        ctk.CTkCheckBox(check_row, text="Sin ID", variable=self.show_no_id, command=self.refresh_list, 
                        font=ctk.CTkFont(size=10), width=60).pack(side="left", padx=1)

        btn_row = ctk.CTkFrame(left, fg_color="transparent")
        btn_row.grid(row=3, column=0, sticky="ew", padx=5, pady=5)
        ctk.CTkButton(btn_row, text="＋ Nueva", command=self._new_solicitud, width=100).pack(side="left", padx=3)
        ctk.CTkButton(btn_row, text="🗑 Borrar", fg_color="#c0392b", hover_color="#922b21",
                      command=self._delete_solicitud, width=100).pack(side="left", padx=3)

        # ── Formulario ─────────────────────────────────────────────────
        right = ctk.CTkFrame(self)
        right.grid(row=0, column=1, sticky="nsew", padx=(5, 10), pady=10)
        right.grid_columnconfigure(1, weight=1)

        ctk.CTkLabel(right, text="Detalle de la Solicitud",
                     font=ctk.CTkFont(size=16, weight="bold")).grid(
            row=0, column=0, columnspan=2, sticky="w", padx=15, pady=(15, 10))

        # Título
        ctk.CTkLabel(right, text="Título *").grid(row=1, column=0, sticky="w", padx=15, pady=4)
        self.title_entry = ctk.CTkEntry(right)
        self.title_entry.grid(row=1, column=1, sticky="ew", padx=(5, 15), pady=4)

        # Tipología
        ctk.CTkLabel(right, text="Tipología").grid(row=2, column=0, sticky="w", padx=15, pady=4)
        self.typology_var = ctk.StringVar(value=TYPOLOGIES[0])
        self.typology_var.trace_add("write", self._on_typology_change)
        self.typology_menu = ctk.CTkOptionMenu(right, values=TYPOLOGIES, variable=self.typology_var)
        self.typology_menu.grid(row=2, column=1, sticky="ew", padx=(5, 15), pady=4)

        # Descripción
        ctk.CTkLabel(right, text="Descripción").grid(row=3, column=0, sticky="nw", padx=15, pady=4)
        self.desc_text = ctk.CTkTextbox(right, height=100)
        self.desc_text.grid(row=3, column=1, sticky="ew", padx=(5, 15), pady=4)

        # ID Solicitud
        ctk.CTkLabel(right, text="ID Solicitud").grid(row=4, column=0, sticky="w", padx=15, pady=4)
        id_sol_frame = ctk.CTkFrame(right, fg_color="transparent")
        id_sol_frame.grid(row=4, column=1, sticky="ew", padx=(5, 15), pady=4)
        id_sol_frame.grid_columnconfigure(0, weight=1)
        
        self.id_sol_entry = ctk.CTkEntry(id_sol_frame)
        self.id_sol_entry.grid(row=0, column=0, sticky="ew")
        
        self.btn_link_sol = ctk.CTkButton(id_sol_frame, text="🔗 SOL", width=60,
                                         command=self._open_sol_link, fg_color="#2980b9")
        self.btn_link_sol.grid(row=0, column=1, padx=(4, 0))

        # Estado
        ctk.CTkLabel(right, text="Estado").grid(row=6, column=0, sticky="w", padx=15, pady=4)
        self.status_var = ctk.StringVar()
        self.status_menu = ctk.CTkOptionMenu(right, variable=self.status_var, values=["—"], command=self._on_status_change)
        self.status_menu.grid(row=6, column=1, sticky="ew", padx=(5, 15), pady=4)

        # Fechas de Seguimiento
        dates_frame = ctk.CTkFrame(right, fg_color="transparent")
        dates_frame.grid(row=7, column=0, columnspan=2, sticky="ew", padx=15, pady=5)
        dates_frame.grid_columnconfigure((1, 3, 5), weight=1)

        ctk.CTkLabel(dates_frame, text="Inicio").grid(row=0, column=0, padx=(0, 5))
        self.start_date_entry = DateEntry(dates_frame, width=100)
        self.start_date_entry.grid(row=0, column=1, sticky="ew", padx=2)

        ctk.CTkLabel(dates_frame, text="Fin").grid(row=0, column=2, padx=(10, 5))
        self.end_date_entry = DateEntry(dates_frame, width=100)
        self.end_date_entry.grid(row=0, column=3, sticky="ew", padx=2)

        ctk.CTkLabel(dates_frame, text="Detención").grid(row=0, column=4, padx=(10, 5))
        self.detention_date_entry = DateEntry(dates_frame, width=100)
        self.detention_date_entry.grid(row=0, column=5, sticky="ew", padx=2)

        button_frame = ctk.CTkFrame(right, fg_color="transparent")
        button_frame.grid(row=8, column=0, columnspan=2, pady=15)
        
        ctk.CTkButton(button_frame, text="💾 Guardar Solicitud", command=self._save).pack(side="left", padx=5)
        self.btn_report = ctk.CTkButton(button_frame, text="📄 Informe PDF", fg_color="#27ae60", 
                                        hover_color="#1e8449", command=self._export_pdf, state="disabled")
        self.btn_report.pack(side="left", padx=5)

        # ── Anotaciones (Nueva Columna) ──────────────────────────────
        annot_frame = ctk.CTkFrame(self)
        annot_frame.grid(row=0, column=2, sticky="nsew", padx=(5, 10), pady=10)
        annot_frame.grid_rowconfigure(1, weight=3) # Anotaciones
        annot_frame.grid_rowconfigure(3, weight=2) # Entregables
        annot_frame.grid_columnconfigure(0, weight=1)

        ctk.CTkLabel(annot_frame, text="Anotaciones", font=ctk.CTkFont(size=14, weight="bold")).grid(
            row=0, column=0, pady=(10, 5))

        self.annot_list = ctk.CTkScrollableFrame(annot_frame)
        self.annot_list.grid(row=1, column=0, sticky="nsew", padx=5, pady=5)
        self.annot_list.grid_columnconfigure(0, weight=1)

        # Input de nueva anotación
        add_frame = ctk.CTkFrame(annot_frame, fg_color="transparent")
        add_frame.grid(row=2, column=0, sticky="ew", padx=5, pady=5)
        
        self.annot_entry = ctk.CTkEntry(add_frame, placeholder_text="Nueva nota...", font=ctk.CTkFont(size=12))
        self.annot_entry.pack(side="left", fill="x", expand=True, padx=(0, 5))
        
        self.btn_add_annot = ctk.CTkButton(add_frame, text="➕", width=30, command=self._add_annotation, state="disabled")
        self.btn_add_annot.pack(side="right")

        # ── Entregables (Solo PIPE) ──────────────────────────────
        self.deliv_frame = ctk.CTkFrame(annot_frame)
        self.deliv_frame.grid(row=4, column=0, sticky="nsew", padx=5, pady=(10, 5))
        self.deliv_frame.grid_rowconfigure(1, weight=1)
        self.deliv_frame.grid_columnconfigure(0, weight=1)

        ctk.CTkLabel(self.deliv_frame, text="Entregables (PIPE)", font=ctk.CTkFont(size=14, weight="bold")).grid(
            row=0, column=0, pady=(5, 2))

        self.deliv_list = ctk.CTkScrollableFrame(self.deliv_frame, height=120)
        self.deliv_list.grid(row=1, column=0, sticky="nsew", padx=5, pady=2)
        self.deliv_list.grid_columnconfigure(0, weight=1)

        add_deliv_row = ctk.CTkFrame(self.deliv_frame, fg_color="transparent")
        add_deliv_row.grid(row=2, column=0, sticky="ew", padx=5, pady=5)
        
        self.deliv_entry = ctk.CTkEntry(add_deliv_row, placeholder_text="Nuevo entregable...")
        self.deliv_entry.pack(side="left", fill="x", expand=True, padx=(0, 5))
        
        self.btn_add_deliv = ctk.CTkButton(add_deliv_row, text="➕", width=30, command=self._add_deliverable, state="disabled")
        self.btn_add_deliv.pack(side="right")

    def refresh(self):
        self.solicitudes_raw = get_all_solicitudes()
        
        # Cargar estados para los dropdowns
        self.statuses_list = get_all_statuses()
        status_names = [s["name"] for s in self.statuses_list]
        self.status_menu.configure(values=status_names)
        if not self.status_var.get() and status_names:
            self.status_var.set(status_names[0])
            
        self.refresh_list()

    def _clear_list(self):
        for w in self.list_frame.winfo_children():
            w.destroy()
        self.sol_buttons = {} # Limpiar mapa de botones

    def refresh_list(self):
        self._clear_list()
        
        search_text = self.search_var.get().lower()
        
        # Filtrar solicitudes
        filtered = []
        for sol in self.solicitudes_raw:
            status = sol.get("status_name", "Idea")
            
            # Filtro por estado
            if status == "Finalizado" and not self.show_finished.get(): continue
            if status == "Descartado" and not self.show_discarded.get(): continue
            if status == "Detenido" and not self.show_stopped.get(): continue
            
            # Filtro "Sin ID Solicitud"
            if self.show_no_id.get():
                if sol.get("id_solicitud", 0) != 0:
                    continue
            
            # Filtro por búsqueda: título O id_solicitud
            if search_text:
                title_match = search_text in sol["title"].lower()
                id_sol = str(sol.get("id_solicitud", 0))
                id_sol_match = (sol.get("id_solicitud", 0) > 0 and search_text in id_sol)
                if not title_match and not id_sol_match:
                    continue
            
            filtered.append(sol)

        TYPOLOGY_COLORS = {
            "Operacion": "#1a5276",
            "PIPE": "#145a32",
            "Regulatorio": "#6e2f1a",
            "TTM": "#4a235a",
        }
        for sol in filtered:
            color = TYPOLOGY_COLORS.get(sol["typology"], "#333")
            
            id_sol = sol.get("id_solicitud", 0)
            id_str = f"#{id_sol} " if id_sol > 0 else ""
            prefix = f"[{sol['typology']}] {id_str}"
            max_total = 38
            max_title = max_total - len(prefix)
            
            display_title = sol['title']
            if len(display_title) > max_title:
                display_title = display_title[:max_title-3] + "..."
            label = prefix + display_title
            
            btn = ctk.CTkButton(
                self.list_frame, text=label, anchor="w",
                fg_color=color, hover_color="gray40",
                text_color="white",
                font=ctk.CTkFont(size=12, weight="bold" if id_sol > 0 else "normal"),
                command=lambda s=sol["id"]: self._select_solicitud(s)
            )
            btn.grid(sticky="ew", pady=2, padx=2)
            self.sol_buttons[sol["id"]] = btn
            
            Tooltip(btn, sol["title"])

        # Restaurar resaltado si hay algo seleccionado
        if self.selected_solicitud_id:
            self._highlight_selection(self.selected_solicitud_id)

    def _select_solicitud(self, solicitud_id):
        self.selected_solicitud_id = solicitud_id
        self._highlight_selection(solicitud_id)
        sol = next((s for s in self.solicitudes_raw if s["id"] == solicitud_id), None)
        if not sol:
            return
        self.title_entry.delete(0, "end")
        self.title_entry.insert(0, sol["title"])
        self.typology_var.set(sol["typology"])
        self.desc_text.delete("1.0", "end")
        self.desc_text.insert("1.0", sol["description"])
        self.id_sol_entry.delete(0, "end")
        self.id_sol_entry.insert(0, str(sol.get("id_solicitud", 0)))
        self.status_var.set(sol.get("status_name", "Idea"))
        
        if sol["typology"] == "PIPE":
            self.deliv_frame.grid()
        else:
            self.deliv_frame.grid_remove()

        # Cargar fechas
        self.btn_report.configure(state="normal")
        self.btn_add_annot.configure(state="normal")
        self.btn_add_deliv.configure(state="normal")
        
        self._refresh_annotations()
        self._refresh_deliverables()

    def _highlight_selection(self, solicitud_id):
        for sid, btn in self.sol_buttons.items():
            btn.configure(border_width=0)
        if solicitud_id in self.sol_buttons:
            self.sol_buttons[solicitud_id].configure(border_width=2, border_color="white")

    def _on_status_change(self, new_status):
        today = get_today_gui()
        if new_status in ["Finalizado", "Descartado"]:
            if not self.end_date_entry.get():
                self.end_date_entry.insert(0, today)
        elif new_status == "Detenido":
            if not self.detention_date_entry.get():
                self.detention_date_entry.insert(0, today)

    def _refresh_annotations(self):
        for w in self.annot_list.winfo_children():
            w.destroy()
        if not self.selected_solicitud_id:
            return
        self.annotations = get_annotations_by_solicitud(self.selected_solicitud_id)
        for a in self.annotations:
            card = ctk.CTkFrame(self.annot_list, fg_color=("gray90", "gray20"))
            card.pack(fill="x", pady=2, padx=2)
            header = ctk.CTkFrame(card, fg_color="transparent")
            header.pack(fill="x", padx=5, pady=(2, 0))
            ctk.CTkLabel(header, text=f"Nota #{a['annotation_number']}", font=ctk.CTkFont(size=10, weight="bold")).pack(side="left")
            ctk.CTkLabel(header, text=db_to_gui(a['date']), font=ctk.CTkFont(size=10)).pack(side="left", padx=10)
            ctk.CTkButton(header, text="✕", width=18, height=18, fg_color="#c0392b",
                          hover_color="#922b21", command=lambda aid=a['id']: self._delete_annotation(aid)).pack(side="right")
            ctk.CTkLabel(card, text=a['content'], font=ctk.CTkFont(size=11), justify="left", wraplength=250).pack(fill="x", padx=10, pady=(2, 5))

    def _add_annotation(self):
        content = self.annot_entry.get().strip()
        if not content: return
        today_db = date.today().isoformat()
        create_annotation(self.selected_solicitud_id, content, today_db)
        self.annot_entry.delete(0, "end")
        self._refresh_annotations()

    def _delete_annotation(self, annotation_id):
        if messagebox.askyesno("Confirmar", "¿Borrar esta anotación?"):
            delete_annotation(annotation_id)
            self._refresh_annotations()

    def _new_solicitud(self):
        self.selected_solicitud_id = None
        self.title_entry.delete(0, "end")
        self.typology_var.set(TYPOLOGIES[0])
        self.desc_text.delete("1.0", "end")
        self.id_sol_entry.delete(0, "end")
        self.id_sol_entry.insert(0, "0")
        if hasattr(self, "statuses_list") and self.statuses_list:
            self.status_var.set(self.statuses_list[0]["name"])
        self.start_date_entry.delete(0, "end")
        self.start_date_entry.insert(0, get_today_gui())
        self.end_date_entry.delete(0, "end")
        self.detention_date_entry.delete(0, "end")
        self.btn_add_annot.configure(state="disabled")
        self.btn_report.configure(state="disabled")
        self.btn_add_deliv.configure(state="disabled")
        self._refresh_annotations()
        self._refresh_deliverables()
        self.deliv_frame.grid_remove()

    def _save(self):
        title = self.title_entry.get().strip()
        if not title:
            messagebox.showerror("Error", "El título es obligatorio.")
            return
        status_id = get_status_id_by_name(self.status_var.get())
        try:
            id_sol_str = self.id_sol_entry.get().strip() or "0"
            id_solicitud = int(id_sol_str)
        except ValueError:
            messagebox.showerror("Error", "El ID Solicitud debe ser un número entero.")
            return
        data = {
            "title": title, "typology": self.typology_var.get(), "description": self.desc_text.get("1.0", "end").strip(),
            "request_link": "", "id_solicitud": id_solicitud, "status_id": status_id,
            "start_date": gui_to_db(self.start_date_entry.get().strip()),
            "end_date": gui_to_db(self.end_date_entry.get().strip()),
            "detention_date": gui_to_db(self.detention_date_entry.get().strip()),
        }
        try:
            if self.selected_solicitud_id:
                update_solicitud(self.selected_solicitud_id, data)
            else:
                self.selected_solicitud_id = create_solicitud(data)
            self.refresh()
            messagebox.showinfo("OK", "Solicitud guardada correctamente.")
        except Exception as e:
            if "UNIQUE" in str(e):
                messagebox.showerror("Error", f"Ya existe una solicitud con el título '{title}'.")
            else:
                messagebox.showerror("Error", str(e))

    def _delete_solicitud(self):
        if not self.selected_solicitud_id:
            messagebox.showwarning("Aviso", "Selecciona una solicitud primero.")
            return
        sol = next((s for s in self.solicitudes_raw if s["id"] == self.selected_solicitud_id), None)
        name = sol["title"] if sol else f"#{self.selected_solicitud_id}"
        if messagebox.askyesno("Confirmar", f"¿Borrar la solicitud '{name}'?"):
            delete_solicitud(self.selected_solicitud_id)
            self.selected_solicitud_id = None
            self._new_solicitud()
            self.refresh()

    def _export_pdf(self):
        if not self.selected_solicitud_id: return
        sol = next((s for s in self.solicitudes_raw if s["id"] == self.selected_solicitud_id), None)
        if not sol: return
        import re
        slug = re.sub(r'[^\w\s-]', '', sol['title'].lower())
        slug = re.sub(r'[-\s]+', '_', slug).strip('_')
        filename = f"Informe_{slug}.pdf"
        filepath = filedialog.asksaveasfilename(defaultextension=".pdf", initialfile=filename, filetypes=[("PDF files", "*.pdf")])
        if not filepath: return
        if generate_solicitud_pdf(self.selected_solicitud_id, filepath):
            messagebox.showinfo("OK", f"Informe guardado en:\n{filepath}")
            try: os.startfile(filepath)
            except: pass
        else: messagebox.showerror("Error", "No se pudo generar el informe.")

    def _on_typology_change(self, *args):
        if self.typology_var.get() == "PIPE": self.deliv_frame.grid()
        else: self.deliv_frame.grid_remove()

    def _refresh_deliverables(self):
        for w in self.deliv_list.winfo_children(): w.destroy()
        if not self.selected_solicitud_id: return
        delivs = get_deliverables_by_solicitud(self.selected_solicitud_id)
        for d in delivs:
            row = ctk.CTkFrame(self.deliv_list, fg_color="transparent")
            row.pack(fill="x", pady=1)
            ctk.CTkLabel(row, text=f"• {d['name']}", font=ctk.CTkFont(size=12)).pack(side="left", padx=5)
            ctk.CTkButton(row, text="✕", width=18, height=18, fg_color="#c0392b", hover_color="#922b21", 
                          command=lambda did=d['id']: self._delete_deliverable(did)).pack(side="right", padx=5)

    def _add_deliverable(self):
        if not self.selected_solicitud_id: return
        name = self.deliv_entry.get().strip()
        if not name: return
        try:
            add_deliverable(self.selected_solicitud_id, name)
            self.deliv_entry.delete(0, "end")
            self._refresh_deliverables()
        except Exception as e: messagebox.showerror("Error", str(e))

    def _delete_deliverable(self, deliverable_id):
        if not self.selected_solicitud_id: return
        if messagebox.askyesno("Confirmar", "¿Eliminar este entregable?"):
            delete_deliverable(deliverable_id)
            self._refresh_deliverables()

    def _open_sol_link(self):
        id_sol = self.id_sol_entry.get().strip()
        if not id_sol or id_sol == "0": return
        base_url = get_config("base_url_solicitud", "").strip()
        if not base_url:
            messagebox.showwarning("Configuración Faltante", "No se ha definido 'base_url_solicitud'.")
            return
        webbrowser.open(base_url + id_sol)
