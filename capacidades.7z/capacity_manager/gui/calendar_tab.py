"""
gui/calendar_tab.py — Configuración de festivos y disponibilidad mensual.
"""
import customtkinter as ctk
from tkinter import messagebox
from datetime import date
from db.models.calendar_config import (
    get_holidays, add_holiday, delete_holiday,
    get_all_month_availability, set_month_availability
)
from logic.calendar_engine import get_working_days
from utils.date_utils import gui_to_db, db_to_gui
from utils.gui_utils import DateEntry

MONTHS_ES = ["Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio",
             "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre"]


class CalendarTab(ctk.CTkFrame):
    def __init__(self, master, **kwargs):
        super().__init__(master, **kwargs)
        self.year_var = ctk.IntVar(value=date.today().year)
        self._build_ui()
        self.refresh()

    def _build_ui(self):
        self.grid_columnconfigure(0, weight=1)
        self.grid_columnconfigure(1, weight=1)
        self.grid_rowconfigure(1, weight=1)

        # ── Selector de año ────────────────────────────────────────────
        top = ctk.CTkFrame(self, fg_color="transparent")
        top.grid(row=0, column=0, columnspan=2, sticky="ew", padx=10, pady=(10, 4))
        ctk.CTkLabel(top, text="Año:", font=ctk.CTkFont(size=14)).pack(side="left", padx=6)
        self.year_spin = ctk.CTkEntry(top, textvariable=self.year_var, width=80)
        self.year_spin.pack(side="left")
        ctk.CTkButton(top, text="◀", width=35,
                      command=lambda: self._change_year(-1)).pack(side="left", padx=2)
        ctk.CTkButton(top, text="▶", width=35,
                      command=lambda: self._change_year(1)).pack(side="left", padx=2)
        ctk.CTkButton(top, text="🔄 Actualizar", command=self.refresh).pack(side="left", padx=10)

        # ── Festivos ───────────────────────────────────────────────────
        left = ctk.CTkFrame(self)
        left.grid(row=1, column=0, sticky="nsew", padx=(10, 5), pady=6)
        left.grid_rowconfigure(1, weight=1)
        left.grid_columnconfigure(0, weight=1)

        ctk.CTkLabel(left, text="Festivos", font=ctk.CTkFont(size=15, weight="bold")).grid(
            row=0, column=0, sticky="w", padx=10, pady=(10, 4))

        self.holidays_frame = ctk.CTkScrollableFrame(left)
        self.holidays_frame.grid(row=1, column=0, sticky="nsew", padx=5, pady=4)
        self.holidays_frame.grid_columnconfigure(0, weight=1)

        add_frame = ctk.CTkFrame(left, fg_color="transparent")
        add_frame.grid(row=2, column=0, sticky="ew", padx=6, pady=6)
        add_frame.grid_columnconfigure(1, weight=1)

        ctk.CTkLabel(add_frame, text="Fecha").grid(row=0, column=0, sticky="w", padx=4)
        self.holiday_date_entry = DateEntry(add_frame, placeholder_text="DD-MM-YYYY")
        self.holiday_date_entry.grid(row=0, column=1, sticky="ew", padx=4)

        ctk.CTkLabel(add_frame, text="Nombre").grid(row=1, column=0, sticky="w", padx=4)
        self.holiday_name_entry = ctk.CTkEntry(add_frame, placeholder_text="Ej: Semana Santa")
        self.holiday_name_entry.grid(row=1, column=1, sticky="ew", padx=4)

        ctk.CTkButton(add_frame, text="＋ Añadir festivo",
                      command=self._add_holiday).grid(row=2, column=0, columnspan=2, pady=6)

        # ── Disponibilidad mensual ─────────────────────────────────────
        right = ctk.CTkFrame(self)
        right.grid(row=1, column=1, sticky="nsew", padx=(5, 10), pady=6)
        right.grid_columnconfigure(1, weight=1)

        ctk.CTkLabel(right, text="Disponibilidad mensual (%)",
                     font=ctk.CTkFont(size=15, weight="bold")).grid(
            row=0, column=0, columnspan=3, sticky="w", padx=10, pady=(10, 4))

        self.avail_entries = {}
        self.lbl_days = {}
        for i, month_name in enumerate(MONTHS_ES, start=1):
            row = i
            ctk.CTkLabel(right, text=month_name, width=100).grid(row=row, column=0, sticky="w", padx=10, pady=3)
            e = ctk.CTkEntry(right, width=70)
            e.grid(row=row, column=1, padx=6, pady=3)
            self.avail_entries[i] = e
            lbl = ctk.CTkLabel(right, text="— días lab.")
            lbl.grid(row=row, column=2, sticky="w", padx=4, pady=3)
            self.lbl_days[i] = lbl

        ctk.CTkButton(right, text="💾 Guardar disponibilidades",
                      command=self._save_availability).grid(
            row=14, column=0, columnspan=3, pady=12)

    def _change_year(self, delta):
        self.year_var.set(self.year_var.get() + delta)
        self.refresh()

    def refresh(self):
        year = self.year_var.get()
        self._refresh_holidays(year)
        self._refresh_availability(year)

    def _refresh_holidays(self, year):
        for w in self.holidays_frame.winfo_children():
            w.destroy()
        self.holidays = get_holidays(year)
        if not self.holidays:
            ctk.CTkLabel(self.holidays_frame, text="Sin festivos configurados",
                         text_color="gray").grid(sticky="w", padx=6)
        for h in self.holidays:
            row = ctk.CTkFrame(self.holidays_frame, fg_color="transparent")
            row.grid(sticky="ew", pady=2)
            row.grid_columnconfigure(0, weight=1)
            ctk.CTkLabel(row, text=f"📅 {db_to_gui(h['date'])}  {h['name']}").grid(
                row=0, column=0, sticky="w", padx=4)
            ctk.CTkButton(row, text="🗑", width=30, fg_color="#c0392b", hover_color="#922b21",
                          command=lambda hid=h["id"]: self._delete_holiday(hid)).grid(
                row=0, column=1, padx=4)

    def _refresh_availability(self, year):
        avail = get_all_month_availability(year)
        for month, pct in avail.items():
            self.avail_entries[month].delete(0, "end")
            self.avail_entries[month].insert(0, str(pct))
            raw_days = get_working_days(year, month)
            eff_days = raw_days * pct / 100
            self.lbl_days[month].configure(text=f"{raw_days} días ({eff_days:.1f} ef.)")

    def _add_holiday(self):
        year = self.year_var.get()
        date_gui = self.holiday_date_entry.get().strip()
        name = self.holiday_name_entry.get().strip()
        if not date_gui:
            messagebox.showerror("Error", "La fecha es obligatoria (DD-MM-YYYY).")
            return
        
        date_db = gui_to_db(date_gui)
        try:
            d = date.fromisoformat(date_db)
            if d.year != year:
                messagebox.showwarning("Aviso", f"La fecha debe pertenecer al año {year}.")
                return
        except ValueError:
            messagebox.showerror("Error", "Formato de fecha inválido. Usa DD-MM-YYYY.")
            return
        add_holiday(year, date_db, name)
        self.holiday_date_entry.delete(0, "end")
        self.holiday_name_entry.delete(0, "end")
        self._refresh_holidays(year)

    def _delete_holiday(self, holiday_id):
        if messagebox.askyesno("Confirmar", "¿Borrar este festivo?"):
            delete_holiday(holiday_id)
            self._refresh_holidays(self.year_var.get())

    def _save_availability(self):
        year = self.year_var.get()
        for month, entry in self.avail_entries.items():
            try:
                pct = float(entry.get())
                pct = max(0.0, min(100.0, pct))
                set_month_availability(year, month, pct)
            except ValueError:
                messagebox.showerror("Error", f"Valor inválido en {MONTHS_ES[month-1]}.")
                return
        self._refresh_availability(year)
        messagebox.showinfo("OK", "Disponibilidades guardadas.")
