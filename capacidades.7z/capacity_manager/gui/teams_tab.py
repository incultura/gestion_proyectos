"""
gui/teams_tab.py — Gestión de equipos.
Incluye número de recursos y horas anuales para cada tipo.
"""
import customtkinter as ctk
from tkinter import messagebox
from db.models.teams import get_all_teams, create_team, update_team, delete_team, team_total_annual_hours
from utils.gui_utils import Tooltip


class TeamsTab(ctk.CTkFrame):
    def __init__(self, master, **kwargs):
        super().__init__(master, **kwargs)
        self.selected_team_id = None
        self.team_buttons = {} # Para resaltar selección
        self._build_ui()
        self.refresh()

    def _build_ui(self):
        self.grid_columnconfigure(0, weight=1)
        self.grid_columnconfigure(1, weight=2)
        self.grid_rowconfigure(0, weight=1)

        # ── Lista izquierda ────────────────────────────────────────────
        left = ctk.CTkFrame(self)
        left.grid(row=0, column=0, sticky="nsew", padx=(10, 5), pady=10)
        left.grid_rowconfigure(1, weight=1)
        left.grid_columnconfigure(0, weight=1)

        ctk.CTkLabel(left, text="Equipos", font=ctk.CTkFont(size=16, weight="bold")).grid(
            row=0, column=0, sticky="w", padx=10, pady=(10, 5))

        self.listbox_frame = ctk.CTkScrollableFrame(left)
        self.listbox_frame.grid(row=1, column=0, sticky="nsew", padx=5, pady=5)
        self.listbox_frame.grid_columnconfigure(0, weight=1)

        btn_row = ctk.CTkFrame(left, fg_color="transparent")
        btn_row.grid(row=2, column=0, sticky="ew", padx=5, pady=5)
        ctk.CTkButton(btn_row, text="＋ Nuevo", command=self._new_team, width=100).pack(side="left", padx=3)
        ctk.CTkButton(btn_row, text="🗑 Borrar", fg_color="#c0392b", hover_color="#922b21",
                      command=self._delete_team, width=100).pack(side="left", padx=3)

        # ── Cuadro Resumen Global ──────────────────────────────────────
        self.summary_card = ctk.CTkFrame(left, fg_color=("gray90", "gray20"), corner_radius=8)
        self.summary_card.grid(row=3, column=0, sticky="ew", padx=10, pady=(5, 15))
        
        ctk.CTkLabel(self.summary_card, text="RESUMEN TOTAL", font=ctk.CTkFont(size=14, weight="bold")).pack(pady=(12, 6))
        
        self.sum_resources_lbl = ctk.CTkLabel(self.summary_card, text="", font=ctk.CTkFont(size=13), justify="left")
        self.sum_resources_lbl.pack(padx=15, pady=4, anchor="w")
        
        self.sum_dist_lbl = ctk.CTkLabel(self.summary_card, text="", font=ctk.CTkFont(size=13), justify="left")
        self.sum_dist_lbl.pack(padx=15, pady=(4, 12), anchor="w")

        # ── Formulario derecha ─────────────────────────────────────────
        right = ctk.CTkScrollableFrame(self)
        right.grid(row=0, column=1, sticky="nsew", padx=(5, 10), pady=10)
        right.grid_columnconfigure(1, weight=1)

        ctk.CTkLabel(right, text="Detalle del Equipo",
                     font=ctk.CTkFont(size=16, weight="bold")).grid(
            row=0, column=0, columnspan=2, sticky="w", padx=15, pady=(15, 10))

        # Campos de texto
        self.entries = {}
        
        # Nombre
        ctk.CTkLabel(right, text="Nombre del equipo *").grid(row=1, column=0, sticky="w", padx=15, pady=5)
        self.entries["name"] = ctk.CTkEntry(right)
        self.entries["name"].grid(row=1, column=1, sticky="ew", padx=(5, 15), pady=5)

        # Internos
        row = 2
        ctk.CTkLabel(right, text="INTERNOS", font=ctk.CTkFont(weight="bold")).grid(row=row, column=0, columnspan=2, sticky="w", padx=15, pady=(10, 2))
        row += 1
        ctk.CTkLabel(right, text="  Nº Personas").grid(row=row, column=0, sticky="w", padx=15, pady=2)
        self.entries["internal_people"] = ctk.CTkEntry(right)
        self.entries["internal_people"].grid(row=row, column=1, sticky="ew", padx=(5, 15), pady=2)
        row += 1
        ctk.CTkLabel(right, text="  Horas anuales totales").grid(row=row, column=0, sticky="w", padx=15, pady=2)
        self.entries["internal_annual_hours"] = ctk.CTkEntry(right)
        self.entries["internal_annual_hours"].grid(row=row, column=1, sticky="ew", padx=(5, 15), pady=2)
        
        # Línea Base
        row += 1
        ctk.CTkLabel(right, text="LÍNEA BASE", font=ctk.CTkFont(weight="bold")).grid(row=row, column=0, columnspan=2, sticky="w", padx=15, pady=(10, 2))
        row += 1
        ctk.CTkLabel(right, text="  Nº Personas").grid(row=row, column=0, sticky="w", padx=15, pady=2)
        self.entries["baseline_people"] = ctk.CTkEntry(right)
        self.entries["baseline_people"].grid(row=row, column=1, sticky="ew", padx=(5, 15), pady=2)
        row += 1
        ctk.CTkLabel(right, text="  Horas anuales totales").grid(row=row, column=0, sticky="w", padx=15, pady=2)
        self.entries["baseline_annual_hours"] = ctk.CTkEntry(right)
        self.entries["baseline_annual_hours"].grid(row=row, column=1, sticky="ew", padx=(5, 15), pady=2)

        # Refuerzo
        row += 1
        ctk.CTkLabel(right, text="REFUERZO", font=ctk.CTkFont(weight="bold")).grid(row=row, column=0, columnspan=2, sticky="w", padx=15, pady=(10, 2))
        row += 1
        ctk.CTkLabel(right, text="  Nº Personas").grid(row=row, column=0, sticky="w", padx=15, pady=2)
        self.entries["reinforce_people"] = ctk.CTkEntry(right)
        self.entries["reinforce_people"].grid(row=row, column=1, sticky="ew", padx=(5, 15), pady=2)
        row += 1
        ctk.CTkLabel(right, text="  Horas anuales totales").grid(row=row, column=0, sticky="w", padx=15, pady=2)
        self.entries["reinforce_annual_hours"] = ctk.CTkEntry(right)
        self.entries["reinforce_annual_hours"].grid(row=row, column=1, sticky="ew", padx=(5, 15), pady=2)

        # % Operación
        row += 1
        ctk.CTkLabel(right, text="% Operación (0-100)").grid(row=row, column=0, sticky="w", padx=15, pady=10)
        self.entries["ops_percentage"] = ctk.CTkEntry(right)
        self.entries["ops_percentage"].grid(row=row, column=1, sticky="ew", padx=(5, 15), pady=10)

        row += 1
        # Separador visual
        sep = ctk.CTkFrame(right, height=2, fg_color=("gray70", "gray40"))
        sep.grid(row=row, column=0, columnspan=2, sticky="ew", padx=15, pady=8)

        # ── Totales calculados (readonly) ──────────────────────────────
        row += 1
        totals_frame = ctk.CTkFrame(right, fg_color=("gray92", "gray18"), corner_radius=8)
        totals_frame.grid(row=row, column=0, columnspan=2, sticky="ew", padx=15, pady=4)
        totals_frame.grid_columnconfigure(1, weight=1)

        ctk.CTkLabel(totals_frame, text="Total horas anuales",
                     font=ctk.CTkFont(weight="bold")).grid(
            row=0, column=0, sticky="w", padx=12, pady=6)
        self.lbl_total = ctk.CTkLabel(totals_frame, text="—",
                                       font=ctk.CTkFont(size=16, weight="bold"),
                                       text_color="#4fc3f7")
        self.lbl_total.grid(row=0, column=1, sticky="w", padx=8, pady=6)

        ctk.CTkLabel(totals_frame, text="  → Operación").grid(
            row=1, column=0, sticky="w", padx=12, pady=3)
        self.lbl_ops = ctk.CTkLabel(totals_frame, text="—", text_color="#1e8449")
        self.lbl_ops.grid(row=1, column=1, sticky="w", padx=8, pady=3)

        ctk.CTkLabel(totals_frame, text="  → No-Operación").grid(
            row=2, column=0, sticky="w", padx=12, pady=3)
        self.lbl_nonops = ctk.CTkLabel(totals_frame, text="—", text_color="#d4ac0d")
        self.lbl_nonops.grid(row=2, column=1, sticky="w", padx=8, pady=(3, 8))

        # ID interno
        row += 1
        ctk.CTkLabel(right, text="ID interno", text_color="gray").grid(
            row=row, column=0, sticky="w", padx=15, pady=(8, 4))
        self.lbl_id = ctk.CTkLabel(right, text="(nuevo)", text_color="gray")
        self.lbl_id.grid(row=row, column=1, sticky="w", padx=(5, 15), pady=(8, 4))

        # Botón guardar
        row += 1
        ctk.CTkButton(right, text="💾 Guardar", command=self._save,
                      font=ctk.CTkFont(size=14, weight="bold")).grid(
            row=row, column=0, columnspan=2, pady=15)

        # Recalcular al teclear
        for key in ["internal_annual_hours", "baseline_annual_hours",
                    "reinforce_annual_hours", "ops_percentage"]:
            self.entries[key].bind("<KeyRelease>", self._update_totals)

    def refresh(self):
        for w in self.listbox_frame.winfo_children():
            w.destroy()
        self.team_buttons = {} # Limpiar mapa
        self.teams = get_all_teams()
        for team in self.teams:
            btn = ctk.CTkButton(
                self.listbox_frame,
                text=team["name"],
                anchor="w", fg_color="transparent",
                text_color=("black", "white"),
                hover_color=("gray80", "gray30"),
                command=lambda tid=team["id"]: self._select_team(tid)
            )
            btn.grid(sticky="ew", pady=1)
            self.team_buttons[team["id"]] = btn
            
            # Tooltip por si acaso
            Tooltip(btn, team["name"])
            
        # Restaurar resaltado
        if self.selected_team_id:
            self._highlight_selection(self.selected_team_id)
            
        self._update_sidebar_summary()

    def _update_sidebar_summary(self):
        # Totales globales
        total_int_p = 0; total_int_h = 0
        total_lb_p = 0; total_lb_h = 0
        total_ref_p = 0; total_ref_h = 0
        total_ops_h = 0
        
        for t in self.teams:
            # Extraer valores con safeguards
            int_p = t.get("internal_people", 0) or 0
            int_h = t.get("internal_annual_hours", 0) or 0
            lb_p = t.get("baseline_people", 0) or 0
            lb_h = t.get("baseline_annual_hours", 0) or 0
            ref_p = t.get("reinforce_people", 0) or 0
            ref_h = t.get("reinforce_annual_hours", 0) or 0
            ops_pct = t.get("ops_percentage", 0) or 0
            
            total_int_p += int_p; total_int_h += int_h
            total_lb_p += lb_p; total_lb_h += lb_h
            total_ref_p += ref_p; total_ref_h += ref_h
            
            team_total = int_h + lb_h + ref_h
            total_ops_h += (team_total * ops_pct / 100)
            
        grand_total_h = total_int_h + total_lb_h + total_ref_h
        total_rest_h = grand_total_h - total_ops_h
        
        ops_pct_global = (total_ops_h / grand_total_h * 100) if grand_total_h > 0 else 0
        rest_pct_global = (total_rest_h / grand_total_h * 100) if grand_total_h > 0 else 0
        
        # Formatear textos
        res_text = (f"• Internos: {total_int_p} ({total_int_h:,.0f}h)\n"
                    f"• L. Base: {total_lb_p} ({total_lb_h:,.0f}h)\n"
                    f"• Refuerzo: {total_ref_p} ({total_ref_h:,.0f}h)").replace(",", ".")
        
        dist_text = (f"Total: {grand_total_h:,.0f}h\n"
                     f"Operación: {total_ops_h:,.0f}h ({ops_pct_global:.1f}%)\n"
                     f"Proyectos: {total_rest_h:,.0f}h ({rest_pct_global:.1f}%)").replace(",", ".")
        
        self.sum_resources_lbl.configure(text=res_text)
        self.sum_dist_lbl.configure(text=dist_text)

    def _select_team(self, team_id: int):
        self.selected_team_id = team_id
        self._highlight_selection(team_id)
        team = next((t for t in self.teams if t["id"] == team_id), None)
        if not team:
            return
        # Rellenar todos los campos del formulario
        for key, entry in self.entries.items():
            entry.delete(0, "end")
            val = team.get(key)
            entry.insert(0, str(val) if val is not None else "0")
        self.lbl_id.configure(text=str(team["id"]))
        self._update_totals()

    def _highlight_selection(self, team_id):
        # Restablecer todos
        for tid, btn in self.team_buttons.items():
            btn.configure(fg_color="transparent")
        
        # Resaltar seleccinado
        if team_id in self.team_buttons:
            self.team_buttons[team_id].configure(fg_color="#34495e")

    def _new_team(self):
        self.selected_team_id = None
        for entry in self.entries.values():
            entry.delete(0, "end")
        self.lbl_id.configure(text="(nuevo)")
        self.lbl_total.configure(text="—")
        self.lbl_ops.configure(text="—")
        self.lbl_nonops.configure(text="—")

    def _save(self):
        raw = {key: entry.get().strip() for key, entry in self.entries.items()}
        if not raw["name"]:
            messagebox.showerror("Error", "El nombre del equipo es obligatorio.")
            return
        try:
            data = {
                "name": raw["name"],
                "internal_people": int(raw["internal_people"] or 0),
                "internal_annual_hours": float(raw["internal_annual_hours"] or 0),
                "baseline_people": int(raw["baseline_people"] or 0),
                "baseline_annual_hours": float(raw["baseline_annual_hours"] or 0),
                "reinforce_people": int(raw["reinforce_people"] or 0),
                "reinforce_annual_hours": float(raw["reinforce_annual_hours"] or 0),
                "ops_percentage": float(raw["ops_percentage"] or 0),
            }
        except ValueError:
            messagebox.showerror("Error", "Los valores de personas, horas y % deben ser numéricos.")
            return

        ops = data["ops_percentage"]
        if not (0 <= ops <= 100):
            messagebox.showerror("Error", "El % de operación debe estar entre 0 y 100.")
            return

        try:
            if self.selected_team_id is not None:
                update_team(self.selected_team_id, data)
            else:
                self.selected_team_id = create_team(data)
                self.lbl_id.configure(text=str(self.selected_team_id))
        except Exception as e:
            if "UNIQUE" in str(e):
                messagebox.showerror("Error", f"Ya existe un equipo con el nombre '{data['name']}'.")
            else:
                messagebox.showerror("Error", str(e))
            return

        self.refresh()
        messagebox.showinfo("OK", "Equipo guardado correctamente.")

    def _delete_team(self):
        if self.selected_team_id is None:
            messagebox.showwarning("Aviso", "Selecciona un equipo primero.")
            return
        team = next((t for t in self.teams if t["id"] == self.selected_team_id), None)
        name = team["name"] if team else str(self.selected_team_id)
        if messagebox.askyesno("Confirmar", f"¿Borrar el equipo '{name}'?"):
            delete_team(self.selected_team_id)
            self.selected_team_id = None
            self._new_team()
            self.refresh()

    def _update_totals(self, event=None):
        try:
            internal = float(self.entries["internal_annual_hours"].get() or 0)
            baseline = float(self.entries["baseline_annual_hours"].get() or 0)
            reinforce = float(self.entries["reinforce_annual_hours"].get() or 0)
            ops_pct = float(self.entries["ops_percentage"].get() or 0)

            total = internal + baseline + reinforce
            ops_h = total * ops_pct / 100
            non_ops_h = total * (1 - ops_pct / 100)

            self.lbl_total.configure(text=f"{total:,.0f} h".replace(",", "."))
            self.lbl_ops.configure(text=f"{ops_h:,.0f} h".replace(",", "."))
            self.lbl_nonops.configure(text=f"{non_ops_h:,.0f} h".replace(",", "."))
        except ValueError:
            self.lbl_total.configure(text="—")
            self.lbl_ops.configure(text="—")
            self.lbl_nonops.configure(text="—")
