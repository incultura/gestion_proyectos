"""
gui/dependencies_tab.py — Gestión del catálogo global de dependencias.
"""
import customtkinter as ctk
from tkinter import messagebox
from db.models.dependencies import get_all_dependencies, create_dependency, update_dependency, delete_dependency

class DependenciesTab(ctk.CTkFrame):
    def __init__(self, master, **kwargs):
        super().__init__(master, **kwargs)
        self.selected_dep_id = None
        self._build_ui()
        self.refresh()

    def _build_ui(self):
        self.grid_columnconfigure(0, weight=1)
        self.grid_columnconfigure(1, weight=1)
        self.grid_rowconfigure(0, weight=1)

        # ── Lista izquierda ────────────────────────────────────────────
        left = ctk.CTkFrame(self)
        left.grid(row=0, column=0, sticky="nsew", padx=(10, 5), pady=10)
        left.grid_rowconfigure(1, weight=1)
        left.grid_columnconfigure(0, weight=1)

        ctk.CTkLabel(left, text="Catálogo de Dependencias", font=ctk.CTkFont(size=16, weight="bold")).grid(
            row=0, column=0, sticky="w", padx=10, pady=(10, 5))

        self.listbox_frame = ctk.CTkScrollableFrame(left)
        self.listbox_frame.grid(row=1, column=0, sticky="nsew", padx=5, pady=5)
        self.listbox_frame.grid_columnconfigure(0, weight=1)

        # Filtro de búsqueda
        search_frame = ctk.CTkFrame(left, fg_color="transparent")
        search_frame.grid(row=2, column=0, sticky="ew", padx=10, pady=2)
        
        self.search_var = ctk.StringVar()
        self.search_var.trace_add("write", lambda *args: self.refresh_list())
        
        self.search_entry = ctk.CTkEntry(search_frame, placeholder_text="🔍 Buscar area/app...", textvariable=self.search_var)
        self.search_entry.pack(side="left", fill="x", expand=True)
        
        ctk.CTkButton(search_frame, text="🧹", width=30, command=lambda: self.search_var.set("")).pack(side="left", padx=(5, 0))

        btn_row = ctk.CTkFrame(left, fg_color="transparent")
        btn_row.grid(row=3, column=0, sticky="ew", padx=5, pady=5)
        ctk.CTkButton(btn_row, text="＋ Nueva", command=self._new_dep, width=100).pack(side="left", padx=3)
        ctk.CTkButton(btn_row, text="🗑 Borrar", fg_color="#c0392b", hover_color="#922b21",
                      command=self._delete_dep, width=100).pack(side="left", padx=3)

        # ── Formulario derecha ─────────────────────────────────────────
        right = ctk.CTkFrame(self)
        right.grid(row=0, column=1, sticky="nsew", padx=(5, 10), pady=10)
        right.grid_columnconfigure(1, weight=1)

        ctk.CTkLabel(right, text="Detalle de Dependencia",
                     font=ctk.CTkFont(size=16, weight="bold")).grid(
            row=0, column=0, columnspan=2, sticky="w", padx=15, pady=(15, 10))

        ctk.CTkLabel(right, text="Nombre de Area/App *").grid(row=1, column=0, sticky="w", padx=15, pady=5)
        self.entry_name = ctk.CTkEntry(right)
        self.entry_name.grid(row=1, column=1, sticky="ew", padx=(5, 15), pady=5)

        self.lbl_id = ctk.CTkLabel(right, text="(nueva)", text_color="gray")
        self.lbl_id.grid(row=2, column=1, sticky="w", padx=(5, 15), pady=(8, 4))

        ctk.CTkButton(right, text="💾 Guardar", command=self._save,
                      font=ctk.CTkFont(size=14, weight="bold")).grid(
            row=3, column=0, columnspan=2, pady=15)

    def refresh(self):
        self.dependencies = get_all_dependencies()
        self.refresh_list()

    def refresh_list(self):
        for w in self.listbox_frame.winfo_children():
            w.destroy()
        
        search_text = self.search_var.get().lower()
        
        filtered = [d for d in self.dependencies if search_text in d["name"].lower()] if search_text else self.dependencies

        for dep in filtered:
            btn = ctk.CTkButton(
                self.listbox_frame,
                text=dep["name"],
                anchor="w", fg_color="transparent",
                text_color=("black", "white"),
                hover_color=("gray80", "gray30"),
                command=lambda did=dep["id"]: self._select_dep(did)
            )
            btn.grid(sticky="ew", pady=1)

    def _select_dep(self, dep_id: int):
        self.selected_dep_id = dep_id
        dep = next((d for d in self.dependencies if d["id"] == dep_id), None)
        if dep:
            self.entry_name.delete(0, "end")
            self.entry_name.insert(0, dep["name"])
            self.lbl_id.configure(text=f"ID: {dep['id']}")

    def _new_dep(self):
        self.selected_dep_id = None
        self.entry_name.delete(0, "end")
        self.lbl_id.configure(text="(nueva)")

    def _save(self):
        name = self.entry_name.get().strip()
        if not name:
            messagebox.showerror("Error", "El nombre es obligatorio.")
            return

        try:
            if self.selected_dep_id:
                update_dependency(self.selected_dep_id, name)
            else:
                self.selected_dep_id = create_dependency(name)
            
            messagebox.showinfo("OK", "Dependencia guardada.")
            self.refresh()
            self._select_dep(self.selected_dep_id)
        except Exception as e:
            if "UNIQUE" in str(e):
                messagebox.showerror("Error", "Ya existe una dependencia con ese nombre.")
            else:
                messagebox.showerror("Error", str(e))

    def _delete_dep(self):
        if not self.selected_dep_id:
            messagebox.showwarning("Aviso", "Selecciona una dependencia.")
            return
        
        dep = next((d for d in self.dependencies if d["id"] == self.selected_dep_id), None)
        if messagebox.askyesno("Confirmar", f"¿Borrar '{dep['name']}'? Esto afectará a todos los proyectos asociados."):
            delete_dependency(self.selected_dep_id)
            self._new_dep()
            self.refresh()
