import customtkinter as ctk
from tkinter import messagebox, filedialog
import datetime
import os
from db.models.notes import create_note, get_all_notes, update_note, delete_note, search_notes
from logic.report_logic import generate_notes_report_pdf
from utils.gui_utils import TableFrame


class NotesTab(ctk.CTkFrame):
    def __init__(self, parent):
        super().__init__(parent)
        self.parent = parent
        self.current_note_id = None
        
        # --- TOP SECTION: Search & Form ---
        self.top_frame = ctk.CTkFrame(self)
        self.top_frame.pack(fill="x", padx=10, pady=10)
        
        # Search Sub-frame
        self.search_frame = ctk.CTkFrame(self.top_frame, fg_color="transparent")
        self.search_frame.pack(fill="x", pady=(0, 10))
        
        ctk.CTkLabel(self.search_frame, text="Buscar Notas:").pack(side="left", padx=5)
        self.search_entry = ctk.CTkEntry(self.search_frame, width=300, placeholder_text="Buscar en título o contenido...")
        self.search_entry.pack(side="left", padx=5)
        self.search_button = ctk.CTkButton(self.search_frame, text="Buscar", command=self._search_notes, width=80)
        self.search_button.pack(side="left", padx=5)
        self.clear_search_btn = ctk.CTkButton(self.search_frame, text="Limpiar", command=self._clear_search, width=80, fg_color="gray")
        self.clear_search_btn.pack(side="left", padx=5)
        
        # Form Sub-frame
        self.form_frame = ctk.CTkFrame(self.top_frame)
        self.form_frame.pack(fill="x", pady=10,padx=5)
        
        # We can use a grid layout for the form
        ctk.CTkLabel(self.form_frame, text="Título:").grid(row=0, column=0, padx=5, pady=5, sticky="e")
        self.title_entry = ctk.CTkEntry(self.form_frame, width=600)
        self.title_entry.grid(row=0, column=1, padx=5, pady=5, sticky="w")
        
        ctk.CTkLabel(self.form_frame, text="Contenido:").grid(row=1, column=0, padx=5, pady=5, sticky="ne")
        self.content_text = ctk.CTkTextbox(self.form_frame, width=600, height=200)
        self.content_text.grid(row=1, column=1, padx=5, pady=5, sticky="w")
        
        self.is_area_var = ctk.BooleanVar(value=False)
        self.is_area_check = ctk.CTkCheckBox(self.form_frame, text="¿Es Reunión de Área?", variable=self.is_area_var)
        self.is_area_check.grid(row=2, column=1, padx=5, pady=5, sticky="w")
        
        self.btn_frame = ctk.CTkFrame(self.form_frame, fg_color="transparent")
        self.btn_frame.grid(row=3, column=1, pady=10, sticky="w")
        
        self.save_btn = ctk.CTkButton(self.btn_frame, text="Guardar Nota", command=self._save_note)
        self.save_btn.pack(side="left", padx=5)
        
        self.cancel_btn = ctk.CTkButton(self.btn_frame, text="Cancelar Edición", command=self._clear_form, fg_color="gray")
        self.cancel_btn.pack(side="left", padx=5)
        self.cancel_btn.pack_forget() # Hide initially
        
        # --- REPORT SECTION ---
        self.report_frame = ctk.CTkFrame(self.top_frame, fg_color="transparent")
        self.report_frame.pack(fill="x", pady=10, padx=5)
        
        ctk.CTkLabel(self.report_frame, text="Informe PDF - Desde (DD-MM-YYYY):").pack(side="left", padx=5)
        
        today = datetime.date.today()
        default_from = (today - datetime.timedelta(days=7)).strftime("%d-%m-%Y")
        default_to = today.strftime("%d-%m-%Y")
        
        self.report_start_entry = ctk.CTkEntry(self.report_frame, width=120)
        self.report_start_entry.insert(0, default_from)
        self.report_start_entry.pack(side="left", padx=5)
        
        ctk.CTkLabel(self.report_frame, text="Hasta:").pack(side="left", padx=5)
        self.report_end_entry = ctk.CTkEntry(self.report_frame, width=120)
        self.report_end_entry.insert(0, default_to)
        self.report_end_entry.pack(side="left", padx=5)
        
        self.report_area_var = ctk.BooleanVar(value=False)
        self.report_area_check = ctk.CTkCheckBox(self.report_frame, text="Solo Reunión de Área", variable=self.report_area_var)
        self.report_area_check.pack(side="left", padx=15)
        
        self.generate_btn = ctk.CTkButton(self.report_frame, text="Generar PDF", command=self._generate_pdf, fg_color="#d9534f", hover_color="#c9302c")
        self.generate_btn.pack(side="left", padx=5)

        
        # --- BOTTOM SECTION: Table ---
        self.table_container = ctk.CTkFrame(self)
        self.table_container.pack(fill="both", expand=True, padx=10, pady=10)
        
        self.table = None
        self.refresh()

    def _save_note(self):
        title = self.title_entry.get().strip()
        content = self.content_text.get("1.0", "end-1c").strip()
        is_area = self.is_area_var.get()
        
        if not title:
            messagebox.showwarning("Aviso", "El título es obligatorio.")
            return
            
        if self.current_note_id:
            update_note(self.current_note_id, title, content, is_area)
            messagebox.showinfo("Éxito", "Nota actualizada correctamente.")
        else:
            create_note(title, content, is_area)
            messagebox.showinfo("Éxito", "Nota creada correctamente.")
            
        self._clear_form()
        self.refresh()
        
    def _generate_pdf(self):
        start_date_gui = self.report_start_entry.get().strip()
        end_date_gui = self.report_end_entry.get().strip()
        only_area = self.report_area_var.get()
        
        if not start_date_gui or not end_date_gui:
            messagebox.showwarning("Fechas Inválidas", "Por favor, especifica un desde y un hasta en formato DD-MM-YYYY.")
            return
            
        # Parse DD-MM-YYYY to YYYY-MM-DD for DB
        try:
            start_date = datetime.datetime.strptime(start_date_gui, "%d-%m-%Y").strftime("%Y-%m-%d")
            end_date = datetime.datetime.strptime(end_date_gui, "%d-%m-%Y").strftime("%Y-%m-%d")
        except ValueError:
            messagebox.showwarning("Formato Incorrecto", "Las fechas deben estar en formato DD-MM-YYYY.")
            return
            
        out_path = filedialog.asksaveasfilename(
            defaultextension=".pdf",
            filetypes=[("PDF files", "*.pdf")],
            title="Guardar Informe de Notas",
            initialfile=f"Informe_Notas_{start_date}_{end_date}.pdf"
        )
        if not out_path:
            return
            
        try:
            generate_notes_report_pdf(out_path, start_date, end_date, only_area)
            messagebox.showinfo("Éxito", f"Informe generado en:\n{out_path}")
            os.startfile(os.path.dirname(out_path) or '.') # Open folder
        except Exception as e:
            messagebox.showerror("Error", f"Fallo al generar informe:\n{str(e)}")

    def _clear_form(self):
        self.current_note_id = None
        self.title_entry.delete(0, 'end')
        self.content_text.delete("1.0", 'end')
        self.is_area_var.set(False)
        self.save_btn.configure(text="Guardar Nota")
        self.cancel_btn.pack_forget()

    def _search_notes(self):
        query = self.search_entry.get().strip()
        if query:
            notes = search_notes(query)
            self._display_notes(notes)
        else:
            self.refresh()
            
    def _clear_search(self):
        self.search_entry.delete(0, 'end')
        self.refresh()

    def refresh(self):
        """Loads all notes from db and displays them."""
        notes = get_all_notes()
        self._display_notes(notes)

    def _display_notes(self, notes):
        if self.table:
            self.table.destroy()
            
        headers = ["ID", "Fecha", "Título", "Contenido (Extracto)"]
        self.table = TableFrame(self.table_container, headers=headers)
        self.table.pack(fill="both", expand=True)
        
        for n in notes:
            content_snippet = n['content'][:50] + "..." if n['content'] and len(n['content']) > 50 else n['content']
            
            date_str = ""
            if n['created_date']:
                date_part = n['created_date'][:10]
                if '-' in date_part:
                    y, m, d = date_part.split('-')
                    date_str = f"{d}-{m}-{y}"
                else:
                    date_str = date_part
                    
            row_data = [
                str(n['id']),
                date_str,
                n['title'],
                content_snippet
            ]
            row_widgets = self.table.add_row(row_data)
            
            # Add Action buttons
            btn_frame = ctk.CTkFrame(row_widgets[0].master, fg_color="transparent")
            btn_frame.grid(row=len(self.table.rows), column=4, padx=5, pady=2)
            
            edit_btn = ctk.CTkButton(btn_frame, text="✏️", width=30, command=lambda note=n: self._load_note_for_edit(note))
            edit_btn.pack(side="left", padx=2)
            
            del_btn = ctk.CTkButton(btn_frame, text="🗑️", width=30, fg_color="red", hover_color="#8b0000",
                                    command=lambda nid=n['id']: self._delete_note(nid))
            del_btn.pack(side="left", padx=2)

    def _load_note_for_edit(self, note):
        self._clear_form()
        self.current_note_id = note['id']
        self.title_entry.insert(0, note['title'])
        if note['content']:
            self.content_text.insert("1.0", note['content'])
        self.is_area_var.set(bool(note.get('is_area_meeting', False)))
        self.save_btn.configure(text="Actualizar Nota")
        self.cancel_btn.pack(side="left", padx=5)

    def _delete_note(self, note_id):
        if messagebox.askyesno("Confirmar", "¿Seguro que quieres borrar esta nota?"):
            delete_note(note_id)
            self.refresh()
