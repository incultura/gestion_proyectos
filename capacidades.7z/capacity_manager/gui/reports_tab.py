"""
gui/reports_tab.py — Generación de informes detallados.
"""
import os
import customtkinter as ctk
from tkinter import messagebox, filedialog
from datetime import date
from db.models.teams import get_all_teams
from logic.report_logic import get_team_report_data, generate_team_pdf, generate_global_pdf
from utils.date_utils import db_to_gui

class ReportsTab(ctk.CTkFrame):
    def __init__(self, master, **kwargs):
        super().__init__(master, **kwargs)
        self.selected_team_id = None
        self.year = date.today().year
        self._build_ui()
        self.refresh()

    def _build_ui(self):
        self.grid_columnconfigure(0, weight=1)
        self.grid_columnconfigure(1, weight=4)
        self.grid_rowconfigure(0, weight=1)

        # ── Sidebar: Selección de Informe ─────────────────────────────
        sidebar = ctk.CTkFrame(self, width=200)
        sidebar.grid(row=0, column=0, sticky="nsew", padx=10, pady=10)
        sidebar.grid_rowconfigure(2, weight=1)

        ctk.CTkLabel(sidebar, text="Informes", font=ctk.CTkFont(size=14, weight="bold")).grid(row=0, column=0, pady=10)
        
        self.btn_global = ctk.CTkButton(sidebar, text="🌍 Visión Global", command=self._select_global)
        self.btn_global.grid(row=1, column=0, padx=10, pady=5, sticky="ew")

        ctk.CTkLabel(sidebar, text="Por Equipo", font=ctk.CTkFont(size=12)).grid(row=2, column=0, pady=(10, 0))
        self.teams_frame = ctk.CTkScrollableFrame(sidebar)
        self.teams_frame.grid(row=3, column=0, sticky="nsew", padx=5, pady=5)
        self.teams_frame.grid_columnconfigure(0, weight=1)

        # ── Área Principal: Visualización ─────────────────────────────
        self.main_area = ctk.CTkScrollableFrame(self)
        self.main_area.grid(row=0, column=1, sticky="nsew", padx=10, pady=10)
        self.main_area.grid_columnconfigure(0, weight=1)

        # Barra de herramientas superior
        self.toolbar = ctk.CTkFrame(self.main_area, fg_color="transparent")
        self.toolbar.grid(row=0, column=0, sticky="ew", padx=10, pady=10)
        
        self.lbl_title = ctk.CTkLabel(self.toolbar, text="Selecciona un equipo para ver el informe", 
                                     font=ctk.CTkFont(size=16, weight="bold"))
        self.lbl_title.pack(side="left", padx=10)

        self.btn_pdf = ctk.CTkButton(self.toolbar, text="📄 Exportar PDF", fg_color="#27ae60", 
                                     hover_color="#1e8449", command=self._export_pdf, state="disabled")
        self.btn_pdf.pack(side="right", padx=10)

        # Contenedor para el contenido dinámico
        self.content_frame = ctk.CTkFrame(self.main_area, fg_color="transparent")
        self.content_frame.grid(row=1, column=0, sticky="nsew", padx=10, pady=10)
        self.content_frame.grid_columnconfigure(0, weight=1)

    def refresh(self):
        for w in self.teams_frame.winfo_children():
            w.destroy()
        
        teams = get_all_teams()
        for t in teams:
            btn = ctk.CTkButton(
                self.teams_frame, text=t["name"], anchor="w",
                fg_color="transparent", text_color=("black", "white"),
                hover_color=("gray80", "gray30"),
                command=lambda tid=t["id"]: self._select_team(tid)
            )
            btn.grid(sticky="ew", pady=1)

    def _select_global(self):
        self.selected_team_id = "GLOBAL"
        self.lbl_title.configure(text="🌍 Visión Global de Capacidad")
        self.btn_pdf.configure(state="normal")
        self._show_global_report()

    def _select_team(self, team_id):
        self.selected_team_id = team_id
        self.btn_pdf.configure(state="normal")
        self._show_team_report(team_id)

    def _clear_content(self):
        for w in self.content_frame.winfo_children():
            w.destroy()

    def _show_team_report(self, team_id):
        self._clear_content()
        data = get_team_report_data(team_id, self.year)
        if not data: return

        self.lbl_title.configure(text=f"Informe: {data['team']['name']}")

        # 1. Resumen Ficha
        f1 = ctk.CTkFrame(self.content_frame)
        f1.grid(row=0, column=0, sticky="ew", pady=10)
        ctk.CTkLabel(f1, text="Resumen de Recursos", font=ctk.CTkFont(weight="bold")).pack(pady=5)
        
        t = data['team']
        txt = (f"Internos: {t['internal_people']} ({t['internal_annual_hours']:.0f}h)   |   "
               f"Baseline: {t['baseline_people']} ({t['baseline_annual_hours']:.0f}h)   |   "
               f"Refuerzo: {t['reinforce_people']} ({t['reinforce_annual_hours']:.0f}h)\n"
               f"Total: {data['summary']['total_hours']:.1f}h/año   |   "
               f"Op: {data['summary']['ops_hours']:.1f}h ({t['ops_percentage']}%)   |   "
               f"Proyectos: {data['summary']['non_ops_hours']:.1f}h")
        ctk.CTkLabel(f1, text=txt, justify="center").pack(pady=10)

        # 2. Proyectos Activos
        f2 = ctk.CTkFrame(self.content_frame)
        f2.grid(row=1, column=0, sticky="ew", pady=10)
        ctk.CTkLabel(f2, text="Proyectos con Carga Pendiente o en Curso", font=ctk.CTkFont(weight="bold")).pack(pady=5)
        
        if not data['active_projects']:
            ctk.CTkLabel(f2, text="No hay proyectos activos registrados para este equipo.").pack(pady=10)
        else:
            p_frame = ctk.CTkFrame(f2, fg_color="transparent")
            p_frame.pack(fill="x", padx=10, pady=10)
            
            # Cabecera tabla
            cols = ["Proyecto", "Fin", "Estimado", "Pendiente", "Estado"]
            for i, col in enumerate(cols):
                ctk.CTkLabel(p_frame, text=col, font=ctk.CTkFont(size=11, weight="bold")).grid(row=0, column=i, padx=5, sticky="w")
            
            for idx, p in enumerate(data['active_projects']):
                ctk.CTkLabel(p_frame, text=p['project_title'][:40], font=ctk.CTkFont(size=11)).grid(row=idx+1, column=0, padx=5, sticky="w")
                ctk.CTkLabel(p_frame, text=db_to_gui(p['end']) if p['end'] else "-", font=ctk.CTkFont(size=11)).grid(row=idx+1, column=1, padx=5)
                ctk.CTkLabel(p_frame, text=f"{p['estimated']:.1f}h", font=ctk.CTkFont(size=11)).grid(row=idx+1, column=2, padx=5)
                ctk.CTkLabel(p_frame, text=f"{p['remaining']:.1f}h", font=ctk.CTkFont(size=11, weight="bold")).grid(row=idx+1, column=3, padx=5)
                ctk.CTkLabel(p_frame, text=p['status'], font=ctk.CTkFont(size=10)).grid(row=idx+1, column=4, padx=5)

        # 3. Timeline de Carga
        f3 = ctk.CTkFrame(self.content_frame)
        f3.grid(row=2, column=0, sticky="ew", pady=10)
        ctk.CTkLabel(f3, text="Timeline de Carga Mensual (Proyectos)", font=ctk.CTkFont(weight="bold")).pack(pady=5)
        
        for m in data['timeline']:
            m_frame = ctk.CTkFrame(f3, fg_color=("gray90", "gray25"))
            m_frame.pack(fill="x", padx=10, pady=5)
            
            load = (m['total_assigned'] / m['available_non_ops'] * 100) if m['available_non_ops'] > 0 else 0
            color = "#e74c3c" if load > 100 else "#27ae60" if load < 80 else "#f39c12"
            
            title_txt = f"Mes {m['month']}  —  Disp: {m['available_non_ops']:.1f}h  |  Carga: {load:.1f}%"
            ctk.CTkLabel(m_frame, text=title_txt, font=ctk.CTkFont(weight="bold"), text_color=color).pack(side="top", anchor="w", padx=10)
            
            if not m['projects']:
                ctk.CTkLabel(m_frame, text="   (Sin carga)", font=ctk.CTkFont(size=10, slant="italic")).pack(side="top", anchor="w", padx=20)
            else:
                for p in m['projects']:
                    ctk.CTkLabel(m_frame, text=f"   • {p['title']}: {p['hours']:.1f}h", font=ctk.CTkFont(size=10)).pack(side="top", anchor="w", padx=20)

    def _show_global_report(self):
        self._clear_content()
        teams = get_all_teams()
        
        for t in teams:
            t_data = get_team_report_data(t['id'], self.year)
            if not t_data: continue
            
            card = ctk.CTkFrame(self.content_frame)
            card.pack(fill="x", pady=5)
            
            ctk.CTkLabel(card, text=t['name'], font=ctk.CTkFont(size=13, weight="bold")).pack(side="left", padx=15, pady=10)
            
            # Carga media futura
            avg_load = 0
            count = 0
            for m in t_data['timeline']:
                if m['available_non_ops'] > 0:
                    avg_load += (m['total_assigned'] / m['available_non_ops'] * 100)
                    count += 1
            avg_load = (avg_load / count) if count > 0 else 0
            
            color = "#e74c3c" if avg_load > 100 else "#27ae60" if avg_load < 80 else "#f39c12"
            ctk.CTkLabel(card, text=f"Carga media: {avg_load:.1f}%", text_color=color).pack(side="right", padx=15)
            ctk.CTkLabel(card, text=f"Proyectos: {len(t_data['active_projects'])}").pack(side="right", padx=15)

    def _export_pdf(self):
        if not self.selected_team_id: return
        
        filename = f"Informe_{self.selected_team_id}_{self.year}.pdf"
        filepath = filedialog.asksaveasfilename(defaultextension=".pdf", initialfile=filename,
                                                filetypes=[("PDF files", "*.pdf")])
        if not filepath: return

        try:
            if self.selected_team_id == "GLOBAL":
                success = generate_global_pdf(self.year, filepath)
            else:
                success = generate_team_pdf(self.selected_team_id, self.year, filepath)
            
            if success:
                messagebox.showinfo("Éxito", f"Informe guardado en:\n{filepath}")
                if messagebox.askyesno("Abrir", "¿Deseas abrir el archivo ahora?"):
                    os.startfile(filepath)
        except Exception as e:
            messagebox.showerror("Error", f"No se pudo generar el PDF:\n{str(e)}")
