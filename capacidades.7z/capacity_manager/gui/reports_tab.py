"""
gui/reports_tab.py — Generación de informes detallados.
"""
import os
import customtkinter as ctk
from tkinter import messagebox, filedialog
from datetime import date
from db.models.teams import get_all_teams
from logic.report_logic import (
    get_team_report_data, generate_team_pdf, generate_global_pdf,
    get_inconsistent_estimates_data, generate_inconsistent_estimates_pdf,
    get_inactive_estimated_projects_data, generate_inactive_estimated_projects_pdf,
    get_capacity_deviation_data, generate_capacity_deviation_pdf,
    get_stopped_projects_data, generate_stopped_projects_pdf
)
from utils.date_utils import db_to_gui
from utils.gui_utils import Tooltip

class ReportsTab(ctk.CTkFrame):
    def __init__(self, master, **kwargs):
        super().__init__(master, **kwargs)
        self.selected_team_id = None
        self.team_buttons = {} # Para resaltar selección
        self.year = date.today().year
        self._build_ui()
        self.refresh()

    def _build_ui(self):
        self.grid_columnconfigure(0, weight=1)
        self.grid_columnconfigure(1, weight=4)
        self.grid_rowconfigure(0, weight=1)

        # ── Sidebar: Selección de Informe ─────────────────────────────
        sidebar = ctk.CTkFrame(self, width=200)
        sidebar.grid(row=0, column=0, sticky="nsew", padx=10, pady=10)
        sidebar.grid_rowconfigure(2, weight=1)

        ctk.CTkLabel(sidebar, text="Globales", font=ctk.CTkFont(size=12)).grid(row=1, column=0, pady=(10, 0))
        self.global_frame = ctk.CTkFrame(sidebar, fg_color="transparent")
        self.global_frame.grid(row=2, column=0, sticky="nsew", padx=5, pady=5)
        self.global_frame.grid_columnconfigure(0, weight=1)

        self.btn_global_carga = ctk.CTkButton(self.global_frame, text="🌍 Visión Global (Carga)", 
                                             command=lambda: self._select_global("GLOBAL_LOAD"), anchor="w", fg_color="transparent", text_color=("black", "white"))
        self.btn_global_carga.grid(row=0, column=0, padx=5, pady=2, sticky="ew")

        self.btn_global_inconsistent = ctk.CTkButton(self.global_frame, text="⚠️ Est. Inconsistentes", 
                                                    command=lambda: self._select_global("GLOBAL_INCONSISTENT"), anchor="w", fg_color="transparent", text_color=("black", "white"))
        self.btn_global_inconsistent.grid(row=1, column=0, padx=5, pady=2, sticky="ew")

        self.btn_global_inactive = ctk.CTkButton(self.global_frame, text="💤 Inactivos c/Estim.", 
                                                    command=lambda: self._select_global("GLOBAL_INACTIVE"), anchor="w", fg_color="transparent", text_color=("black", "white"))
        self.btn_global_inactive.grid(row=2, column=0, padx=5, pady=2, sticky="ew")

        self.btn_global_deviation = ctk.CTkButton(self.global_frame, text="📈 Desviaciones P/R", 
                                                   command=lambda: self._select_global("GLOBAL_DEVIATION"), anchor="w", fg_color="transparent", text_color=("black", "white"))
        self.btn_global_deviation.grid(row=3, column=0, padx=5, pady=2, sticky="ew")

        self.btn_global_stopped = ctk.CTkButton(self.global_frame, text="⏸ Proyectos Detenidos", 
                                                 command=lambda: self._select_global("GLOBAL_STOPPED"), anchor="w", fg_color="transparent", text_color=("black", "white"))
        self.btn_global_stopped.grid(row=4, column=0, padx=5, pady=2, sticky="ew")

        ctk.CTkLabel(sidebar, text="Por Equipo", font=ctk.CTkFont(size=12)).grid(row=3, column=0, pady=(10, 0))
        self.teams_frame = ctk.CTkScrollableFrame(sidebar)
        self.teams_frame.grid(row=4, column=0, sticky="nsew", padx=5, pady=5)
        self.teams_frame.grid_columnconfigure(0, weight=1)

        # ── Área Principal: Visualización ─────────────────────────────
        self.main_area = ctk.CTkScrollableFrame(self)
        self.main_area.grid(row=0, column=1, sticky="nsew", padx=10, pady=10)
        self.main_area.grid_columnconfigure(0, weight=1)

        # Barra de herramientas superior
        self.toolbar = ctk.CTkFrame(self.main_area, fg_color="transparent")
        self.toolbar.grid(row=0, column=0, sticky="ew", padx=10, pady=10)
        
        self.lbl_title = ctk.CTkLabel(self.toolbar, text="Selecciona un equipo para ver el informe", 
                                     font=ctk.CTkFont(size=16, weight="bold"))
        self.lbl_title.pack(side="left", padx=10)

        # Título y botón PDF ya están en la barra de herramientas

        self.btn_pdf = ctk.CTkButton(self.toolbar, text="📄 Exportar PDF", fg_color="#27ae60", 
                                     hover_color="#1e8449", command=self._export_pdf, state="disabled")
        self.btn_pdf.pack(side="right", padx=10)

        # Contenedor para el contenido dinámico
        self.content_frame = ctk.CTkFrame(self.main_area, fg_color="transparent")
        self.content_frame.grid(row=2, column=0, sticky="nsew", padx=10, pady=10)
        self.content_frame.grid_columnconfigure(0, weight=1)

    def refresh(self):
        for w in self.teams_frame.winfo_children():
            w.destroy()
        self.team_buttons = {} # Limpiar mapa
        
        teams = get_all_teams()
        for t in teams:
            btn = ctk.CTkButton(
                self.teams_frame, text=t["name"], anchor="w",
                fg_color="transparent", text_color=("black", "white"),
                hover_color=("gray80", "gray30"),
                command=lambda tid=t["id"]: self._select_team(tid)
            )
            btn.grid(sticky="ew", pady=1)
            self.team_buttons[t["id"]] = btn
            Tooltip(btn, t["name"])
            
        # Si no hay nada seleccionado, seleccionar global por defecto
        if self.selected_team_id is None:
            self._select_global("GLOBAL_LOAD")
        else:
            self._highlight_selection(self.selected_team_id)

    def _select_global(self, report_type):
        self.selected_team_id = report_type
        self._highlight_selection(report_type)
        if report_type == "GLOBAL_LOAD":
            self.lbl_title.configure(text="🌍 Visión Global de Capacidad")
        elif report_type == "GLOBAL_INCONSISTENT":
            self.lbl_title.configure(text="⚠️ Estimaciones Inconsistentes")
        elif report_type == "GLOBAL_INACTIVE":
            self.lbl_title.configure(text="💤 Equipos Inactivos con Estimación")
        elif report_type == "GLOBAL_DEVIATION":
            self.lbl_title.configure(text="📈 Desviaciones Previsto vs Real")
        elif report_type == "GLOBAL_STOPPED":
            self.lbl_title.configure(text="⏸ Proyectos Detenidos")
        self.btn_pdf.configure(state="normal")
        self._update_preview()

    def _select_team(self, team_id):
        self.selected_team_id = team_id
        self._highlight_selection(team_id)
        self.btn_pdf.configure(state="normal")
        self._update_preview()

    def _highlight_selection(self, selection_id):
        # Botones globales
        self.btn_global_carga.configure(fg_color="transparent")
        self.btn_global_inconsistent.configure(fg_color="transparent")
        self.btn_global_inactive.configure(fg_color="transparent")
        self.btn_global_deviation.configure(fg_color="transparent")
        self.btn_global_stopped.configure(fg_color="transparent")
        
        if selection_id == "GLOBAL_LOAD":
            self.btn_global_carga.configure(fg_color=["#3b8ed0", "#1f538d"])
        elif selection_id == "GLOBAL_INCONSISTENT":
            self.btn_global_inconsistent.configure(fg_color=["#3b8ed0", "#1f538d"])
        elif selection_id == "GLOBAL_INACTIVE":
            self.btn_global_inactive.configure(fg_color=["#3b8ed0", "#1f538d"])
        elif selection_id == "GLOBAL_DEVIATION":
            self.btn_global_deviation.configure(fg_color=["#3b8ed0", "#1f538d"])
        elif selection_id == "GLOBAL_STOPPED":
            self.btn_global_stopped.configure(fg_color=["#3b8ed0", "#1f538d"])
            
        # Botones de equipo
        for tid, btn in self.team_buttons.items():
            btn.configure(fg_color="transparent")
            
        if selection_id in self.team_buttons:
            self.team_buttons[selection_id].configure(fg_color="#34495e")

    def _update_preview(self):
        if self.selected_team_id == "GLOBAL_LOAD":
            self._show_global_report()
        elif self.selected_team_id == "GLOBAL_INCONSISTENT":
            self._show_inconsistent_estimates_report()
        elif self.selected_team_id == "GLOBAL_INACTIVE":
            self._show_inactive_estimated_report()
        elif self.selected_team_id == "GLOBAL_DEVIATION":
            self._show_deviation_report()
        elif self.selected_team_id == "GLOBAL_STOPPED":
            self._show_stopped_report()
        elif self.selected_team_id and isinstance(self.selected_team_id, int):
            self._show_team_report(self.selected_team_id)

    def _clear_content(self):
        for w in self.content_frame.winfo_children():
            w.destroy()

    def _show_team_report(self, team_id):
        self._clear_content()
        data = get_team_report_data(team_id, self.year)
        if not data: return

        self.lbl_title.configure(text=f"Informe: {data['team']['name']}")

        # 1. Resumen Ficha
        f1 = ctk.CTkFrame(self.content_frame)
        f1.grid(row=0, column=0, sticky="ew", pady=10)
        ctk.CTkLabel(f1, text="Resumen de Recursos", font=ctk.CTkFont(weight="bold")).pack(pady=5)
        
        t = data['team']
        txt = (f"Internos: {t['internal_people']} ({t['internal_annual_hours']:.0f}h)   |   "
               f"Baseline: {t['baseline_people']} ({t['baseline_annual_hours']:.0f}h)   |   "
               f"Refuerzo: {t['reinforce_people']} ({t['reinforce_annual_hours']:.0f}h)\n"
               f"Total: {data['summary']['total_hours']:.1f}h/año   |   "
               f"Op: {data['summary']['ops_hours']:.1f}h ({t['ops_percentage']}%)   |   "
               f"Proyectos: {data['summary']['non_ops_hours']:.1f}h")
        ctk.CTkLabel(f1, text=txt, justify="center").pack(pady=10)

        # 2. Proyectos Activos
        f2 = ctk.CTkFrame(self.content_frame)
        f2.grid(row=1, column=0, sticky="ew", pady=10)
        ctk.CTkLabel(f2, text="Proyectos con Carga Pendiente o en Curso", font=ctk.CTkFont(weight="bold")).pack(pady=5)
        
        if not data['active_projects']:
            ctk.CTkLabel(f2, text="No hay proyectos activos registrados para este equipo.").pack(pady=10)
        else:
            p_frame = ctk.CTkFrame(f2, fg_color="transparent")
            p_frame.pack(fill="x", padx=10, pady=10)
            
            # Cabecera tabla
            cols = ["Proyecto", "Tipo", "Fin", "Estimado", "Pendiente", "Estado"]
            widths = [180, 50, 80, 70, 70, 90]
            for i, (col, w) in enumerate(zip(cols, widths)):
                ctk.CTkLabel(p_frame, text=col, width=w, font=ctk.CTkFont(size=11, weight="bold"), anchor="w").grid(row=0, column=i, padx=5, sticky="w")
            
            row_idx = 1
            for p in data['active_projects']:
                title = p['project_title']
                if p['typology'] == "PIPE" and p.get('entregable'):
                    title = p['entregable']
                if p.get('id_proyecto', 0) > 0: 
                    title = f"#{p['id_proyecto']} {title}"
                
                ctk.CTkLabel(p_frame, text=title[:40], width=180, font=ctk.CTkFont(size=11), anchor="w").grid(row=row_idx, column=0, padx=5, sticky="w")
                ctk.CTkLabel(p_frame, text=p['typology'], width=50, font=ctk.CTkFont(size=11)).grid(row=row_idx, column=1, padx=5)
                ctk.CTkLabel(p_frame, text=db_to_gui(p['end']) if p['end'] else "-", width=80, font=ctk.CTkFont(size=11)).grid(row=row_idx, column=2, padx=5)
                ctk.CTkLabel(p_frame, text=f"{p['estimated']:.0f}h", width=70, font=ctk.CTkFont(size=11)).grid(row=row_idx, column=3, padx=5)
                ctk.CTkLabel(p_frame, text=f"{p['remaining']:.0f}h", width=70, font=ctk.CTkFont(size=11, weight="bold")).grid(row=row_idx, column=4, padx=5)
                ctk.CTkLabel(p_frame, text=p['status_name'], width=90, font=ctk.CTkFont(size=10)).grid(row=row_idx, column=5, padx=5)
                row_idx += 1

        # 3. Timeline de Carga
        f3 = ctk.CTkFrame(self.content_frame)
        f3.grid(row=2, column=0, sticky="ew", pady=10)
        ctk.CTkLabel(f3, text="Timeline de Carga Mensual (Proyectos)", font=ctk.CTkFont(weight="bold")).pack(pady=5)
        
        for m in data['timeline']:
            m_frame = ctk.CTkFrame(f3, fg_color=("gray90", "gray25"))
            m_frame.pack(fill="x", padx=10, pady=5)
            
            load = (m['total_assigned'] / m['available_non_ops'] * 100) if m['available_non_ops'] > 0 else 0
            color = "#e74c3c" if load > 100 else "#27ae60" if load < 80 else "#f39c12"
            
            title_txt = f"Mes {m['month']}  —  Disp: {m['available_non_ops']:.1f}h  |  Carga: {load:.1f}%"
            ctk.CTkLabel(m_frame, text=title_txt, font=ctk.CTkFont(weight="bold"), text_color=color).pack(side="top", anchor="w", padx=10)
            
            if not m['projects']:
                ctk.CTkLabel(m_frame, text="   (Sin carga)", font=ctk.CTkFont(size=10, slant="italic")).pack(side="top", anchor="w", padx=20)
            else:
                for p in m['projects']:
                    ctk.CTkLabel(m_frame, text=f"   • {p['title']}: {p['hours']:.1f}h", font=ctk.CTkFont(size=10)).pack(side="top", anchor="w", padx=20)

    def _show_global_report(self):
        self._clear_content()
        teams = get_all_teams()
        
        for t in teams:
            t_data = get_team_report_data(t['id'], self.year)
            if not t_data: continue
            
            card = ctk.CTkFrame(self.content_frame)
            card.pack(fill="x", pady=5)
            
            ctk.CTkLabel(card, text=t['name'], font=ctk.CTkFont(size=13, weight="bold")).pack(side="left", padx=15, pady=10)
            
            # Carga media futura
            avg_load = 0
            count = 0
            for m in t_data['timeline']:
                if m['available_non_ops'] > 0:
                    avg_load += (m['total_assigned'] / m['available_non_ops'] * 100)
                    count += 1
            avg_load = (avg_load / count) if count > 0 else 0
            
            color = "#e74c3c" if avg_load > 100 else "#27ae60" if avg_load < 80 else "#f39c12"
            ctk.CTkLabel(card, text=f"Carga media: {avg_load:.1f}%", text_color=color).pack(side="right", padx=15)
            ctk.CTkLabel(card, text=f"Proyectos: {len(t_data['active_projects'])}").pack(side="right", padx=15)

    def _show_inconsistent_estimates_report(self):
        self._clear_content()
        data = get_inconsistent_estimates_data()
        
        if not data:
            ctk.CTkLabel(self.content_frame, text="✅ No se han detectado inconsistencias en las estimaciones.", font=ctk.CTkFont(size=14)).pack(pady=20)
            return

        for item in data:
            s = item['solicitud']
            card = ctk.CTkFrame(self.content_frame)
            card.pack(fill="x", pady=5)
            
            lbl_sol = ctk.CTkLabel(card, text=f"📂 Solicitud: {s['title']} ({s['status_name']})", font=ctk.CTkFont(size=13, weight="bold"))
            lbl_sol.pack(side="top", anchor="w", padx=15, pady=5)

            # Contenedor para dedicaciones
            deds_frame = ctk.CTkFrame(card, fg_color="transparent")
            deds_frame.pack(side="top", fill="x", padx=30, pady=5)

            # Con estimación
            ctk.CTkLabel(deds_frame, text="Dedicaciones con estimación:", font=ctk.CTkFont(size=11, weight="bold"), text_color="#27ae60").grid(row=0, column=0, sticky="w")
            txt_with = ", ".join([f"{d['team_name']} ({d['estimated_hours']}h)" for d in item['projs_with']])
            ctk.CTkLabel(deds_frame, text=txt_with, font=ctk.CTkFont(size=11), wraplength=400, justify="left").grid(row=1, column=0, sticky="w", padx=10)

            # Sin estimación
            ctk.CTkLabel(deds_frame, text="Dedicaciones SIN estimación:", font=ctk.CTkFont(size=11, weight="bold"), text_color="#e74c3c").grid(row=2, column=0, sticky="w", pady=(5,0))
            txt_without = ", ".join([d['team_name'] for d in item['projs_without']])
            ctk.CTkLabel(deds_frame, text=txt_without, font=ctk.CTkFont(size=11), wraplength=400, justify="left").grid(row=3, column=0, sticky="w", padx=10)

    def _show_inactive_estimated_report(self):
        self._clear_content()
        data = get_inactive_estimated_projects_data()
        
        if not data:
            ctk.CTkLabel(self.content_frame, text="✅ No se han detectado equipos inactivos con estimación.", font=ctk.CTkFont(size=14)).pack(pady=20)
            return

        current_sol = None
        card = None
        for item in data:
            if current_sol != item['solicitud_title']:
                current_sol = item['solicitud_title']
                card = ctk.CTkFrame(self.content_frame)
                card.pack(fill="x", pady=5)
                lbl_sol = ctk.CTkLabel(card, text=f"📂 Solicitud: {current_sol}", font=ctk.CTkFont(size=13, weight="bold"))
                lbl_sol.pack(side="top", anchor="w", padx=15, pady=5)
                
            teams_frame = ctk.CTkFrame(card, fg_color="transparent")
            teams_frame.pack(side="top", fill="x", padx=30, pady=2)
            
            last_imp = db_to_gui(item['last_imputation']) if item['last_imputation'] else "Nunca"
            name = item['team_name']
            if item['id_proyecto'] > 0: name = f"#{item['id_proyecto']} {name}"
            info_txt = f"[{item['status_name']}] {name}  |  Estimado: {item['estimated_hours']}h  |  Última Imputación: {last_imp}"
            ctk.CTkLabel(teams_frame, text=info_txt, font=ctk.CTkFont(size=11), text_color="#e74c3c").pack(side="left", anchor="w", padx=5)

    def _show_deviation_report(self):
        """Vista previa del informe de desviaciones Previsto vs Real."""
        self._clear_content()
        data = get_capacity_deviation_data(self.year)

        if not data:
            ctk.CTkLabel(self.content_frame, text="No hay datos de desviación disponibles.",
                         font=ctk.CTkFont(size=14)).pack(pady=20)
            return

        MONTHS_ES = ["Ene", "Feb", "Mar", "Abr", "May", "Jun",
                     "Jul", "Ago", "Sep", "Oct", "Nov", "Dic"]

        for team_data in data:
            card = ctk.CTkFrame(self.content_frame)
            card.pack(fill="x", pady=8, padx=5)

            ctk.CTkLabel(card, text=f"Equipo: {team_data['team_name']}",
                         font=ctk.CTkFont(size=13, weight="bold")).pack(anchor="w", padx=15, pady=(10, 5))

            table = ctk.CTkFrame(card, fg_color="transparent")
            table.pack(fill="x", padx=15, pady=5)

            # Cabecera
            headers = ["Mes", "Prev.", "Real", "Desv.", "%"]
            for i, h in enumerate(headers):
                ctk.CTkLabel(table, text=h, width=60, font=ctk.CTkFont(size=10, weight="bold")).grid(row=0, column=i, padx=3)

            for idx, m in enumerate(team_data["months"]):
                row = idx + 1
                is_past = m["is_past"]
                p_total = m["planned_total"]
                a_total = m["actual_total"]

                ctk.CTkLabel(table, text=MONTHS_ES[m["month"]-1], width=60, font=ctk.CTkFont(size=10)).grid(row=row, column=0, padx=3)

                if not is_past or (p_total == 0 and a_total == 0):
                    for col in range(1, 5):
                        ctk.CTkLabel(table, text="—", width=60, text_color="gray", font=ctk.CTkFont(size=10)).grid(row=row, column=col, padx=3)
                else:
                    ctk.CTkLabel(table, text=f"{p_total:.0f}h", width=60, font=ctk.CTkFont(size=10)).grid(row=row, column=1, padx=3)
                    ctk.CTkLabel(table, text=f"{a_total:.0f}h", width=60, font=ctk.CTkFont(size=10)).grid(row=row, column=2, padx=3)
                    dev = m["deviation"]
                    dev_pct = m["deviation_pct"]
                    sign = "+" if dev >= 0 else ""
                    color = "#1e8449" if abs(dev_pct) <= 10 else "#d4ac0d" if abs(dev_pct) <= 25 else "#c0392b"
                    ctk.CTkLabel(table, text=f"{sign}{dev:.0f}h", width=60, text_color=color, font=ctk.CTkFont(size=10, weight="bold")).grid(row=row, column=3, padx=3)
                    ctk.CTkLabel(table, text=f"{sign}{dev_pct:.0f}%", width=60, text_color=color, font=ctk.CTkFont(size=10, weight="bold")).grid(row=row, column=4, padx=3)

    def _show_stopped_report(self):
        """Vista previa de proyectos detenidos."""
        self._clear_content()
        data = get_stopped_projects_data()

        if not data:
            ctk.CTkLabel(self.content_frame, text="✅ No hay proyectos detenidos actualmente.",
                         font=ctk.CTkFont(size=14)).pack(pady=20)
            return

        table = ctk.CTkFrame(self.content_frame, fg_color="transparent")
        table.pack(fill="x", padx=10, pady=10)

        headers = ["Proyecto", "Equipo", "Est.", "Imp.", "Rest.", "Últ. Imp."]
        widths = [180, 100, 60, 60, 60, 90]
        for i, (h, w) in enumerate(zip(headers, widths)):
            ctk.CTkLabel(table, text=h, width=w, font=ctk.CTkFont(size=11, weight="bold"), anchor="w").grid(row=0, column=i, padx=5, sticky="w")

        for idx, item in enumerate(data, 1):
            ctk.CTkLabel(table, text=item["project_title"][:40], width=180, font=ctk.CTkFont(size=10), anchor="w").grid(row=idx, column=0, padx=5, sticky="w")
            ctk.CTkLabel(table, text=item["team_name"][:20], width=100, font=ctk.CTkFont(size=10), anchor="w").grid(row=idx, column=1, padx=5, sticky="w")
            ctk.CTkLabel(table, text=f"{item['estimated_hours']:.0f}h", width=60, font=ctk.CTkFont(size=10)).grid(row=idx, column=2, padx=5)
            ctk.CTkLabel(table, text=f"{item['imputed_hours']:.0f}h", width=60, font=ctk.CTkFont(size=10)).grid(row=idx, column=3, padx=5)
            ctk.CTkLabel(table, text=f"{item['remaining_hours']:.0f}h", width=60, font=ctk.CTkFont(size=10, weight="bold"), text_color="#e74c3c").grid(row=idx, column=4, padx=5)
            last = db_to_gui(item["last_imputation"]) if item["last_imputation"] and item["last_imputation"] != "-" else "Nunca"
            ctk.CTkLabel(table, text=last, width=90, font=ctk.CTkFont(size=10)).grid(row=idx, column=5, padx=5)

    def _export_pdf(self):
        if self.selected_team_id == "GLOBAL_LOAD":
            team_name = "Global_Carga"
        elif self.selected_team_id == "GLOBAL_INCONSISTENT":
            team_name = "Estimaciones_Inconsistentes"
        elif self.selected_team_id == "GLOBAL_DEVIATION":
            team_name = "Desviaciones_Previsto_Real"
        elif self.selected_team_id == "GLOBAL_STOPPED":
            team_name = "Proyectos_Detenidos"
        elif isinstance(self.selected_team_id, int):
            team_data = get_team_report_data(self.selected_team_id, self.year)
            team_name = team_data['team']['name'] if team_data else str(self.selected_team_id)
        else:
            return
        
        # Sanitizar nombre de equipo para archivo
        safe_name = "".join([c for c in team_name if c.isalnum() or c in (' ', '_')]).rstrip().replace(' ', '_')
        filename = f"Informe_{safe_name}_{self.year}.pdf"
        filepath = filedialog.asksaveasfilename(defaultextension=".pdf", initialfile=filename,
                                                filetypes=[("PDF files", "*.pdf")])
        if not filepath: return

        try:
            if self.selected_team_id == "GLOBAL_LOAD":
                success = generate_global_pdf(self.year, filepath)
            elif self.selected_team_id == "GLOBAL_INCONSISTENT":
                success = generate_inconsistent_estimates_pdf(filepath)
            elif self.selected_team_id == "GLOBAL_INACTIVE":
                success = generate_inactive_estimated_projects_pdf(filepath)
            elif self.selected_team_id == "GLOBAL_DEVIATION":
                success = generate_capacity_deviation_pdf(self.year, filepath)
            elif self.selected_team_id == "GLOBAL_STOPPED":
                success = generate_stopped_projects_pdf(filepath)
            else:
                success = generate_team_pdf(self.selected_team_id, self.year, filepath)
            
            if success:
                messagebox.showinfo("Éxito", f"Informe guardado en:\n{filepath}")
                if messagebox.askyesno("Abrir", "¿Deseas abrir el archivo ahora?"):
                    os.startfile(filepath)
        except Exception as e:
            messagebox.showerror("Error", f"No se pudo generar el PDF:\n{str(e)}")
