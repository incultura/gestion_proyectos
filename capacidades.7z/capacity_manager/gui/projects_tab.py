import customtkinter as ctk
from tkinter import messagebox, filedialog
import webbrowser
import os
from db.models.solicitudes import get_all_solicitudes, get_solicitud
from db.models.teams import get_all_teams
from db.models.projects import (
    get_projects_by_solicitud, create_project,
    update_project, delete_project, get_project_by_id_pry
)
from db.models.dedications import (
    get_dedications_by_project, create_dedication,
    update_dedication, delete_dedication, get_imputed_hours
)
from db.models.statuses import get_all_statuses, get_status_id_by_name
from db.models.config import get_config
from db.models.deliverables import get_deliverables_by_solicitud
from db.models.dependencies import (
    get_all_dependencies, get_project_dependencies,
    associate_project_dependency, remove_project_dependency
)
from utils.date_utils import gui_to_db, db_to_gui, get_today_gui
from utils.gui_utils import Tooltip, DateEntry


class ProjectsTab(ctk.CTkFrame):
    def __init__(self, master, **kwargs):
        super().__init__(master, **kwargs)
        self.selected_solicitud_id = None
        self.selected_project_id = None
        self.selected_dedication_id = None
        
        self.solicitudes_raw = []
        self.projects_raw = []
        self.dedications_raw = []
        
        self.sol_buttons = {}
        self.proj_buttons = {}
        self.ded_buttons = {}
        
        self._team_name_to_id = {}
        self._team_id_to_name = {}
        
        self._build_ui()
        self.refresh()

    def refresh(self):
        self.solicitudes_raw = get_all_solicitudes()
        self.refresh_solicitudes_list()
        self._refresh_teams()
        self._refresh_statuses()
        self._refresh_dependency_menu()

    def _refresh_dependency_menu(self):
        deps = get_all_dependencies()
        names = [d["name"] for d in deps]
        if names:
            self.proj_dep_menu.configure(values=names)
            self.proj_dep_var.set("Seleccionar...")
        else:
            self.proj_dep_menu.configure(values=["—"])
            self.proj_dep_var.set("—")

    def _refresh_teams(self):
        teams = get_all_teams()
        self._team_name_to_id = {t["name"]: t["id"] for t in teams}
        self._team_id_to_name = {t["id"]: t["name"] for t in teams}
        self.team_menu.configure(values=sorted(list(self._team_name_to_id.keys())))

    def _refresh_statuses(self):
        st = get_all_statuses()
        self.status_menu.configure(values=[s["name"] for s in st])

    def _build_ui(self):
        self.grid_columnconfigure(0, weight=1)
        self.grid_columnconfigure(1, weight=3) # Más peso al centro
        self.grid_columnconfigure(2, weight=1) # Menos peso a dedicaciones
        self.grid_rowconfigure(0, weight=1)

        # ── PANEL 1: Solicitudes ───────────────────────────────────────
        col1 = ctk.CTkFrame(self)
        col1.grid(row=0, column=0, sticky="nsew", padx=(10, 4), pady=10)
        col1.grid_rowconfigure(1, weight=1)
        col1.grid_columnconfigure(0, weight=1)
        
        ctk.CTkLabel(col1, text="1. Solicitudes", font=ctk.CTkFont(size=14, weight="bold")).grid(
            row=0, column=0, sticky="w", padx=8, pady=(8, 4))
        
        self.sol_frame = ctk.CTkScrollableFrame(col1)
        self.sol_frame.grid(row=1, column=0, sticky="nsew", padx=4, pady=4)
        self.sol_frame.grid_columnconfigure(0, weight=1)

        search_frame = ctk.CTkFrame(col1, fg_color="transparent")
        search_frame.grid(row=2, column=0, sticky="ew", padx=8, pady=2)
        self.search_var = ctk.StringVar()
        self.search_var.trace_add("write", lambda *args: self.refresh_solicitudes_list())
        ctk.CTkEntry(search_frame, placeholder_text="🔍 Buscar...", textvariable=self.search_var).pack(fill="x")

        # ── PANEL 2: Proyectos de Solicitud ────────────────────────────
        col2 = ctk.CTkFrame(self)
        col2.grid(row=0, column=1, sticky="nsew", padx=4, pady=10)
        col2.grid_rowconfigure(1, weight=1)
        col2.grid_columnconfigure(0, weight=1)
        
        ctk.CTkLabel(col2, text="2. Proyectos", font=ctk.CTkFont(size=14, weight="bold")).grid(
            row=0, column=0, sticky="w", padx=8, pady=(8, 4))
        
        self.proj_frame = ctk.CTkScrollableFrame(col2)
        self.proj_frame.grid(row=1, column=0, sticky="nsew", padx=4, pady=4)
        self.proj_frame.grid_columnconfigure(0, weight=1)
        
        # Formulario Proyecto Enriquecido
        proj_form_container = ctk.CTkFrame(col2)
        proj_form_container.grid(row=2, column=0, sticky="ew", padx=4, pady=4)
        proj_form_container.grid_columnconfigure(0, weight=1)

        proj_form = ctk.CTkFrame(proj_form_container, fg_color="transparent")
        proj_form.pack(fill="x", padx=5, pady=5)
        proj_form.grid_columnconfigure(1, weight=1)
        
        # Fila 1: ID y Título
        ctk.CTkLabel(proj_form, text="ID de Proyecto").grid(row=0, column=0, padx=5, pady=2, sticky="w")
        id_row = ctk.CTkFrame(proj_form, fg_color="transparent")
        id_row.grid(row=0, column=1, sticky="ew")
        id_row.grid_columnconfigure(0, weight=1)
        
        self.proj_id_entry = ctk.CTkEntry(id_row, width=80)
        self.proj_id_entry.grid(row=0, column=0, sticky="w")
        
        self.btn_proj_link = ctk.CTkButton(id_row, text="🔗", width=30, command=self._open_project_link)
        self.btn_proj_link.grid(row=0, column=1, padx=(5, 0))
        
        # Fila 2: Título
        ctk.CTkLabel(proj_form, text="Título").grid(row=1, column=0, padx=5, pady=2, sticky="w")
        self.proj_title_entry = ctk.CTkEntry(proj_form)
        self.proj_title_entry.grid(row=1, column=1, sticky="ew", padx=5, pady=2)
        
        # Fila 3: Entregable (Solo PIPE)
        self.lbl_entregable = ctk.CTkLabel(proj_form, text="Entregable")
        self.lbl_entregable.grid(row=2, column=0, padx=5, pady=2, sticky="w")
        self.ent_var = ctk.StringVar(value="—")
        self.ent_menu = ctk.CTkOptionMenu(proj_form, variable=self.ent_var, values=["—"])
        self.ent_menu.grid(row=2, column=1, sticky="ew", padx=5, pady=2)
        
        # Fila 4: Descripción (Reducir altura para dar espacio a la lista)
        ctk.CTkLabel(proj_form, text="Descripción").grid(row=3, column=0, padx=5, pady=2, sticky="nw")
        self.proj_desc_text = ctk.CTkTextbox(proj_form, height=90)
        self.proj_desc_text.grid(row=3, column=1, sticky="ew", padx=5, pady=2)
        
        # Fila 5: Dependencias del Proyecto (Más compactas)
        dep_container = ctk.CTkFrame(proj_form_container, fg_color="transparent")
        dep_container.pack(fill="x", padx=5, pady=(2, 5))
        
        header_dep = ctk.CTkFrame(dep_container, fg_color="transparent")
        header_dep.pack(fill="x")
        ctk.CTkLabel(header_dep, text="Dependencias:", font=ctk.CTkFont(size=12, weight="bold")).pack(side="left")
        
        self.proj_dep_list = ctk.CTkScrollableFrame(dep_container, height=50)
        self.proj_dep_list.pack(fill="x", pady=2)
        self.proj_dep_list.grid_columnconfigure(0, weight=1)
        
        add_dep_row = ctk.CTkFrame(dep_container, fg_color="transparent")
        add_dep_row.pack(fill="x")
        self.proj_dep_var = ctk.StringVar(value="Seleccionar...")
        self.proj_dep_menu = ctk.CTkOptionMenu(add_dep_row, variable=self.proj_dep_var, values=["—"])
        self.proj_dep_menu.pack(side="left", fill="x", expand=True, padx=(0, 5))
        self.btn_add_proj_dep = ctk.CTkButton(add_dep_row, text="➕", width=30, command=self._add_project_dependency, state="disabled")
        self.btn_add_proj_dep.pack(side="right")

        proj_btns = ctk.CTkFrame(col2, fg_color="transparent")
        proj_btns.grid(row=3, column=0, sticky="ew", padx=4, pady=2)
        ctk.CTkButton(proj_btns, text="Nuevo Proyecto", width=120, command=self._new_project).pack(side="left", padx=2)
        ctk.CTkButton(proj_btns, text="Guardar Proyecto", width=120, command=self._save_project).pack(side="left", padx=2)
        
        self.btn_export_pdf = ctk.CTkButton(proj_btns, text="📄 PDF", width=60, fg_color="#2e7d32", hover_color="#1b5e20",
                                           command=self._export_pdf, state="disabled")
        self.btn_export_pdf.pack(side="left", padx=2)
        
        ctk.CTkButton(proj_btns, text="🗑", width=40, fg_color="#c0392b", command=self._delete_project).pack(side="right", padx=2)

        # ── PANEL 3: Dedicaciones ──────────────────────────────────────
        col3 = ctk.CTkFrame(self)
        col3.grid(row=0, column=2, sticky="nsew", padx=(4, 10), pady=10)
        col3.grid_rowconfigure(1, weight=1)
        col3.grid_columnconfigure(0, weight=1)
        
        ctk.CTkLabel(col3, text="3. Dedicaciones", font=ctk.CTkFont(size=14, weight="bold")).grid(
            row=0, column=0, sticky="w", padx=8, pady=(8, 4))
        
        self.ded_frame = ctk.CTkScrollableFrame(col3)
        self.ded_frame.grid(row=1, column=0, sticky="nsew", padx=4, pady=4)
        self.ded_frame.grid_columnconfigure(0, weight=1)
        
        # Formulario Dedicación
        ded_form = ctk.CTkFrame(col3)
        ded_form.grid(row=2, column=0, sticky="ew", padx=4, pady=4)
        ded_form.grid_columnconfigure(1, weight=1)
        ded_form.grid_columnconfigure(3, weight=1)
        
        ctk.CTkLabel(ded_form, text="Equipo").grid(row=0, column=0, padx=5, pady=2)
        self.team_var = ctk.StringVar(value="—")
        self.team_menu = ctk.CTkOptionMenu(ded_form, variable=self.team_var, values=["—"])
        self.team_menu.grid(row=0, column=1, sticky="ew", padx=5, pady=2)
        
        ctk.CTkLabel(ded_form, text="Estado").grid(row=0, column=2, padx=5, pady=2)
        self.status_var = ctk.StringVar(value="—")
        self.status_menu = ctk.CTkOptionMenu(ded_form, variable=self.status_var, values=["—"])
        self.status_menu.grid(row=0, column=3, sticky="ew", padx=5, pady=2)
        
        ctk.CTkLabel(ded_form, text="Inicio").grid(row=1, column=0, padx=5, pady=2)
        self.start_entry = DateEntry(ded_form, placeholder_text="DD-MM-YYYY")
        self.start_entry.grid(row=1, column=1, sticky="ew", padx=5, pady=2)
        
        ctk.CTkLabel(ded_form, text="Fin").grid(row=1, column=2, padx=5, pady=2)
        self.end_entry = DateEntry(ded_form, placeholder_text="DD-MM-YYYY")
        self.end_entry.grid(row=1, column=3, sticky="ew", padx=5, pady=2)
        
        ctk.CTkLabel(ded_form, text="Horas Est.").grid(row=2, column=0, padx=5, pady=2)
        self.est_hours_entry = ctk.CTkEntry(ded_form)
        self.est_hours_entry.grid(row=2, column=1, sticky="ew", padx=5, pady=2)
        
        self.lbl_stats = ctk.CTkLabel(ded_form, text="Imp: 0h | Rest: 0h", font=ctk.CTkFont(size=11))
        self.lbl_stats.grid(row=2, column=2, columnspan=2, padx=5, pady=2)
        
        ded_btns = ctk.CTkFrame(col3, fg_color="transparent")
        ded_btns.grid(row=3, column=0, sticky="ew", padx=4, pady=2)
        ctk.CTkButton(ded_btns, text="Nueva Dedicación", width=120, command=self._new_dedication).pack(side="left", padx=2)
        ctk.CTkButton(ded_btns, text="Guardar", width=70, command=self._save_dedication).pack(side="left", padx=2)
        ctk.CTkButton(ded_btns, text="🗑", width=40, fg_color="#c0392b", command=self._delete_dedication).pack(side="left", padx=2)

    # ── LÓGICA SOLICITUDES ──────────────────────────────────────────
    def refresh_solicitudes_list(self):
        for w in self.sol_frame.winfo_children(): w.destroy()
        self.sol_buttons = {}
        search = self.search_var.get().lower()
        
        TYPOLOGY_COLORS = {
            "Operacion": "#1a5276",
            "PIPE": "#145a32",
            "Regulatorio": "#6e2f1a",
            "TTM": "#4a235a",
        }
        
        for s in self.solicitudes_raw:
            if search and search not in s["title"].lower(): continue
            
            id_sol = s.get("id_solicitud", 0)
            id_str = f"#{id_sol} " if id_sol > 0 else ""
            prefix = f"[{s['typology']}] {id_str}"
            max_total = 32
            max_title = max_total - len(prefix)
            display_title = s['title']
            if len(display_title) > max_title:
                display_title = display_title[:max_title-3] + "..."
            
            btn = ctk.CTkButton(
                self.sol_frame, text=prefix + display_title, anchor="w",
                fg_color=TYPOLOGY_COLORS.get(s["typology"], "gray30"),
                command=lambda sid=s["id"]: self._select_solicitud(sid)
            )
            btn.grid(sticky="ew", pady=1)
            self.sol_buttons[s["id"]] = btn
            Tooltip(btn, s["title"])
        
        if self.selected_solicitud_id:
            self._highlight_sol(self.selected_solicitud_id)

    def _open_project_link(self):
        try:
            val = self.proj_id_entry.get().strip()
            if not val or val == "0": return
            base_url = get_config("base_url_solicitud", "").strip()
            if not base_url:
                messagebox.showwarning("Config", "Defina 'base_url_solicitud' en Config.")
                return
            webbrowser.open(base_url + val)
        except: pass

    def _select_solicitud(self, sol_id):
        self.selected_solicitud_id = sol_id
        self._highlight_sol(sol_id)
        self.selected_project_id = None
        self.selected_dedication_id = None
        self._new_project()
        self._refresh_projects_list()
        
        # Actualizar entregables si es PIPE
        sol = get_solicitud(sol_id)
        if sol and sol["typology"] == "PIPE":
            ents = get_deliverables_by_solicitud(sol_id)
            vals = ["—"] + [e["name"] for e in ents]
            self.ent_menu.configure(values=vals)
            self.lbl_entregable.grid()
            self.ent_menu.grid()
        else:
            self.lbl_entregable.grid_remove()
            self.ent_menu.grid_remove()
        
        self.btn_add_proj_dep.configure(state="disabled") # Hasta que se seleccione proyecto

    def _highlight_sol(self, sol_id):
        for sid, b in self.sol_buttons.items(): b.configure(fg_color="transparent")
        if sol_id in self.sol_buttons: self.sol_buttons[sol_id].configure(fg_color="#34495e")

    # ── LÓGICA PROYECTOS ───────────────────────────────────────────
    def _refresh_projects_list(self):
        for w in self.proj_frame.winfo_children(): w.destroy()
        self.proj_buttons = {}
        if not self.selected_solicitud_id: return
        
        sol = get_solicitud(self.selected_solicitud_id)
        is_pipe = sol and sol["typology"] == "PIPE"
        
        self.projects_raw = get_projects_by_solicitud(self.selected_solicitud_id)
        for p in self.projects_raw:
            content = p['entregable'] if is_pipe and p.get('entregable') else p['title']
            lbl = f"#{p['id_proyecto']} | {content}"
            btn = ctk.CTkButton(self.proj_frame, text=lbl, anchor="w", fg_color="transparent",
                               text_color=("black", "white"), hover_color=("gray80", "gray30"),
                               command=lambda pr=p: self._select_project(pr))
            btn.grid(sticky="ew", pady=1)
            self.proj_buttons[p["id"]] = btn
            if p.get("description"): Tooltip(btn, p["description"])

    def _select_project(self, project):
        self.selected_project_id = project["id"]
        self._highlight_proj(project["id"])
        self.selected_dedication_id = None
        
        # Cargar form proyecto
        self.proj_id_entry.delete(0, "end")
        self.proj_id_entry.insert(0, str(project["id_proyecto"]))
        self.proj_title_entry.delete(0, "end")
        self.proj_title_entry.insert(0, project["title"])
        
        desc = project.get("description", "")
        self.proj_desc_text.delete("1.0", "end")
        self.proj_desc_text.insert("1.0", desc)
        
        self.ent_var.set(project.get("entregable") or "—")
        
        self.btn_proj_link.configure(state="normal" if project["id_proyecto"] > 0 else "disabled")
        self.btn_add_proj_dep.configure(state="normal")
        self.btn_export_pdf.configure(state="normal")
        self._refresh_project_dependencies()
        
        self._refresh_dedications_list()
        self._new_dedication()

    def _refresh_project_dependencies(self):
        for w in self.proj_dep_list.winfo_children():
            w.destroy()
        if not self.selected_project_id: return
        
        deps = get_project_dependencies(self.selected_project_id)
        for d in deps:
            row = ctk.CTkFrame(self.proj_dep_list, fg_color="transparent")
            row.pack(fill="x", pady=1)
            ctk.CTkLabel(row, text=f"• {d['name']}", font=ctk.CTkFont(size=12)).pack(side="left", padx=5)
            ctk.CTkButton(row, text="✕", width=18, height=18, fg_color="#c0392b", hover_color="#922b21",
                          command=lambda did=d['id']: self._remove_project_dependency(did)).pack(side="right", padx=5)

    def _add_project_dependency(self):
        if not self.selected_project_id: return
        dep_name = self.proj_dep_var.get()
        if dep_name in ["Seleccionar...", "—"]: return
        
        all_deps = get_all_dependencies()
        dep = next((d for d in all_deps if d["name"] == dep_name), None)
        if dep:
            associate_project_dependency(self.selected_project_id, dep["id"])
            self._refresh_project_dependencies()

    def _remove_project_dependency(self, dependency_id):
        if not self.selected_project_id: return
        remove_project_dependency(self.selected_project_id, dependency_id)
        self._refresh_project_dependencies()

    def _highlight_proj(self, pr_id):
        for pid, b in self.proj_buttons.items(): b.configure(fg_color="transparent")
        if pr_id in self.proj_buttons: self.proj_buttons[pr_id].configure(fg_color="#34495e")

    def _new_project(self):
        self.selected_project_id = None
        self.proj_id_entry.delete(0, "end")
        self.proj_id_entry.insert(0, "0")
        self.proj_title_entry.delete(0, "end")
        self.proj_desc_text.delete("1.0", "end")
        self.ent_var.set("—")
        self.btn_proj_link.configure(state="disabled")
        self.btn_add_proj_dep.configure(state="disabled")
        self.btn_export_pdf.configure(state="disabled")
        for w in self.proj_dep_list.winfo_children(): w.destroy()
        self._highlight_proj(None)
        # Limpiar dedicaciones
        for w in self.ded_frame.winfo_children(): w.destroy()

    def _save_project(self):
        if not self.selected_solicitud_id: return
        try:
            id_pry = int(self.proj_id_entry.get())
            title = self.proj_title_entry.get().strip()
            desc = self.proj_desc_text.get("1.0", "end-1c").strip()
            ent = self.ent_var.get()
            if ent == "—": ent = ""
            
            if not title:
                messagebox.showerror("Error", "El título es obligatorio")
                return
            
            data = {
                "solicitud_id": self.selected_solicitud_id,
                "id_proyecto": id_pry,
                "title": title,
                "description": desc,
                "entregable": ent
            }
            
            if self.selected_project_id:
                update_project(self.selected_project_id, data)
            else:
                # Verificar duplicado
                if id_pry != 0:
                    existing = get_project_by_id_pry(self.selected_solicitud_id, id_pry)
                    if existing:
                        messagebox.showerror("Error", f"Ya existe un proyecto con ID #{id_pry}")
                        return
                else:
                    # Si es id_pry = 0, verificar que el título no esté ya en la solicitud
                    if any(p["title"].lower() == title.lower() for p in self.projects_raw):
                        messagebox.showerror("Error", f"Ya existe un proyecto con el título '{title}' para esta solicitud.")
                        return
                create_project(data)
            
            self._refresh_projects_list()
            messagebox.showinfo("OK", "Proyecto guardado")
        except ValueError:
            messagebox.showerror("Error", "ID Proyecto debe ser numérico")

    def _delete_project(self):
        if not self.selected_project_id: return
        if messagebox.askyesno("Confirmar", "¿Borrar proyecto y todas sus dedicaciones?"):
            delete_project(self.selected_project_id)
            self._new_project()
            self._refresh_projects_list()

    # ── LÓGICA DEDICACIONES ────────────────────────────────────────
    def _refresh_dedications_list(self):
        for w in self.ded_frame.winfo_children(): w.destroy()
        self.ded_buttons = {}
        if not self.selected_project_id: return
        self.dedications_raw = get_dedications_by_project(self.selected_project_id)
        for d in self.dedications_raw:
            lbl = f"{d['team_name']} ({d['status_name'] or '?'})"
            btn = ctk.CTkButton(self.ded_frame, text=lbl, anchor="w", fg_color="transparent",
                               text_color=("black", "white"), hover_color=("gray80", "gray30"),
                               command=lambda de=d: self._select_dedication(de))
            btn.grid(sticky="ew", pady=1)
            self.ded_buttons[d["id"]] = btn

    def _select_dedication(self, ded):
        self.selected_dedication_id = ded["id"]
        self._highlight_ded(ded["id"])
        
        self.team_var.set(ded["team_name"])
        self.status_var.set(ded["status_name"] or "—")
        self.start_entry.set_date(db_to_gui(ded["start_date"]))
        self.end_entry.set_date(db_to_gui(ded["end_date"]))
        self.est_hours_entry.delete(0, "end")
        self.est_hours_entry.insert(0, str(ded["estimated_hours"]))
        
        imp = get_imputed_hours(ded["id"])
        rest = max(0, ded["estimated_hours"] - imp)
        self.lbl_stats.configure(text=f"Imp: {imp:.1f}h | Rest: {rest:.1f}h")

    def _highlight_ded(self, d_id):
        for did, b in self.ded_buttons.items(): b.configure(fg_color="transparent")
        if d_id in self.ded_buttons: self.ded_buttons[d_id].configure(fg_color="#34495e")

    def _new_dedication(self):
        self.selected_dedication_id = None
        self.team_var.set("—")
        self.status_var.set("Propuesta") # default?
        self.start_entry.delete(0, "end")
        self.start_entry.insert(0, get_today_gui())
        self.end_entry.delete(0, "end")
        self.est_hours_entry.delete(0, "end")
        self.lbl_stats.configure(text="Imp: 0h | Rest: 0h")
        self._highlight_ded(None)

    def _save_dedication(self):
        if not self.selected_project_id:
            messagebox.showwarning("Aviso", "Selecciona un proyecto primero.")
            return
        
        try:
            team_name = self.team_var.get()
            status_name = self.status_var.get()
            
            # Buscar el proyecto seleccionado en cache
            proj = next((p for p in self.projects_raw if p["id"] == self.selected_project_id), None)
            
            # Validación ID 0
            if proj and proj.get("id_proyecto", 0) == 0:
                allowed = ["Idea", "En estimación", "Descartado", "Propuesta"]
                if status_name not in allowed:
                    messagebox.showerror("Error", f"Proyectos con ID 0 solo admiten estados: {', '.join(allowed)}.\nPara desarrollo o finalizado se requiere un ID de Proyecto real.")
                    return

            team_id = self._team_name_to_id.get(team_name)
            if not team_id:
                messagebox.showerror("Error", "Selecciona un equipo válido")
                return
                
            status_id = get_status_id_by_name(status_name)
            
            data = {
                "project_id": self.selected_project_id,
                "team_id": team_id,
                "status_id": status_id,
                "start_date": gui_to_db(self.start_entry.get()),
                "end_date": gui_to_db(self.end_entry.get()),
                "estimated_hours": float(self.est_hours_entry.get() or 0)
            }
            
            if self.selected_dedication_id:
                update_dedication(self.selected_dedication_id, data)
            else:
                create_dedication(data)
            
            self._refresh_dedications_list()
            messagebox.showinfo("OK", "Dedicación guardada")
        except Exception as e:
            messagebox.showerror("Error", str(e))

    def _export_pdf(self):
        if not self.selected_project_id: return
        p = next((pr for pr in self.projects_raw if pr["id"] == self.selected_project_id), None)
        if not p: return
        
        base_name = f"Informe_Proyecto_{p['id_proyecto'] if p['id_proyecto']>0 else p['id']}.pdf"
        file_path = filedialog.asksaveasfilename(
            defaultextension=".pdf",
            filetypes=[("PDF files", "*.pdf")],
            initialfile=base_name
        )
        if file_path:
            from logic.report_logic import generate_project_pdf
            success = generate_project_pdf(self.selected_project_id, file_path)
            if success:
                messagebox.showinfo("OK", "PDF generado correctamente")
                os.startfile(file_path)
            else:
                messagebox.showerror("Error", "No se pudo generar el PDF")

    def _delete_dedication(self):
        if not self.selected_dedication_id: return
        if messagebox.askyesno("Confirmar", "¿Quitar equipo de este proyecto?"):
            delete_dedication(self.selected_dedication_id)
            self._new_dedication()
            self._refresh_dedications_list()
