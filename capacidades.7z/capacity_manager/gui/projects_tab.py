"""
gui/projects_tab.py — Inventario de proyectos con título obligatorio y único.
"""
import customtkinter as ctk
from tkinter import messagebox
import webbrowser
from datetime import date
from datetime import date
from db.models.projects import get_all_projects, create_project, update_project, delete_project, TYPOLOGIES
from db.models.annotations import get_annotations_by_project, create_annotation, delete_annotation
from db.models.statuses import get_all_statuses, get_status_id_by_name
from db.models.dependencies import get_all_dependencies, get_project_dependencies, associate_project_dependency, remove_project_dependency
from utils.date_utils import get_today_gui, db_to_gui, gui_to_db
from logic.report_logic import generate_project_pdf
import os
from tkinter import filedialog
from utils.gui_utils import Tooltip


class ProjectsTab(ctk.CTkFrame):
    def __init__(self, master, **kwargs):
        super().__init__(master, **kwargs)
        self.selected_project_id = None
        self.annotations = []
        self.proj_buttons = {}  # Para resaltar selección
        self._build_ui()
        self.refresh()

    def _build_ui(self):
        self.grid_columnconfigure(0, weight=1)
        self.grid_columnconfigure(1, weight=1)
        self.grid_columnconfigure(2, weight=1)
        self.grid_rowconfigure(0, weight=1)

        # ── Lista ──────────────────────────────────────────────────────
        left = ctk.CTkFrame(self)
        left.grid(row=0, column=0, sticky="nsew", padx=(10, 5), pady=10)
        left.grid_rowconfigure(1, weight=1)
        left.grid_columnconfigure(0, weight=1)

        ctk.CTkLabel(left, text="Proyectos", font=ctk.CTkFont(size=16, weight="bold")).grid(
            row=0, column=0, sticky="w", padx=10, pady=(10, 5))

        self.list_frame = ctk.CTkScrollableFrame(left)
        self.list_frame.grid(row=1, column=0, sticky="nsew", padx=5, pady=5)
        self.list_frame.grid_columnconfigure(0, weight=1)

        # Filtros y Búsqueda
        filter_frame = ctk.CTkFrame(left, fg_color="transparent")
        filter_frame.grid(row=2, column=0, sticky="ew", padx=10, pady=2)
        
        self.search_var = ctk.StringVar()
        self.search_var.trace_add("write", lambda *args: self.refresh_list())
        
        search_row = ctk.CTkFrame(filter_frame, fg_color="transparent")
        search_row.pack(fill="x", pady=(2, 5))
        
        self.search_entry = ctk.CTkEntry(search_row, placeholder_text="🔍 Buscar proyecto...", textvariable=self.search_var)
        self.search_entry.pack(side="left", fill="x", expand=True)
        
        ctk.CTkButton(search_row, text="🧹", width=30, command=lambda: self.search_var.set("")).pack(side="left", padx=(5, 0))

        check_row = ctk.CTkFrame(filter_frame, fg_color="transparent")
        check_row.pack(fill="x")
        
        self.show_finished = ctk.BooleanVar(value=False)
        self.show_discarded = ctk.BooleanVar(value=False)
        self.show_stopped = ctk.BooleanVar(value=False)

        ctk.CTkCheckBox(check_row, text="Finalizado", variable=self.show_finished, command=self.refresh_list, 
                        font=ctk.CTkFont(size=11), width=90).pack(side="left", padx=2)
        ctk.CTkCheckBox(check_row, text="Descartado", variable=self.show_discarded, command=self.refresh_list, 
                        font=ctk.CTkFont(size=11), width=90).pack(side="left", padx=2)
        ctk.CTkCheckBox(check_row, text="Detenido", variable=self.show_stopped, command=self.refresh_list, 
                        font=ctk.CTkFont(size=11), width=80).pack(side="left", padx=2)

        btn_row = ctk.CTkFrame(left, fg_color="transparent")
        btn_row.grid(row=3, column=0, sticky="ew", padx=5, pady=5)
        ctk.CTkButton(btn_row, text="＋ Nuevo", command=self._new_project, width=100).pack(side="left", padx=3)
        ctk.CTkButton(btn_row, text="🗑 Borrar", fg_color="#c0392b", hover_color="#922b21",
                      command=self._delete_project, width=100).pack(side="left", padx=3)

        # ── Formulario ─────────────────────────────────────────────────
        right = ctk.CTkFrame(self)
        right.grid(row=0, column=1, sticky="nsew", padx=(5, 10), pady=10)
        right.grid_columnconfigure(1, weight=1)

        ctk.CTkLabel(right, text="Detalle del Proyecto",
                     font=ctk.CTkFont(size=16, weight="bold")).grid(
            row=0, column=0, columnspan=2, sticky="w", padx=15, pady=(15, 10))

        # Título
        ctk.CTkLabel(right, text="Título *").grid(row=1, column=0, sticky="w", padx=15, pady=4)
        self.title_entry = ctk.CTkEntry(right)
        self.title_entry.grid(row=1, column=1, sticky="ew", padx=(5, 15), pady=4)

        # Tipología
        ctk.CTkLabel(right, text="Tipología").grid(row=2, column=0, sticky="w", padx=15, pady=4)
        self.typology_var = ctk.StringVar(value=TYPOLOGIES[0])
        self.typology_menu = ctk.CTkOptionMenu(right, values=TYPOLOGIES, variable=self.typology_var)
        self.typology_menu.grid(row=2, column=1, sticky="ew", padx=(5, 15), pady=4)

        # Descripción
        ctk.CTkLabel(right, text="Descripción").grid(row=3, column=0, sticky="nw", padx=15, pady=4)
        self.desc_text = ctk.CTkTextbox(right, height=100)
        self.desc_text.grid(row=3, column=1, sticky="ew", padx=(5, 15), pady=4)

        # Enlace
        ctk.CTkLabel(right, text="Enlace solicitud").grid(row=4, column=0, sticky="w", padx=15, pady=4)
        link_frame = ctk.CTkFrame(right, fg_color="transparent")
        link_frame.grid(row=4, column=1, sticky="ew", padx=(5, 15), pady=4)
        link_frame.grid_columnconfigure(0, weight=1)
        self.link_entry = ctk.CTkEntry(link_frame)
        self.link_entry.grid(row=0, column=0, sticky="ew")
        ctk.CTkButton(link_frame, text="🔗", width=35,
                      command=self._open_link).grid(row=0, column=1, padx=(4, 0))

        # Estado
        ctk.CTkLabel(right, text="Estado").grid(row=5, column=0, sticky="w", padx=15, pady=4)
        self.status_var = ctk.StringVar()
        self.status_menu = ctk.CTkOptionMenu(right, variable=self.status_var, values=["—"], command=self._on_status_change)
        self.status_menu.grid(row=5, column=1, sticky="ew", padx=(5, 15), pady=4)

        # Fechas de Seguimiento
        dates_frame = ctk.CTkFrame(right, fg_color="transparent")
        dates_frame.grid(row=6, column=0, columnspan=2, sticky="ew", padx=15, pady=5)
        dates_frame.grid_columnconfigure((1, 3, 5), weight=1)

        ctk.CTkLabel(dates_frame, text="Inicio").grid(row=0, column=0, padx=(0, 5))
        self.start_date_entry = ctk.CTkEntry(dates_frame, width=100)
        self.start_date_entry.grid(row=0, column=1, sticky="ew", padx=2)

        ctk.CTkLabel(dates_frame, text="Fin").grid(row=0, column=2, padx=(10, 5))
        self.end_date_entry = ctk.CTkEntry(dates_frame, width=100)
        self.end_date_entry.grid(row=0, column=3, sticky="ew", padx=2)

        ctk.CTkLabel(dates_frame, text="Detención").grid(row=0, column=4, padx=(10, 5))
        self.detention_date_entry = ctk.CTkEntry(dates_frame, width=100)
        self.detention_date_entry.grid(row=0, column=5, sticky="ew", padx=2)

        button_frame = ctk.CTkFrame(right, fg_color="transparent")
        button_frame.grid(row=7, column=0, columnspan=2, pady=15)
        
        ctk.CTkButton(button_frame, text="💾 Guardar Proyecto", command=self._save).pack(side="left", padx=5)
        self.btn_report = ctk.CTkButton(button_frame, text="📄 Informe PDF", fg_color="#27ae60", 
                                        hover_color="#1e8449", command=self._export_pdf, state="disabled")
        self.btn_report.pack(side="left", padx=5)

        # ── Anotaciones (Nueva Columna) ──────────────────────────────
        annot_frame = ctk.CTkFrame(self)
        annot_frame.grid(row=0, column=2, sticky="nsew", padx=(5, 10), pady=10)
        annot_frame.grid_rowconfigure(1, weight=1)
        annot_frame.grid_columnconfigure(0, weight=1)

        ctk.CTkLabel(annot_frame, text="Anotaciones", font=ctk.CTkFont(size=14, weight="bold")).grid(
            row=0, column=0, pady=(10, 5))

        self.annot_list = ctk.CTkScrollableFrame(annot_frame)
        self.annot_list.grid(row=1, column=0, sticky="nsew", padx=5, pady=5)
        self.annot_list.grid_columnconfigure(0, weight=1)

        # Input de nueva anotación
        add_frame = ctk.CTkFrame(annot_frame, fg_color="transparent")
        add_frame.grid(row=2, column=0, sticky="ew", padx=5, pady=5)
        
        self.annot_entry = ctk.CTkEntry(add_frame, placeholder_text="Nueva nota...", font=ctk.CTkFont(size=12))
        self.annot_entry.pack(side="left", fill="x", expand=True, padx=(0, 5))
        
        self.btn_add_annot = ctk.CTkButton(add_frame, text="➕", width=30, command=self._add_annotation, state="disabled")
        self.btn_add_annot.pack(side="right")

        # ── Dependencias (Debajo de Anotaciones o en nueva sección) ──
        dep_frame = ctk.CTkFrame(annot_frame)
        dep_frame.grid(row=3, column=0, sticky="nsew", padx=5, pady=(10, 5))
        dep_frame.grid_rowconfigure(1, weight=1)
        dep_frame.grid_columnconfigure(0, weight=1)

        ctk.CTkLabel(dep_frame, text="Dependencias Area/App", font=ctk.CTkFont(size=14, weight="bold")).grid(
            row=0, column=0, pady=(5, 2))

        self.dep_list = ctk.CTkScrollableFrame(dep_frame, height=150)
        self.dep_list.grid(row=1, column=0, sticky="nsew", padx=5, pady=2)
        self.dep_list.grid_columnconfigure(0, weight=1)

        # Selector de dependencia para añadir
        add_dep_row = ctk.CTkFrame(dep_frame, fg_color="transparent")
        add_dep_row.grid(row=2, column=0, sticky="ew", padx=5, pady=5)
        
        self.dep_var = ctk.StringVar(value="Seleccionar...")
        self.dep_menu = ctk.CTkOptionMenu(add_dep_row, variable=self.dep_var, values=["—"])
        self.dep_menu.pack(side="left", fill="x", expand=True, padx=(0, 5))
        
        self.btn_add_dep = ctk.CTkButton(add_dep_row, text="➕", width=30, command=self._add_dependency, state="disabled")
        self.btn_add_dep.pack(side="right")

    def refresh(self):
        self.projects_raw = get_all_projects()
        
        # Cargar estados para los dropdowns
        self.statuses_list = get_all_statuses()
        status_names = [s["name"] for s in self.statuses_list]
        self.status_menu.configure(values=status_names)
        if not self.status_var.get() and status_names:
            self.status_var.set(status_names[0])
        
        # Cargar dependencias globales para el menú
        all_deps = get_all_dependencies()
        dep_names = [d["name"] for d in all_deps]
        if dep_names:
            self.dep_menu.configure(values=dep_names)
            self.dep_var.set("Seleccionar...")
        else:
            self.dep_menu.configure(values=["—"])
            self.dep_var.set("—")
            
        self.refresh_list()

    def refresh_list(self):
        for w in self.list_frame.winfo_children():
            w.destroy()
        self.proj_buttons = {} # Limpiar mapa de botones
        
        search_text = self.search_var.get().lower()
        
        # Filtrar proyectos
        filtered = []
        for p in self.projects_raw:
            status = p.get("status_name", "Idea")
            
            # Filtro por estado
            if status == "Finalizado" and not self.show_finished.get(): continue
            if status == "Descartado" and not self.show_discarded.get(): continue
            if status == "Detenido" and not self.show_stopped.get(): continue
            
            # Filtro por búsqueda
            if search_text and search_text not in p["title"].lower():
                continue
            
            filtered.append(p)

        TYPOLOGY_COLORS = {
            "Operacion": "#1a5276",
            "PIPE": "#145a32",
            "Regulatorio": "#6e2f1a",
            "TTM": "#4a235a",
        }
        for proj in filtered:
            color = TYPOLOGY_COLORS.get(proj["typology"], "#333")
            
            # Truncado estricto para asegurar que la tipología siempre se vea (38 chars total)
            prefix = f"[{proj['typology']}] "
            max_total = 38
            max_title = max_total - len(prefix)
            
            display_title = proj['title']
            if len(display_title) > max_title:
                display_title = display_title[:max_title-3] + "..."
            label = prefix + display_title
            
            btn = ctk.CTkButton(
                self.list_frame, text=label, anchor="w",
                fg_color=color, hover_color="gray40",
                text_color="white",
                font=ctk.CTkFont(size=12),
                command=lambda p=proj["id"]: self._select_project(p)
            )
            btn.grid(sticky="ew", pady=2, padx=2)
            self.proj_buttons[proj["id"]] = btn
            
            # Añadir Tooltip con el nombre completo
            Tooltip(btn, proj["title"])

        # Restaurar resaltado si hay algo seleccionado
        if self.selected_project_id:
            self._highlight_selection(self.selected_project_id)

    def _select_project(self, project_id):
        self.selected_project_id = project_id
        self._highlight_selection(project_id)
        proj = next((p for p in self.projects_raw if p["id"] == project_id), None)
        if not proj:
            return
        self.title_entry.delete(0, "end")
        self.title_entry.insert(0, proj["title"])
        self.typology_var.set(proj["typology"])
        self.desc_text.delete("1.0", "end")
        self.desc_text.insert("1.0", proj["description"])
        self.link_entry.delete(0, "end")
        self.link_entry.insert(0, proj["request_link"])
        self.status_var.set(proj.get("status_name", "Idea"))
        
        # Cargar fechas
        self.start_date_entry.delete(0, "end")
        if proj.get("start_date"):
            self.start_date_entry.insert(0, db_to_gui(proj["start_date"]))
            
        self.end_date_entry.delete(0, "end")
        if proj.get("end_date"):
            self.end_date_entry.insert(0, db_to_gui(proj["end_date"]))
            
        self.detention_date_entry.delete(0, "end")
        if proj.get("detention_date"):
            self.detention_date_entry.insert(0, db_to_gui(proj["detention_date"]))

        self.btn_add_annot.configure(state="normal")
        self.btn_report.configure(state="normal")
        self.btn_add_dep.configure(state="normal")
        self._refresh_annotations()
        self._refresh_dependencies()

    def _highlight_selection(self, project_id):
        # Restablecer todos
        for pid, btn in self.proj_buttons.items():
            btn.configure(border_width=0)
        
        # Resaltar seleccinado
        if project_id in self.proj_buttons:
            self.proj_buttons[project_id].configure(border_width=2, border_color="white")

    def _on_status_change(self, new_status):
        today = get_today_gui()
        if new_status in ["Finalizado", "Descartado"]:
            if not self.end_date_entry.get():
                self.end_date_entry.insert(0, today)
        elif new_status == "Detenido":
            if not self.detention_date_entry.get():
                self.detention_date_entry.insert(0, today)
        elif new_status in ["En desarrollo", "En estimación"]:
            # Si se reactiva, quizás limpiar fecha de detención? 
            # Dejamos que el usuario decida por ahora o limpiamos si estaba detenido
            pass

    def _refresh_annotations(self):
        for w in self.annot_list.winfo_children():
            w.destroy()
        
        if not self.selected_project_id:
            return
            
        self.annotations = get_annotations_by_project(self.selected_project_id)
        for a in self.annotations:
            card = ctk.CTkFrame(self.annot_list, fg_color=("gray90", "gray20"))
            card.pack(fill="x", pady=2, padx=2)
            
            header = ctk.CTkFrame(card, fg_color="transparent")
            header.pack(fill="x", padx=5, pady=(2, 0))
            
            ctk.CTkLabel(header, text=f"Nota #{a['annotation_number']}", 
                         font=ctk.CTkFont(size=10, weight="bold")).pack(side="left")
            ctk.CTkLabel(header, text=db_to_gui(a['date']), 
                         font=ctk.CTkFont(size=10)).pack(side="left", padx=10)
            
            ctk.CTkButton(header, text="✕", width=18, height=18, fg_color="#c0392b",
                          hover_color="#922b21", command=lambda aid=a['id']: self._delete_annotation(aid)).pack(side="right")
            
            ctk.CTkLabel(card, text=a['content'], font=ctk.CTkFont(size=11), 
                         justify="left", wraplength=250).pack(fill="x", padx=10, pady=(2, 5))

    def _add_annotation(self):
        content = self.annot_entry.get().strip()
        if not content: return
        
        today_db = date.today().isoformat()
        create_annotation(self.selected_project_id, content, today_db)
        self.annot_entry.delete(0, "end")
        self._refresh_annotations()

    def _delete_annotation(self, annotation_id):
        if messagebox.askyesno("Confirmar", "¿Borrar esta anotación?"):
            delete_annotation(annotation_id)
            self._refresh_annotations()

    def _refresh_dependencies(self):
        for w in self.dep_list.winfo_children():
            w.destroy()
        
        if not self.selected_project_id:
            return
            
        deps = get_project_dependencies(self.selected_project_id)
        for d in deps:
            row = ctk.CTkFrame(self.dep_list, fg_color="transparent")
            row.pack(fill="x", pady=1)
            
            ctk.CTkLabel(row, text=f"• {d['name']}", font=ctk.CTkFont(size=12)).pack(side="left", padx=5)
            
            ctk.CTkButton(row, text="✕", width=18, height=18, fg_color="#c0392b",
                          hover_color="#922b21", 
                          command=lambda did=d['id']: self._remove_dependency(did)).pack(side="right", padx=5)

    def _add_dependency(self):
        if not self.selected_project_id: return
        dep_name = self.dep_var.get()
        if dep_name in ["Seleccionar...", "—"]: return
        
        # Buscar ID por nombre
        all_deps = get_all_dependencies()
        dep = next((d for d in all_deps if d["name"] == dep_name), None)
        if dep:
            associate_project_dependency(self.selected_project_id, dep["id"])
            self._refresh_dependencies()

    def _remove_dependency(self, dependency_id):
        if not self.selected_project_id: return
        remove_project_dependency(self.selected_project_id, dependency_id)
        self._refresh_dependencies()

    def _new_project(self):
        self.selected_project_id = None
        self.title_entry.delete(0, "end")
        self.typology_var.set(TYPOLOGIES[0])
        self.desc_text.delete("1.0", "end")
        self.link_entry.delete(0, "end")
        if hasattr(self, "statuses_list") and self.statuses_list:
            self.status_var.set(self.statuses_list[0]["name"])
        
        # Reset fechas y poner Inicio por defecto
        self.start_date_entry.delete(0, "end")
        self.start_date_entry.insert(0, get_today_gui())
        self.end_date_entry.delete(0, "end")
        self.detention_date_entry.delete(0, "end")

        self.btn_add_annot.configure(state="disabled")
        self.btn_report.configure(state="disabled")
        self.btn_add_dep.configure(state="disabled")
        self._refresh_annotations()
        self._refresh_dependencies()

    def _save(self):
        title = self.title_entry.get().strip()
        if not title:
            messagebox.showerror("Error", "El título es obligatorio.")
            return

        status_id = get_status_id_by_name(self.status_var.get())
        
        data = {
            "title": title,
            "typology": self.typology_var.get(),
            "description": self.desc_text.get("1.0", "end").strip(),
            "request_link": self.link_entry.get().strip(),
            "status_id": status_id,
            "start_date": gui_to_db(self.start_date_entry.get().strip()),
            "end_date": gui_to_db(self.end_date_entry.get().strip()),
            "detention_date": gui_to_db(self.detention_date_entry.get().strip()),
        }
        try:
            if self.selected_project_id:
                update_project(self.selected_project_id, data)
            else:
                self.selected_project_id = create_project(data)
            self.refresh()
            messagebox.showinfo("OK", "Proyecto guardado correctamente.")
        except Exception as e:
            if "UNIQUE" in str(e):
                messagebox.showerror("Error", f"Ya existe un proyecto con el título '{title}'.")
            else:
                messagebox.showerror("Error", str(e))

    def _delete_project(self):
        if not self.selected_project_id:
            messagebox.showwarning("Aviso", "Selecciona un proyecto primero.")
            return
        proj = next((p for p in self.projects_raw if p["id"] == self.selected_project_id), None)
        name = proj["title"] if proj else f"#{self.selected_project_id}"
        if messagebox.askyesno("Confirmar", f"¿Borrar el proyecto '{name}'?"):
            delete_project(self.selected_project_id)
            self.selected_project_id = None
            self._new_project()
            self.refresh()


    def _export_pdf(self):
        if not self.selected_project_id: return
        
        proj = next((p for p in self.projects_raw if p["id"] == self.selected_project_id), None)
        if not proj: return
        
        # Generar slug para el nombre del archivo
        import re
        slug = re.sub(r'[^\w\s-]', '', proj['title'].lower())
        slug = re.sub(r'[-\s]+', '_', slug).strip('_')
        
        filename = f"Informe_{slug}.pdf"
        filepath = filedialog.asksaveasfilename(defaultextension=".pdf", initialfile=filename,
                                                filetypes=[("PDF files", "*.pdf")])
        if not filepath: return

        if generate_project_pdf(self.selected_project_id, filepath):
            messagebox.showinfo("OK", f"Informe guardado en:\n{filepath}")
            # Intentar abrir el PDF
            try:
                os.startfile(filepath)
            except:
                pass
        else:
            messagebox.showerror("Error", "No se pudo generar el informe.")

    def _open_link(self):
        url = self.link_entry.get().strip()
        if url:
            webbrowser.open(url)
