"""
gui/capacity_tab.py — Dashboard de carga de capacidad por equipo y mes.
Incluye días efectivos, seguimiento previsto vs real, y ajuste homogéneo.
"""
import customtkinter as ctk
from datetime import date
from logic.capacity_engine import compute_all_teams_year, available_hours_for_month
from db.models.teams import get_all_teams

MONTHS_ES = ["Ene", "Feb", "Mar", "Abr", "May", "Jun",
             "Jul", "Ago", "Sep", "Oct", "Nov", "Dic"]


def _color_for_pct(pct: float) -> str:
    """Devuelve un color según el % de carga."""
    if pct <= 70:
        return "#1e8449"   # Verde
    elif pct <= 90:
        return "#d4ac0d"   # Amarillo
    elif pct <= 100:
        return "#ca6f1e"   # Naranja
    else:
        return "#c0392b"   # Rojo (sobrecarga)


def _color_for_deviation(planned: float, actual: float) -> str:
    """Color para la celda de desviación previsto vs real."""
    if planned <= 0:
        return "#555555"  # Gris: sin planificación
    deviation_pct = abs(actual - planned) / planned * 100
    if deviation_pct <= 10:
        return "#1e8449"  # Verde
    elif deviation_pct <= 25:
        return "#d4ac0d"  # Amarillo
    else:
        return "#c0392b"  # Rojo


class CapacityTab(ctk.CTkFrame):
    def __init__(self, master, **kwargs):
        super().__init__(master, **kwargs)
        self.year_var = ctk.IntVar(value=date.today().year)
        self.selected_team = None
        self._build_ui()
        self.refresh()

    def _build_ui(self):
        self.grid_columnconfigure(0, weight=1)
        self.grid_rowconfigure(1, weight=1)

        # ── Controles superiores ───────────────────────────────────────
        top = ctk.CTkFrame(self, fg_color="transparent")
        top.grid(row=0, column=0, sticky="ew", padx=10, pady=(10, 4))
        ctk.CTkLabel(top, text="Año:", font=ctk.CTkFont(size=14)).pack(side="left", padx=6)
        ctk.CTkEntry(top, textvariable=self.year_var, width=80).pack(side="left")
        ctk.CTkButton(top, text="◀", width=35,
                      command=lambda: self._change_year(-1)).pack(side="left", padx=2)
        ctk.CTkButton(top, text="▶", width=35,
                      command=lambda: self._change_year(1)).pack(side="left", padx=2)
        ctk.CTkButton(top, text="🔄 Calcular", command=self.refresh,
                      font=ctk.CTkFont(weight="bold")).pack(side="left", padx=12)

        # Leyenda
        legend_frame = ctk.CTkFrame(top, fg_color="transparent")
        legend_frame.pack(side="right", padx=10)
        for label, color in [("≤70%", "#1e8449"), ("71-90%", "#d4ac0d"),
                              ("91-100%", "#ca6f1e"), (">100%", "#c0392b")]:
            ctk.CTkLabel(legend_frame, text="■", text_color=color,
                         font=ctk.CTkFont(size=16)).pack(side="left")
            ctk.CTkLabel(legend_frame, text=label + "   ").pack(side="left")

        # ── Área scrollable ────────────────────────────────────────────
        self.scroll_area = ctk.CTkScrollableFrame(self)
        self.scroll_area.grid(row=1, column=0, sticky="nsew", padx=6, pady=6)

    def _change_year(self, delta):
        self.year_var.set(self.year_var.get() + delta)
        self.refresh()

    def refresh(self):
        for w in self.scroll_area.winfo_children():
            w.destroy()

        year = self.year_var.get()
        teams = get_all_teams()
        if not teams:
            ctk.CTkLabel(self.scroll_area,
                         text="No hay equipos configurados.",
                         text_color="gray").grid(padx=20, pady=20)
            return

        # Calcular carga
        all_loads = compute_all_teams_year(year)

        # ── Cabecera de meses ──────────────────────────────────────────
        header = ctk.CTkFrame(self.scroll_area, fg_color="transparent")
        header.grid(row=0, column=0, sticky="ew", pady=(0, 2))
        ctk.CTkLabel(header, text="Equipo", width=130,
                     font=ctk.CTkFont(weight="bold")).grid(row=0, column=0, padx=2)
        ctk.CTkLabel(header, text="Categoría", width=100,
                     font=ctk.CTkFont(weight="bold")).grid(row=0, column=1, padx=2)
        for i, m in enumerate(MONTHS_ES):
            ctk.CTkLabel(header, text=m, width=68,
                         font=ctk.CTkFont(weight="bold")).grid(row=0, column=i + 2, padx=2)

        # ── Filas por equipo ───────────────────────────────────────────
        for row_idx, team in enumerate(teams):
            tid = team["id"]
            tname = team["name"]
            loads = all_loads.get(tid, {})

            # Contenedor principal del equipo
            container = ctk.CTkFrame(self.scroll_area, 
                                     fg_color=("white", "gray15"),
                                     border_width=1,
                                     border_color=("gray70", "gray30"),
                                     corner_radius=8)
            container.grid(row=row_idx + 1, column=0, sticky="ew", pady=6, padx=4)
            container.grid_columnconfigure(0, weight=0)

            # Cuatro sub-filas: Operación, No-Operación, Total, Previsto vs Real
            rows_data = [
                ("Operación", "ops_load_pct", "ops_assigned", "ops_hours"),
                ("No-Operación", "non_ops_load_pct", "non_ops_assigned", "non_ops_hours"),
                ("Total", "total_load_pct", None, "total_hours"),
                ("▶ Prev vs Real", None, None, None),  # Fila de seguimiento
            ]
            
            grid_row = 0
            for sub_idx, (cat_label, pct_key, assigned_key, avail_key) in enumerate(rows_data):
                # Línea separadora antes del Total y antes de Prev vs Real
                if cat_label in ("Total", "▶ Prev vs Real"):
                    sep = ctk.CTkFrame(container, height=1, fg_color=("gray80", "gray40"))
                    sep.grid(row=grid_row, column=0, columnspan=14, sticky="ew", padx=10, pady=2)
                    grid_row += 1

                # Equipo label solo en primera sub-fila
                if sub_idx == 0:
                    ctk.CTkLabel(container, text=tname, width=130,
                                 font=ctk.CTkFont(size=13, weight="bold"),
                                 anchor="w").grid(row=grid_row, column=0, padx=(12, 2), pady=4)
                else:
                    ctk.CTkLabel(container, text="", width=130).grid(
                        row=grid_row, column=0, padx=(12, 2), pady=2)

                is_tracking_row = cat_label == "▶ Prev vs Real"
                
                ctk.CTkLabel(container, text=cat_label, width=100,
                             text_color=("#2980b9", "#5dade2") if is_tracking_row else ("gray40", "gray70"), 
                             font=ctk.CTkFont(size=11, weight="bold" if cat_label in ("Total", "▶ Prev vs Real") else "normal"),
                             anchor="w").grid(row=grid_row, column=1, padx=2, pady=2)

                for m_idx in range(1, 13):
                    load = loads.get(m_idx, {})
                    avail = load.get("available", {})

                    if is_tracking_row:
                        # Fila de seguimiento: Previsto vs Real
                        self._render_tracking_cell(container, grid_row, m_idx, load)
                    elif pct_key:
                        # Filas normales de carga
                        pct = load.get(pct_key, 0.0)
                        eff_d = avail.get("effective_days", 0)
                        tot_d = avail.get("total_days", 0)
                        days_str = f"({eff_d:.0f}/{tot_d:.0f}d)" if eff_d != tot_d else f"({tot_d:.0f}d)"

                        if assigned_key:
                            assigned = load.get(assigned_key, 0.0)
                            avail_h = avail.get(avail_key, 0.0)
                            tooltip_text = f"{assigned:.0f}/{avail_h:.0f}h\n{days_str}"
                        else:
                            ops_h = load.get("ops_assigned", 0.0)
                            non_ops_h = load.get("non_ops_assigned", 0.0)
                            total_h = avail.get("total_hours", 0.0)
                            tooltip_text = f"{ops_h+non_ops_h:.0f}/{total_h:.0f}h\n{days_str}"

                        cell_color = _color_for_pct(pct)
                        cell = ctk.CTkFrame(container, fg_color=cell_color,
                                            corner_radius=4, width=64, height=38)
                        cell.grid(row=grid_row, column=m_idx + 1, padx=2, pady=4)
                        cell.grid_propagate(False)
                        ctk.CTkLabel(cell, text=f"{pct:.0f}%\n{tooltip_text}",
                                     font=ctk.CTkFont(size=9, weight="bold"),
                                     text_color="white").place(relx=0.5, rely=0.5, anchor="center")

                grid_row += 1

    def _render_tracking_cell(self, container, grid_row, m_idx, load):
        """Renderiza una celda de la fila Previsto vs Real."""
        is_past = load.get("is_past_or_current", False)
        planned = load.get("planned", {})
        actual = load.get("actual", {})

        planned_total = planned.get("total_hours", 0.0)
        actual_total = actual.get("total_hours", 0.0)

        if not is_past or (planned_total == 0 and actual_total == 0):
            # Mes futuro o sin datos
            cell_color = "#555555"
            text = "—"
        else:
            cell_color = _color_for_deviation(planned_total, actual_total)
            deviation = actual_total - planned_total
            sign = "+" if deviation >= 0 else ""
            text = f"{sign}{deviation:.0f}h\n{actual_total:.0f}/{planned_total:.0f}"

        cell = ctk.CTkFrame(container, fg_color=cell_color,
                            corner_radius=4, width=64, height=38)
        cell.grid(row=grid_row, column=m_idx + 1, padx=2, pady=4)
        cell.grid_propagate(False)
        ctk.CTkLabel(cell, text=text,
                     font=ctk.CTkFont(size=9, weight="bold"),
                     text_color="white").place(relx=0.5, rely=0.5, anchor="center")
