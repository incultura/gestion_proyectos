"""
gui/hours_log_tab.py — Registro de horas (v7: 3-level model).
"""
import customtkinter as ctk
from tkinter import messagebox
from db.models.solicitudes import get_all_solicitudes, get_solicitud
from db.models.projects import get_projects_by_solicitud
from db.models.dedications import get_dedications_by_project, get_imputed_hours, get_dedication
from db.models.hours_log import get_logs_by_dedication, add_log, update_log, delete_log, get_total_solicitud_imputed
from utils.date_utils import gui_to_db, db_to_gui, get_today_gui
from utils.gui_utils import Tooltip, DateEntry

class HoursLogTab(ctk.CTkFrame):
    def __init__(self, master, **kwargs):
        super().__init__(master, **kwargs)
        self.selected_solicitud_id = None
        self.selected_project_id = None
        self.selected_dedication_id = None
        self.selected_log_id = None
        
        self.solicitudes_raw = []
        self.sol_buttons = {}
        self.proj_buttons = {}
        self.ded_buttons = {}
        
        self._build_ui()
        self.refresh()

    def refresh(self):
        self.solicitudes_raw = get_all_solicitudes()
        self.refresh_solicitudes_list()

    def _build_ui(self):
        self.grid_columnconfigure(0, weight=1)
        self.grid_columnconfigure(1, weight=1)
        self.grid_columnconfigure(2, weight=1)
        self.grid_columnconfigure(3, weight=2)
        self.grid_rowconfigure(0, weight=1)

        # ── Col 1: Solicitudes ───────────────────────────────────────────
        col1 = ctk.CTkFrame(self)
        col1.grid(row=0, column=0, sticky="nsew", padx=(10, 2), pady=10)
        col1.grid_rowconfigure(1, weight=1)
        ctk.CTkLabel(col1, text="1. Solicitud", font=ctk.CTkFont(size=13, weight="bold")).grid(row=0, padx=5, pady=5)
        self.sol_frame = ctk.CTkScrollableFrame(col1)
        self.sol_frame.grid(row=1, sticky="nsew", padx=2, pady=2)
        
        self.search_var = ctk.StringVar()
        self.search_var.trace_add("write", lambda *args: self.refresh_solicitudes_list())
        ctk.CTkEntry(col1, placeholder_text="Buscar...", textvariable=self.search_var).grid(row=2, sticky="ew", padx=5, pady=5)

        # ── Col 2: Proyectos ─────────────────────────────────────────────
        col2 = ctk.CTkFrame(self)
        col2.grid(row=0, column=1, sticky="nsew", padx=2, pady=10)
        col2.grid_rowconfigure(1, weight=1)
        ctk.CTkLabel(col2, text="2. Proyecto", font=ctk.CTkFont(size=13, weight="bold")).grid(row=0, padx=5, pady=5)
        self.proj_frame = ctk.CTkScrollableFrame(col2)
        self.proj_frame.grid(row=1, sticky="nsew", padx=2, pady=2)

        # ── Col 3: Dedicaciones (Equipos) ────────────────────────────────
        col3 = ctk.CTkFrame(self)
        col3.grid(row=0, column=2, sticky="nsew", padx=2, pady=10)
        col3.grid_rowconfigure(1, weight=1)
        ctk.CTkLabel(col3, text="3. Equipo", font=ctk.CTkFont(size=13, weight="bold")).grid(row=0, padx=5, pady=5)
        self.ded_frame = ctk.CTkScrollableFrame(col3)
        self.ded_frame.grid(row=1, sticky="nsew", padx=2, pady=2)

        # ── Col 4: Imputaciones ─────────────────────────────────────────
        col4 = ctk.CTkFrame(self)
        col4.grid(row=0, column=3, sticky="nsew", padx=(2, 10), pady=10)
        col4.grid_rowconfigure(2, weight=1)
        col4.grid_columnconfigure(0, weight=1)
        
        ctk.CTkLabel(col4, text="Imputaciones", font=ctk.CTkFont(size=14, weight="bold")).grid(row=0, pady=5)
        
        # Formulario
        form = ctk.CTkFrame(col4)
        form.grid(row=1, sticky="ew", padx=10, pady=5)
        form.grid_columnconfigure(1, weight=1)
        
        ctk.CTkLabel(form, text="Fecha").grid(row=0, column=0, padx=5, pady=2)
        self.date_entry = DateEntry(form)
        self.date_entry.grid(row=0, column=1, sticky="ew", padx=5, pady=2)
        self.date_entry.set_date(get_today_gui())
        
        ctk.CTkLabel(form, text="Horas").grid(row=1, column=0, padx=5, pady=2)
        self.hours_entry = ctk.CTkEntry(form)
        self.hours_entry.grid(row=1, column=1, sticky="ew", padx=5, pady=2)
        
        btns = ctk.CTkFrame(form, fg_color="transparent")
        btns.grid(row=2, column=0, columnspan=2, pady=5)
        ctk.CTkButton(btns, text="Registrar", width=80, command=self._add_log).pack(side="left", padx=2)
        ctk.CTkButton(btns, text="Actualizar", width=80, command=self._update_log).pack(side="left", padx=2)
        ctk.CTkButton(btns, text="🗑", width=40, fg_color="#c0392b", command=self._delete_log).pack(side="left", padx=2)

        self.logs_frame = ctk.CTkScrollableFrame(col4)
        self.logs_frame.grid(row=2, sticky="nsew", padx=10, pady=5)
        self.logs_frame.grid_columnconfigure(0, weight=1)
        
        self.lbl_totals = ctk.CTkLabel(col4, text="Total: 0h", font=ctk.CTkFont(size=12, weight="bold"))
        self.lbl_totals.grid(row=3, pady=5)

    def refresh_solicitudes_list(self):
        for w in self.sol_frame.winfo_children(): w.destroy()
        self.sol_buttons = {}
        search = self.search_var.get().lower()
        for sol in self.solicitudes_raw:
            if search and search not in sol["title"].lower(): continue
            btn = ctk.CTkButton(self.sol_frame, text=sol["title"], anchor="w", fg_color="transparent",
                               text_color=("black", "white"), hover_color=("gray80", "gray30"),
                               command=lambda s=sol["id"]: self._select_solicitud(s))
            btn.grid(sticky="ew", pady=1)
            self.sol_buttons[sol["id"]] = btn
        if self.selected_solicitud_id: self._highlight(self.sol_buttons, self.selected_solicitud_id)

    def _select_solicitud(self, sol_id):
        self.selected_solicitud_id = sol_id
        self._highlight(self.sol_buttons, sol_id)
        self.selected_project_id = None
        self.selected_dedication_id = None
        self._refresh_projects()

    def _refresh_projects(self):
        for w in self.proj_frame.winfo_children(): w.destroy()
        self.proj_buttons = {}
        if not self.selected_solicitud_id: return
        
        sol = get_solicitud(self.selected_solicitud_id)
        is_pipe = sol and sol["typology"] == "PIPE"
        
        projs = get_projects_by_solicitud(self.selected_solicitud_id)
        for p in projs:
            if p.get("id_proyecto", 0) == 0: continue
            content = p['entregable'] if is_pipe and p.get('entregable') else p['title']
            lbl = f"#{p['id_proyecto']} | {content}"
            btn = ctk.CTkButton(self.proj_frame, text=lbl, anchor="w", fg_color="transparent",
                               text_color=("black", "white"), hover_color=("gray80", "gray30"),
                               command=lambda pr=p["id"]: self._select_project(pr))
            btn.grid(sticky="ew", pady=1)
            self.proj_buttons[p["id"]] = btn
        # Limpiar siguientes columnas
        for w in self.ded_frame.winfo_children(): w.destroy()
        for w in self.logs_frame.winfo_children(): w.destroy()

    def _select_project(self, pr_id):
        self.selected_project_id = pr_id
        self._highlight(self.proj_buttons, pr_id)
        self.selected_dedication_id = None
        self._refresh_dedications()

    def _refresh_dedications(self):
        for w in self.ded_frame.winfo_children(): w.destroy()
        self.ded_buttons = {}
        if not self.selected_project_id: return
        deds = get_dedications_by_project(self.selected_project_id)
        for d in deds:
            lbl = f"{d['team_name']}"
            btn = ctk.CTkButton(self.ded_frame, text=lbl, anchor="w", fg_color="transparent",
                               text_color=("black", "white"), hover_color=("gray80", "gray30"),
                               command=lambda de=d["id"]: self._select_dedication(de))
            btn.grid(sticky="ew", pady=1)
            self.ded_buttons[d["id"]] = btn
        for w in self.logs_frame.winfo_children(): w.destroy()

    def _select_dedication(self, ded_id):
        self.selected_dedication_id = ded_id
        self._highlight(self.ded_buttons, ded_id)
        self._refresh_logs()

    def _highlight(self, button_dict, selected_id):
        for idx, btn in button_dict.items():
            btn.configure(fg_color="transparent")
        if selected_id in button_dict:
            button_dict[selected_id].configure(fg_color="#34495e")

    def _refresh_logs(self):
        for w in self.logs_frame.winfo_children(): w.destroy()
        if not self.selected_dedication_id: return
        logs = get_logs_by_dedication(self.selected_dedication_id)
        for lg in logs:
            lbl = f"{db_to_gui(lg['log_date'])}  —  {lg['hours']:.1f}h"
            btn = ctk.CTkButton(self.logs_frame, text=lbl, anchor="w", fg_color="transparent",
                               text_color=("black", "white"), hover_color=("gray80", "gray30"),
                               command=lambda l=lg: self._select_log(l))
            btn.grid(sticky="ew", pady=1)
        
        total = get_imputed_hours(self.selected_dedication_id)
        self.lbl_totals.configure(text=f"Total Equipo: {total:.1f}h")

    def _select_log(self, log):
        self.selected_log_id = log["id"]
        self.date_entry.set_date(db_to_gui(log["log_date"]))
        self.hours_entry.delete(0, "end")
        self.hours_entry.insert(0, str(log["hours"]))

    def _add_log(self):
        if not self.selected_dedication_id:
            messagebox.showwarning("Aviso", "Selecciona un Equipo")
            return
        
        sol = get_solicitud(self.selected_solicitud_id)
        ded = get_dedication(self.selected_dedication_id)
        
        if sol["typology"] == "PIPE" and (not ded or not ded["entregable"]):
             messagebox.showerror("Error", "No se puede imputar en un proyecto PIPE sin entregable")
             return

        try:
            h = float(self.hours_entry.get())
            d = guid = self.date_entry.get()
            add_log({
                "dedication_id": self.selected_dedication_id,
                "log_date": gui_to_db(d),
                "hours": h,
                "comment": ""
            })
            self._refresh_logs()
        except Exception as e:
            messagebox.showerror("Error", str(e))

    def _update_log(self):
        if not self.selected_log_id: return
        try:
            h = float(self.hours_entry.get())
            d = self.date_entry.get()
            update_log(self.selected_log_id, gui_to_db(d), h, "")
            self._refresh_logs()
        except Exception as e:
            messagebox.showerror("Error", str(e))

    def _delete_log(self):
        if not self.selected_log_id: return
        if messagebox.askyesno("Confirmar", "¿Borrar imputación?"):
            delete_log(self.selected_log_id)
            self._refresh_logs()
            self.selected_log_id = None
