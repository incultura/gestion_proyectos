"""
gui/hours_log_tab.py — Registro de horas imputadas por dedicación.
Incluye visualización de totales por proyecto/equipo y restricción de unicidad por día.
"""
import customtkinter as ctk
from tkinter import messagebox
from datetime import date
from db.models.projects import get_all_projects
from db.models.project_teams import get_dedications_by_project, get_imputed_hours
from db.models.hours_log import get_logs_by_dedication, add_log, update_log, delete_log, get_total_project_imputed
from utils.date_utils import gui_to_db, db_to_gui, get_today_gui
from utils.gui_utils import Tooltip


class HoursLogTab(ctk.CTkFrame):
    def __init__(self, master, **kwargs):
        super().__init__(master, **kwargs)
        self.selected_project_id = None
        self.selected_ded_id = None
        self.selected_log_id = None
        self.proj_buttons = {} # Para resaltar selección
        self._build_ui()
        self.refresh_projects()

    def _build_ui(self):
        self.grid_columnconfigure(0, weight=1)
        self.grid_columnconfigure(1, weight=1)
        self.grid_columnconfigure(2, weight=2)
        self.grid_rowconfigure(0, weight=1)

        # ── Col 1: Proyectos ───────────────────────────────────────────
        col1 = ctk.CTkFrame(self)
        col1.grid(row=0, column=0, sticky="nsew", padx=(10, 4), pady=10)
        col1.grid_rowconfigure(1, weight=1)
        col1.grid_columnconfigure(0, weight=1)
        
        header1 = ctk.CTkFrame(col1, fg_color="transparent")
        header1.grid(row=0, column=0, sticky="ew", padx=8, pady=(8, 4))
        ctk.CTkLabel(header1, text="Proyecto", font=ctk.CTkFont(size=14, weight="bold")).pack(side="left")
        
        self.lbl_proj_total = ctk.CTkLabel(header1, text="", text_color="#3498db", font=ctk.CTkFont(size=12))
        self.lbl_proj_total.pack(side="right")

        self.proj_frame = ctk.CTkScrollableFrame(col1)
        self.proj_frame.grid(row=1, column=0, sticky="nsew", padx=4, pady=4)
        self.proj_frame.grid_columnconfigure(0, weight=1)

        # Filtros y Búsqueda
        filter_frame = ctk.CTkFrame(col1, fg_color="transparent")
        filter_frame.grid(row=2, column=0, sticky="ew", padx=8, pady=2)
        
        self.search_var = ctk.StringVar()
        self.search_var.trace_add("write", lambda *args: self.refresh_projects_list())
        
        search_row = ctk.CTkFrame(filter_frame, fg_color="transparent")
        search_row.pack(fill="x", pady=(2, 5))
        
        self.search_entry = ctk.CTkEntry(search_row, placeholder_text="🔍 Buscar...", textvariable=self.search_var)
        self.search_entry.pack(side="left", fill="x", expand=True)
        
        ctk.CTkButton(search_row, text="🧹", width=30, command=lambda: self.search_var.set("")).pack(side="left", padx=(5, 0))

        self.show_finished = ctk.BooleanVar(value=False)
        self.show_discarded = ctk.BooleanVar(value=False)
        self.show_stopped = ctk.BooleanVar(value=False)

        checks = ctk.CTkFrame(filter_frame, fg_color="transparent")
        checks.pack(fill="x")
        ctk.CTkCheckBox(checks, text="Fin.", variable=self.show_finished, command=self.refresh_projects_list, 
                        font=ctk.CTkFont(size=10), width=50).pack(side="left", padx=1)
        ctk.CTkCheckBox(checks, text="Desc.", variable=self.show_discarded, command=self.refresh_projects_list, 
                        font=ctk.CTkFont(size=10), width=50).pack(side="left", padx=1)
        ctk.CTkCheckBox(checks, text="Det.", variable=self.show_stopped, command=self.refresh_projects_list, 
                        font=ctk.CTkFont(size=10), width=50).pack(side="left", padx=1)

        # ── Col 2: Dedicaciones ────────────────────────────────────────
        col2 = ctk.CTkFrame(self)
        col2.grid(row=0, column=1, sticky="nsew", padx=4, pady=10)
        col2.grid_rowconfigure(1, weight=1)
        col2.grid_columnconfigure(0, weight=1)
        
        header2 = ctk.CTkFrame(col2, fg_color="transparent")
        header2.grid(row=0, column=0, sticky="ew", padx=8, pady=(8, 4))
        ctk.CTkLabel(header2, text="Equipo", font=ctk.CTkFont(size=14, weight="bold")).pack(side="left")
        
        self.lbl_team_total = ctk.CTkLabel(header2, text="", text_color="#2ecc71", font=ctk.CTkFont(size=12))
        self.lbl_team_total.pack(side="right")

        self.ded_frame = ctk.CTkScrollableFrame(col2)
        self.ded_frame.grid(row=1, column=0, sticky="nsew", padx=4, pady=4)
        self.ded_frame.grid_columnconfigure(0, weight=1)

        # ── Col 3: Logs ────────────────────────────────────────────────
        col3 = ctk.CTkFrame(self)
        col3.grid(row=0, column=2, sticky="nsew", padx=(4, 10), pady=10)
        col3.grid_rowconfigure(2, weight=1)
        col3.grid_columnconfigure(0, weight=1)

        ctk.CTkLabel(col3, text="Imputaciones", font=ctk.CTkFont(size=14, weight="bold")).grid(
            row=0, column=0, sticky="w", padx=8, pady=(8, 4))

        # Formulario de nueva imputación
        form = ctk.CTkFrame(col3)
        form.grid(row=1, column=0, sticky="ew", padx=6, pady=4)
        form.grid_columnconfigure(1, weight=1)

        ctk.CTkLabel(form, text="Fecha").grid(row=0, column=0, sticky="w", padx=8, pady=3)
        self.date_entry = ctk.CTkEntry(form, placeholder_text="DD-MM-YYYY")
        self.date_entry.grid(row=0, column=1, sticky="ew", padx=(4, 8), pady=3)
        self.date_entry.insert(0, get_today_gui())

        ctk.CTkLabel(form, text="Horas").grid(row=1, column=0, sticky="w", padx=8, pady=3)
        self.hours_entry = ctk.CTkEntry(form)
        self.hours_entry.grid(row=1, column=1, sticky="ew", padx=(4, 8), pady=3)

        btn_row = ctk.CTkFrame(form, fg_color="transparent")
        btn_row.grid(row=2, column=0, columnspan=2, pady=6)
        ctk.CTkButton(btn_row, text="＋ Registrar", command=self._add_log).pack(side="left", padx=3)
        ctk.CTkButton(btn_row, text="✏ Actualizar", command=self._update_log).pack(side="left", padx=3)
        ctk.CTkButton(btn_row, text="🗑", fg_color="#c0392b", hover_color="#922b21",
                      command=self._delete_log, width=40).pack(side="left", padx=3)

        # Info totales (del equipo seleccionado)
        info = ctk.CTkFrame(col3, fg_color="transparent")
        info.grid(row=3, column=0, sticky="ew", padx=8, pady=0)
        ctk.CTkLabel(info, text="Total equipo en este proyecto:").pack(side="left")
        self.lbl_total = ctk.CTkLabel(info, text="— h", font=ctk.CTkFont(weight="bold"))
        self.lbl_total.pack(side="left", padx=6)

        # Lista de logs
        self.logs_frame = ctk.CTkScrollableFrame(col3)
        self.logs_frame.grid(row=2, column=0, sticky="nsew", padx=4, pady=4)
        self.logs_frame.grid_columnconfigure(0, weight=1)

    def refresh_projects(self):
        self.projects_raw = get_all_projects()
        self.refresh_projects_list()
        self.lbl_proj_total.configure(text="")
        self.lbl_team_total.configure(text="")

    def refresh_projects_list(self):
        for w in self.proj_frame.winfo_children():
            w.destroy()
        self.proj_buttons = {} # Limpiar mapa
        
        search_text = self.search_var.get().lower()
        
        filtered = []
        for proj in self.projects_raw:
            status = proj.get("status_name", "Idea")
            
            # Filtro por estado
            if status == "Finalizado" and not self.show_finished.get(): continue
            if status == "Descartado" and not self.show_discarded.get(): continue
            if status == "Detenido" and not self.show_stopped.get(): continue
            
            # Filtro por búsqueda
            if search_text and search_text not in proj["title"].lower():
                continue
                
            filtered.append(proj)

            # Truncado estricto para asegurar que la tipología siempre se vea (38 chars total)
            prefix = f"[{proj['typology']}] "
            max_total = 38
            max_title = max_total - len(prefix)
            
            display_title = proj['title']
            if len(display_title) > max_title:
                display_title = display_title[:max_title-3] + "..."
            lbl = prefix + display_title
            
            btn = ctk.CTkButton(
                self.proj_frame, text=lbl, anchor="w",
                fg_color="transparent", text_color=("black", "white"),
                hover_color=("gray80", "gray30"),
                font=ctk.CTkFont(size=12),
                command=lambda p=proj["id"]: self._select_project(p)
            )
            btn.grid(sticky="ew", pady=1, padx=2)
            self.proj_buttons[proj["id"]] = btn
            
            # Tooltip
            Tooltip(btn, proj["title"])
            
        # Restaurar resaltado
        if self.selected_project_id:
            self._highlight_selection(self.selected_project_id)

    def _select_project(self, project_id):
        self.selected_project_id = project_id
        self._highlight_selection(project_id)
        self.selected_ded_id = None
        
        # Mostrar total proyecto
        total_p = get_total_project_imputed(project_id)
        self.lbl_proj_total.configure(text=f"Total: {total_p:.1f}h")
        self.lbl_team_total.configure(text="")
        
        self._refresh_deds()

    def _highlight_selection(self, project_id):
        # Restablecer todos
        for pid, btn in self.proj_buttons.items():
            btn.configure(fg_color="transparent")
        
        # Resaltar seleccinado
        if project_id in self.proj_buttons:
            self.proj_buttons[project_id].configure(fg_color="#34495e")

    def _refresh_deds(self):
        for w in self.ded_frame.winfo_children():
            w.destroy()
        self.ded_buttons = {} # Limpiar mapa
        for w in self.logs_frame.winfo_children():
            w.destroy()
        self.lbl_total.configure(text="— h")
        
        if not self.selected_project_id:
            return
        self.dedications = get_dedications_by_project(self.selected_project_id)
        for ded in self.dedications:
            team_name = ded.get("team_name", str(ded["team_id"]))
            lbl = f"{team_name} ({ded['status']})"
            btn = ctk.CTkButton(
                self.ded_frame, text=lbl, anchor="w",
                fg_color="transparent", text_color=("black", "white"),
                hover_color=("gray80", "gray30"),
                command=lambda d=ded["id"]: self._select_ded(d)
            )
            btn.grid(sticky="ew", pady=1)
            self.ded_buttons[ded["id"]] = btn
            Tooltip(btn, lbl)
            
        # Restaurar resaltado si aplica
        if self.selected_ded_id:
            self._highlight_ded_selection(self.selected_ded_id)

    def _select_ded(self, ded_id):
        self.selected_ded_id = ded_id
        self._highlight_ded_selection(ded_id)
        self.selected_log_id = None
        
        # Mostrar total equipo (dedicación)
        total_t = get_imputed_hours(ded_id)
        self.lbl_team_total.configure(text=f"Total: {total_t:.1f}h")
        self.lbl_total.configure(text=f"{total_t:.1f} h")
        
        self._refresh_logs()

    def _highlight_ded_selection(self, ded_id):
        for did, btn in self.ded_buttons.items():
            btn.configure(fg_color="transparent")
        
        if ded_id in self.ded_buttons:
            self.ded_buttons[ded_id].configure(fg_color="#34495e")

    def _refresh_logs(self):
        for w in self.logs_frame.winfo_children():
            w.destroy()
        if not self.selected_ded_id:
            return
        self.logs = get_logs_by_dedication(self.selected_ded_id)
        for log in self.logs:
            row_frame = ctk.CTkFrame(self.logs_frame, fg_color="transparent")
            row_frame.grid(sticky="ew", pady=2)
            row_frame.grid_columnconfigure(0, weight=1)
            lbl = f"📅 {db_to_gui(log['log_date'])}  —  {log['hours']:.1f} h"
            btn = ctk.CTkButton(
                row_frame, text=lbl, anchor="w",
                fg_color="transparent", text_color=("black", "white"),
                hover_color=("gray80", "gray30"),
                command=lambda lg=log: self._select_log(lg)
            )
            btn.grid(row=0, column=0, sticky="ew")

        # Refrescar totales superiores también al cambiar logs
        total_t = get_imputed_hours(self.selected_ded_id)
        self.lbl_team_total.configure(text=f"Total: {total_t:.1f}h")
        self.lbl_total.configure(text=f"{total_t:.1f} h")
        
        if self.selected_project_id:
            total_p = get_total_project_imputed(self.selected_project_id)
            self.lbl_proj_total.configure(text=f"Total: {total_p:.1f}h")

    def _select_log(self, log):
        self.selected_log_id = log["id"]
        self.date_entry.delete(0, "end")
        self.date_entry.insert(0, db_to_gui(log["log_date"]))
        self.hours_entry.delete(0, "end")
        self.hours_entry.insert(0, str(log["hours"]))

    def _add_log(self):
        if not self.selected_ded_id:
            messagebox.showwarning("Aviso", "Selecciona una dedicación.")
            return
        try:
            hours_val = float(self.hours_entry.get())
        except ValueError:
            messagebox.showerror("Error", "Las horas deben ser un número.")
            return
        
        log_date_gui = self.date_entry.get().strip()
        log_date_db = gui_to_db(log_date_gui)
        
        # Validación de rango de fechas
        ded = next((d for d in self.dedications if d["id"] == self.selected_ded_id), None)
        if ded:
            if log_date_db < ded["start_date"] or (ded["end_date"] and log_date_db > ded["end_date"]):
                start_disp = db_to_gui(ded["start_date"])
                end_disp = db_to_gui(ded["end_date"]) if ded["end_date"] else "..."
                messagebox.showerror("Error", f"La fecha de imputación debe estar entre {start_disp} y {end_disp}.")
                return

        try:
            add_log({
                "project_team_id": self.selected_ded_id,
                "log_date": log_date_db,
                "hours": hours_val
            })
            self._refresh_logs()
        except Exception as e:
            if "UNIQUE" in str(e):
                messagebox.showerror("Error", f"Ya existe una imputación para el día {log_date_gui} para este equipo.")
            else:
                messagebox.showerror("Error", str(e))

    def _update_log(self):
        if not self.selected_log_id:
            messagebox.showwarning("Aviso", "Selecciona un log primero.")
            return
        try:
            hours_val = float(self.hours_entry.get())
        except ValueError:
            messagebox.showerror("Error", "Las horas deben ser un número.")
            return
        
        log_date_gui = self.date_entry.get().strip()
        log_date_db = gui_to_db(log_date_gui)

        # Validación de rango de fechas
        ded = next((d for d in self.dedications if d["id"] == self.selected_ded_id), None)
        if ded:
            if log_date_db < ded["start_date"] or (ded["end_date"] and log_date_db > ded["end_date"]):
                start_disp = db_to_gui(ded["start_date"])
                end_disp = db_to_gui(ded["end_date"]) if ded["end_date"] else "..."
                messagebox.showerror("Error", f"La fecha de imputación debe estar entre {start_disp} y {end_disp}.")
                return

        try:
            update_log(self.selected_log_id, log_date_db, hours_val)
            self._refresh_logs()
        except Exception as e:
            if "UNIQUE" in str(e):
                messagebox.showerror("Error", f"Ya existe otra imputación para el día {log_date_gui} para este equipo.")
            else:
                messagebox.showerror("Error", str(e))

    def _delete_log(self):
        if not self.selected_log_id:
            messagebox.showwarning("Aviso", "Selecciona un log.")
            return
        if messagebox.askyesno("Confirmar", "¿Borrar esta imputación?"):
            delete_log(self.selected_log_id)
            self.selected_log_id = None
            self._refresh_logs()
