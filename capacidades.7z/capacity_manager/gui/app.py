"""
gui/app.py — Ventana principal con navegación por pestañas.
"""
import customtkinter as ctk
from gui.teams_tab import TeamsTab
from gui.requests_tab import RequestsTab
from gui.projects_tab import ProjectsTab
from gui.hours_log_tab import HoursLogTab
from gui.calendar_tab import CalendarTab
from gui.capacity_tab import CapacityTab
from gui.reports_tab import ReportsTab
from gui.dependencies_tab import DependenciesTab
from gui.imputations_load_tab import ImputationsLoadTab
from gui.notes_tab import NotesTab
from gui.links_tab import LinksTab
from gui.config_tab import ConfigTab


class App(ctk.CTk):
    def __init__(self):
        super().__init__()
        self.title("7429-Particulares Activo")
        self.geometry("1280x780")
        self.minsize(1000, 600)

        ctk.set_appearance_mode("dark")
        ctk.set_default_color_theme("blue")

        self._build_ui()

    def _build_ui(self):
        self.grid_columnconfigure(0, weight=1)
        self.grid_rowconfigure(1, weight=1)

        # ── Header ─────────────────────────────────────────────────────
        header = ctk.CTkFrame(self, fg_color="#1a2535", corner_radius=0)
        header.grid(row=0, column=0, sticky="ew")
        ctk.CTkLabel(
            header,
            text="⚙ Capacidad de Equipos",
            font=ctk.CTkFont(family="Segoe UI", size=22, weight="bold"),
            text_color="#4fc3f7"
        ).pack(side="left", padx=20, pady=12)

        # ── TabView principal ──────────────────────────────────────────
        self.tabview = ctk.CTkTabview(self, anchor="nw")
        self.tabview.grid(row=1, column=0, sticky="nsew", padx=8, pady=8)

        tabs = [
            ("🏢 Equipos", TeamsTab),
            ("📋 Solicitudes", RequestsTab),
            ("📋 Proyectos", ProjectsTab),
            ("⏱ Imputaciones", HoursLogTab),
            ("📅 Calendario", CalendarTab),
            ("📊 Capacidad", CapacityTab),
            ("🔗 Dependencias", DependenciesTab),
            ("📄 Informes", ReportsTab),
            ("📥 Carga Imp.", ImputationsLoadTab),
            ("📝 Notas", NotesTab),
            ("🌐 Enlaces", LinksTab),
            ("⚙ Config", ConfigTab),
        ]

        self.tab_instances = {}
        for tab_name, TabClass in tabs:
            self.tabview.add(tab_name)
            frame = self.tabview.tab(tab_name)
            frame.grid_columnconfigure(0, weight=1)
            frame.grid_rowconfigure(0, weight=1)
            instance = TabClass(frame)
            instance.grid(row=0, column=0, sticky="nsew")
            self.tab_instances[tab_name] = instance

        # Refrescar pestañas dependientes al cambiar de pestaña
        self.tabview.configure(command=self._on_tab_change)

    def _on_tab_change(self):
        current = self.tabview.get()
        # Refrescar datos cuando se navega a pestañas que dependen de otras
        refresh_map = {
            "📋 Solicitudes": ["📋 Solicitudes"],
            "📋 Proyectos": ["📋 Proyectos"],
            "⏱ Imputaciones": ["⏱ Imputaciones"],
            "📊 Capacidad": ["📊 Capacidad"],
            "📄 Informes": ["📄 Informes"],
            "📥 Carga Imp.": ["📥 Carga Imp."],
        }
        for tab_name in refresh_map.get(current, []):
            instance = self.tab_instances.get(tab_name)
            # Refrescar proyectos o solicitudes
            if instance and hasattr(instance, "refresh"):
                instance.refresh()
            elif instance and hasattr(instance, "refresh_projects"):
                instance.refresh_projects()
