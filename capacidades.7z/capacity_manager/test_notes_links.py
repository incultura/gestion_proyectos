import os
from db.database import initialize_db
from db.models.notes import create_note, get_all_notes, search_notes, delete_note
from db.models.links import create_link, get_all_links, search_links, delete_link

def test_notes():
    print("Testing Notes...")
    initialize_db()
    nid = create_note("Test Note 1", "This is some searchable text.")
    print(f"Created note ID: {nid}")
    
    notes = get_all_notes()
    assert len(notes) >= 1
    
    # Search by content
    results = search_notes("searchable")
    print(f"Notes found: {len(results)}")
    assert len(results) >= 1
    
    # Delete
    delete_note(nid)
    print("Deleted note.")

def test_links():
    print("Testing Links...")
    initialize_db()
    lid = create_link("Google Search engine test", "https://google.com")
    print(f"Created link ID: {lid}")
    
    links = get_all_links()
    assert len(links) >= 1
    
    # Search by title
    results = search_links("engine")
    print(f"Links found: {len(results)}")
    assert len(results) >= 1
    
    # Search by URL should NOT work (per user request: only title)
    results2 = search_links("google.com")
    # Actually, if "google" is in title, it might match. Let's test with a title that doesn't have the URL string
    lid2 = create_link("DuckDuckGo", "https://duckduckgo.com")
    results3 = search_links("duckduckgo.com")
    print(f"Links found for URL search (should be 0): {len(results3)}")
    assert len(results3) == 0
    
    # Delete
    delete_link(lid)
    delete_link(lid2)
    print("Deleted links.")

if __name__ == "__main__":
    test_notes()
    test_links()
    print("ALL TESTS PASSED!")
