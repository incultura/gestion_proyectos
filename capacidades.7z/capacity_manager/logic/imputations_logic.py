
import pandas as pd
import os
from datetime import datetime
from db.database import get_connection

def calculate_team(row):
    """
    Placeholder for team calculation logic.
    For now, return Area or some combination.
    """
    # User said "ya crearé yo el contenido", but I'll provide a basic one
    # that can be easily replaced.
    area = str(row.get('Area', '')).strip()
    return area if area else "Sin Equipo"

def read_and_process_file(file_path):
    """Reads the 'Datos' tab and prepares the data."""
    if not os.path.exists(file_path):
        raise FileNotFoundError(f"No se encuentra el archivo: {file_path}")
    
    # Validar que existe la pestaña Datos antes de leer
    with pd.ExcelFile(file_path) as xls:
        if 'Datos' not in xls.sheet_names:
            raise ValueError("El archivo Excel no contiene la pestaña obligatoria: 'Datos'")
    
    # Leer pestaña Datos
    df = pd.read_excel(file_path, sheet_name='Datos')
    
    # Limpieza de nombres de columnas (eliminar espacios accidentales)
    df.columns = df.columns.str.strip()
    
    # Limpieza de datos robusta: evitar que pandas trate campos de texto como floats (ej. '100.0') o NaN
    cols_to_clean = ['Solicitud', 'Codigo Actividad', 'Tipo Actividad', 'Area']
    for col in cols_to_clean:
        if col in df.columns:
            df[col] = df[col].astype(str).str.replace(r'\.0$', '', regex=True)
            df[col] = df[col].replace('nan', '', case=False).str.strip()
            
    # Calcular equipo para cada fila
    df['calculated_team'] = df.apply(calculate_team, axis=1)
    
    # Validar integridad referencial y asignación de equipos
    validate_imputations_data(df)
    
    return df

def validate_imputations_data(df):
    """Valida que todas las filas tengan equipo y existan sus IDs en la BD para tipos que no sean Operación."""
    conn = get_connection()
    try:
        valid_solicitudes = {str(r['id_solicitud']) for r in conn.execute("SELECT id_solicitud FROM projects WHERE id_solicitud IS NOT NULL AND id_solicitud != ''").fetchall()}
        
        # Mapeo de nombre de equipo a ID
        teams_map = {r['name'].lower(): r['id'] for r in conn.execute("SELECT id, name FROM teams").fetchall()}
        
        # Dedicaciones válidas: conjunto de tuplas (str(team_id), str(id_proyecto))
        valid_dedications = {
            (str(r['team_id']), str(r['id_proyecto'])) 
            for r in conn.execute("SELECT team_id, id_proyecto FROM project_teams WHERE id_proyecto IS NOT NULL AND id_proyecto != ''").fetchall()
        }

        errors = []
        for idx, row in df.iterrows():
            row_num = idx + 2 # +2 por base 0 de pandas y el header de Excel
            
            team_name = str(row.get('calculated_team', '')).strip()
            if not team_name or team_name == "Sin Equipo":
                errors.append(f"Fila {row_num}: No se pudo determinar el equipo que imputa.")
                continue
                
            team_id = teams_map.get(team_name.lower())
            if not team_id:
                errors.append(f"Fila {row_num}: El equipo '{team_name}' no existe en la base de datos (tabla teams).")
                continue
            
            tipo = str(row.get('Tipo Actividad', '')).strip()
            if tipo != '1. Operación':
                sol = str(row.get('Solicitud', '')).strip()
                if not sol: sol = '0'
                
                cod = str(row.get('Codigo Actividad', '')).strip()
                if not cod: cod = '0'
                
                # Regla 1: solicitud debe existir como id_solicitud en projects
                if sol != '0' and sol not in valid_solicitudes:
                    errors.append(f"Fila {row_num}: La Solicitud '{sol}' no existe como id_solicitud dado de alta en Proyectos.")
                
                # Regla 2: codigo actividad debe existir como id_proyecto para ese team_id en project_teams
                if cod != '0':
                    if (str(team_id), cod) not in valid_dedications:
                        errors.append(f"Fila {row_num}: El Codigo Actividad '{cod}' no existe como id_proyecto en Dedicaciones para el equipo '{team_name}'.")
                    
        if errors:
            msg = "Errores de validación. La carga completa ha sido abortada. Registre lo necesario en Proyectos o Dedicaciones:\n\n"
            msg += "\n".join(errors[:15])
            if len(errors) > 15:
                msg += f"\n... y {len(errors) - 15} errores más."
            raise ValueError(msg)
    finally:
        conn.close()

def generate_summary(df):
    """Calculates summary for the GUI preview."""
    # Columnas: Equipo, Tipo, Subtipo, Total Horas, % sobre Total Equipo
    summary = df.groupby(['calculated_team', 'Tipo Actividad', 'Subtipo'])['Esfuerzo en horas'].sum().reset_index()
    summary.columns = ['Equipo', 'Tipo', 'Subtipo', 'Horas']
    
    # Calcular totales por equipo para los porcentajes
    team_totals = df.groupby('calculated_team')['Esfuerzo en horas'].sum().reset_index()
    team_totals.columns = ['Equipo', 'TotalEquipo']
    
    summary = summary.merge(team_totals, on='Equipo')
    summary['Porcentaje'] = (summary['Horas'] / summary['TotalEquipo']) * 100
    
    return summary

def apply_bulk_load(df, file_path):
    """Saves everything to the database."""
    conn = get_connection()
    try:
        filename = os.path.basename(file_path)
        total_rows = len(df)
        total_hours = df['Esfuerzo en horas'].sum()
        
        # 1. Crear entrada en loads_log
        cur = conn.execute("""
            INSERT INTO loads_log (filename, file_path, total_rows, total_hours)
            VALUES (?, ?, ?, ?)
        """, (filename, file_path, total_rows, total_hours))
        load_id = cur.lastrowid
        
        # 2. Guardar imputations_raw
        raw_data = df.copy()
        raw_data['load_id'] = load_id
        # Convertir nombres de columnas a los de la tabla
        column_map = {
            'Rol': 'rol', 'Tipo Actividad': 'tipo_actividad', 'Codigo Actividad': 'cod_actividad',
            'Nombre Actividad': 'nom_actividad', 'Nombre Tarea': 'nom_tarea', 'Empresa': 'empresa',
            'Codigo usuario que imputa': 'cod_usuario', 'Usuario que imputa': 'nom_usuario',
            'Area': 'area', 'Departamento': 'departamento', 'Año-Mes': 'anio_mes',
            'Esfuerzo en horas': 'horas', 'Subtipo': 'subtipo', 'Prioridad': 'prioridad',
            'Solicitud': 'solicitud', 'Fecha Suspension': 'fecha_suspension',
            'Fecha ultima replanificacion': 'fecha_replan', 'Aplicacion CGDN': 'aplicacion_cgdn',
            'Entregable': 'entregable', 'Entidad': 'entidad', 'calculated_team': 'calculated_team',
            'load_id': 'load_id'
        }
        raw_data = raw_data[list(column_map.keys())].rename(columns=column_map)
        raw_data.to_sql('imputations_raw', conn, if_exists='append', index=False)
        
        # 3. Procesar y guardar en hours_log
        # Solo lo que NO es "1. Operación"
        df_impute = df[df['Tipo Actividad'] != '1. Operación'].copy()
        
        # Necesitamos buscar los project_team_id
        # Primero obtenemos todos los equipos y proyectos para mapear
        teams_map = {r['name'].lower(): r['id'] for r in conn.execute("SELECT id, name FROM teams").fetchall()}
        
        for _, row in df_impute.iterrows():
            team_name = str(row['calculated_team']).lower()
            solicitud = str(row.get('Solicitud', '')).strip()
            cod_actividad = str(row.get('Codigo Actividad', '')).strip()
            
            # Buscar proyecto
            proj_row = None
            if solicitud and solicitud != '0':
                proj_row = conn.execute("SELECT id FROM projects WHERE id_solicitud = ?", (solicitud,)).fetchone()
            
            if not proj_row and cod_actividad:
                # Intentar por id_proyecto en dedicaciones? No, id_proyecto está en project_teams
                pass 

            # Buscar dedicación (project_team_id)
            # El usuario dijo: "con el codigo de activdad obtendrás el proyecto (idproyecto)"
            # Entiendo que se refiere a id_proyecto en project_teams
            pt_row = None
            team_id = teams_map.get(team_name)
            
            if team_id:
                if cod_actividad:
                    pt_row = conn.execute("""
                        SELECT id FROM project_teams 
                        WHERE team_id = ? AND id_proyecto = ?
                    """, (team_id, cod_actividad)).fetchone()
                
                if not pt_row and proj_row:
                    pt_row = conn.execute("""
                        SELECT id FROM project_teams 
                        WHERE team_id = ? AND project_id = ?
                    """, (team_id, proj_row['id'])).fetchone()
            
            if pt_row:
                # Grabar imputación
                # Fecha: Año-Mes es formato 2024-01? Usaremos el primer día del mes o hoy?
                # Usaremos el primer día del mes indicado para simplificar, o la fecha de carga.
                # El usuario dijo "a la fecha de carga" para el registro? 
                # Releyendo: "registrar a la fecha de carga un total de horas a imputar"
                log_date = datetime.now().strftime("%Y-%m-%d")
                conn.execute("""
                    INSERT INTO hours_log (project_team_id, log_date, hours, comment, load_id)
                    VALUES (?, ?, ?, ?, ?)
                """, (pt_row['id'], log_date, row['Esfuerzo en horas'], f"Carga masiva: {filename}", load_id))

        conn.commit()
        return load_id
    finally:
        conn.close()

def rollback_load(load_id):
    """Deletes all data associated with a load_id."""
    conn = get_connection()
    try:
        conn.execute("DELETE FROM hours_log WHERE load_id = ?", (load_id,))
        conn.execute("DELETE FROM imputations_raw WHERE load_id = ?", (load_id,))
        conn.execute("DELETE FROM loads_log WHERE id = ?", (load_id,))
        conn.commit()
    finally:
        conn.close()

def get_load_history(n=10):
    """Returns last n loads."""
    conn = get_connection()
    try:
        rows = conn.execute("""
            SELECT * FROM loads_log ORDER BY timestamp DESC LIMIT ?
        """, (n,)).fetchall()
        return [dict(r) for r in rows]
    finally:
        conn.close()
