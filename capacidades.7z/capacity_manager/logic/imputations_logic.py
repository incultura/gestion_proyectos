
import pandas as pd
import os
from datetime import datetime
from db.database import get_connection

def calculate_team(row):
    """
    Placeholder for team calculation logic.
    For now, return Area or some combination.
    """
    area = str(row.get('Area', '')).strip()
    return area if area else "Sin Equipo"

def read_and_process_file(file_path):
    """Reads the 'Datos' tab and prepares the data."""
    if not os.path.exists(file_path):
        raise FileNotFoundError(f"No se encuentra el archivo: {file_path}")
    
    # Validar que existe la pestaña Datos antes de leer
    with pd.ExcelFile(file_path) as xls:
        if 'Datos' not in xls.sheet_names:
            raise ValueError("El archivo Excel no contiene la pestaña obligatoria: 'Datos'")
    
    # Leer pestaña Datos
    df = pd.read_excel(file_path, sheet_name='Datos')
    
    # Limpieza de nombres de columnas (eliminar espacios accidentales)
    df.columns = df.columns.str.strip()
    
    # Limpieza de datos robusta: evitar que pandas trate campos de texto como floats (ej. '100.0') o NaN
    cols_to_clean = ['Solicitud', 'Codigo Actividad', 'Tipo Actividad', 'Area']
    for col in cols_to_clean:
        if col in df.columns:
            df[col] = df[col].astype(str).str.replace(r'\.0$', '', regex=True)
            df[col] = df[col].replace('nan', '', case=False).str.strip()
            
    # Calcular equipo para cada fila
    df['calculated_team'] = df.apply(calculate_team, axis=1)
    
    # Validar integridad referencial y asignación de equipos
    validate_imputations_data(df)
    
    return df

def validate_imputations_data(df):
    """Valida que todas las filas tengan equipo y existan sus IDs en la BD para tipos que no sean Operación."""
    conn = get_connection()
    try:
        # id_solicitud está en solicitudes
        valid_solicitudes = {str(r['id_solicitud']) for r in conn.execute("SELECT id_solicitud FROM solicitudes WHERE id_solicitud IS NOT NULL AND id_solicitud != ''").fetchall()}
        
        # Mapeo de nombre de equipo a ID
        teams_map = {r['name'].lower(): r['id'] for r in conn.execute("SELECT id, name FROM teams").fetchall()}
        
        # Proyectos válidos (antes dedicaciones): conjunto de tuplas (str(team_id), str(id_proyecto))
        # id_proyecto está en projects
        valid_projects = {
            (str(r['team_id']), str(r['id_proyecto'])) 
            for r in conn.execute("SELECT team_id, id_proyecto FROM projects WHERE id_proyecto IS NOT NULL AND id_proyecto != ''").fetchall()
        }

        errors = []
        for idx, row in df.iterrows():
            row_num = idx + 2 # +2 por base 0 de pandas y el header de Excel
            
            team_name = str(row.get('calculated_team', '')).strip()
            if not team_name or team_name == "Sin Equipo":
                errors.append(f"Fila {row_num}: No se pudo determinar el equipo que imputa.")
                continue
                
            team_id = teams_map.get(team_name.lower())
            if not team_id:
                errors.append(f"Fila {row_num}: El equipo '{team_name}' no existe en la base de datos (tabla teams).")
                continue
            
            tipo = str(row.get('Tipo Actividad', '')).strip()
            if tipo != '1. Operación':
                sol = str(row.get('Solicitud', '')).strip()
                if not sol: sol = '0'
                
                cod = str(row.get('Codigo Actividad', '')).strip()
                if not cod: cod = '0'
                
                # Regla 1: solicitud debe existir como id_solicitud en solicitudes
                if sol != '0' and sol not in valid_solicitudes:
                    errors.append(f"Fila {row_num}: La Solicitud '{sol}' no existe como id_solicitud dado de alta en Solicitudes.")
                
                # Regla 2: codigo actividad debe existir como id_proyecto para ese team_id en projects
                if cod != '0':
                    if (str(team_id), cod) not in valid_projects:
                        errors.append(f"Fila {row_num}: El Codigo Actividad '{cod}' no existe como id_proyecto en Proyectos para el equipo '{team_name}'.")
                    
        if errors:
            msg = "Errores de validación. La carga completa ha sido abortada. Registre lo necesario en Solicitudes o Proyectos:\n\n"
            msg += "\n".join(errors[:15])
            if len(errors) > 15:
                msg += f"\n... y {len(errors) - 15} errores más."
            raise ValueError(msg)
    finally:
        conn.close()

def generate_summary(df):
    """Calculates summary for the GUI preview."""
    summary = df.groupby(['calculated_team', 'Tipo Actividad', 'Subtipo'])['Esfuerzo en horas'].sum().reset_index()
    summary.columns = ['Equipo', 'Tipo', 'Subtipo', 'Horas']
    
    team_totals = df.groupby('calculated_team')['Esfuerzo en horas'].sum().reset_index()
    team_totals.columns = ['Equipo', 'TotalEquipo']
    
    summary = summary.merge(team_totals, on='Equipo')
    summary['Porcentaje'] = (summary['Horas'] / summary['TotalEquipo']) * 100
    
    return summary

def apply_bulk_load(df, file_path):
    """Saves everything to the database."""
    conn = get_connection()
    try:
        filename = os.path.basename(file_path)
        total_rows = len(df)
        total_hours = df['Esfuerzo en horas'].sum()
        
        # 1. Crear entrada en loads_log
        cur = conn.execute("""
            INSERT INTO loads_log (filename, file_path, total_rows, total_hours)
            VALUES (?, ?, ?, ?)
        """, (filename, file_path, total_rows, total_hours))
        load_id = cur.lastrowid
        
        # 2. Guardar imputations_raw
        raw_data = df.copy()
        raw_data['load_id'] = load_id
        column_map = {
            'Rol': 'rol', 'Tipo Actividad': 'tipo_actividad', 'Codigo Actividad': 'cod_actividad',
            'Nombre Actividad': 'nom_actividad', 'Nombre Tarea': 'nom_tarea', 'Empresa': 'empresa',
            'Codigo usuario que imputa': 'cod_usuario', 'Usuario que imputa': 'nom_usuario',
            'Area': 'area', 'Departamento': 'departamento', 'Año-Mes': 'anio_mes',
            'Esfuerzo en horas': 'horas', 'Subtipo': 'subtipo', 'Prioridad': 'priority',
            'Solicitud': 'solicitud', 'Fecha Suspension': 'fecha_suspension',
            'Fecha ultima replanificacion': 'fecha_replan', 'Aplicacion CGDN': 'aplicacion_cgdn',
            'Entregable': 'entregable', 'Entidad': 'entidad', 'calculated_team': 'calculated_team',
            'load_id': 'load_id'
        }
        # El mapeo de prioridad en database.py es 'prioridad'
        column_map['Prioridad'] = 'prioridad'
        
        raw_data = raw_data[list(column_map.keys())].rename(columns=column_map)
        raw_data.to_sql('imputations_raw', conn, if_exists='append', index=False)
        
        # 3. Procesar y guardar en hours_log
        df_impute = df[df['Tipo Actividad'] != '1. Operación'].copy()
        
        teams_map = {r['name'].lower(): r['id'] for r in conn.execute("SELECT id, name FROM teams").fetchall()}
        
        for _, row in df_impute.iterrows():
            team_name = str(row['calculated_team']).lower()
            solicitud_id_val = str(row.get('Solicitud', '')).strip()
            cod_actividad = str(row.get('Codigo Actividad', '')).strip()
            
            # Buscar solicitud
            sol_row = None
            if solicitud_id_val and solicitud_id_val != '0':
                sol_row = conn.execute("SELECT id FROM solicitudes WHERE id_solicitud = ?", (solicitud_id_val,)).fetchone()
            
            # Buscar proyecto (id_proyecto en projects)
            pt_row = None
            team_id = teams_map.get(team_name)
            
            if team_id:
                if cod_actividad:
                    pt_row = conn.execute("""
                        SELECT id FROM projects 
                        WHERE team_id = ? AND id_proyecto = ?
                    """, (team_id, cod_actividad)).fetchone()
                
                if not pt_row and sol_row:
                    pt_row = conn.execute("""
                        SELECT id FROM projects 
                        WHERE team_id = ? AND solicitud_id = ?
                    """, (team_id, sol_row['id'])).fetchone()
            
            if pt_row:
                log_date = datetime.now().strftime("%Y-%m-%d")
                conn.execute("""
                    INSERT INTO hours_log (project_id, log_date, hours, comment, load_id)
                    VALUES (?, ?, ?, ?, ?)
                """, (pt_row['id'], log_date, row['Esfuerzo en horas'], f"Carga masiva: {filename}", load_id))

        conn.commit()
        return load_id
    finally:
        conn.close()

def rollback_load(load_id):
    """Deletes all data associated with a load_id."""
    conn = get_connection()
    try:
        conn.execute("DELETE FROM hours_log WHERE load_id = ?", (load_id,))
        conn.execute("DELETE FROM imputations_raw WHERE load_id = ?", (load_id,))
        conn.execute("DELETE FROM loads_log WHERE id = ?", (load_id,))
        conn.commit()
    finally:
        conn.close()

def get_load_history(n=10):
    """Returns last n loads."""
    conn = get_connection()
    try:
        rows = conn.execute("""
            SELECT * FROM loads_log ORDER BY timestamp DESC LIMIT ?
        """, (n,)).fetchall()
        return [dict(r) for r in rows]
    finally:
        conn.close()
