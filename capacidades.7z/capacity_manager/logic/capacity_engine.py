"""
logic/capacity_engine.py — Motor de cálculo de carga de capacidad.

Con horas anuales directas:
  horas_mes = total_anual × (días_efectivos_mes / días_laborables_año)
"""
from datetime import date
import calendar as _cal
from db.models.teams import get_all_teams, team_total_annual_hours, get_team
from db.models.project_teams import get_all_active_dedications, get_imputed_hours
from db.models.hours_log import get_last_imputation_date
from db.models.calendar_config import get_month_availability
from logic.calendar_engine import get_working_days, months_in_range


def _working_days_year(year: int) -> int:
    return sum(get_working_days(year, m) for m in range(1, 13))


def available_hours_for_month(team: dict, year: int, month: int) -> dict:
    """
    Horas disponibles del equipo en un mes concreto.
    Se reparte el total anual proporcionalmente a los días laborables del mes
    y se ajusta por el % de disponibilidad mensual (vacaciones, etc.).
    """
    avail_pct = get_month_availability(year, month)
    raw_days = get_working_days(year, month)
    eff_days = raw_days * (avail_pct / 100.0)

    annual_total = team_total_annual_hours(team)
    annual_days = _working_days_year(year)

    if annual_days == 0:
        total_hours = 0.0
    else:
        total_hours = annual_total * (eff_days / annual_days)

    ops_ratio = team.get("ops_percentage", 0) / 100.0
    ops_hours = total_hours * ops_ratio
    non_ops_hours = total_hours * (1.0 - ops_ratio)

    return {
        "total_hours": total_hours,
        "ops_hours": ops_hours,
        "non_ops_hours": non_ops_hours,
        "working_days_raw": raw_days,
        "effective_working_days": eff_days,
        "avail_pct": avail_pct,
        "annual_total": annual_total,
        "annual_days": annual_days,
    }


def _distribute_hours_linear(dedication: dict, year: int, month: int) -> float:
    """
    Distribuye las horas RESTANTES de una dedicación linealmente entre los
    meses restantes, partiendo desde la última imputación registrada.
    """
    start_str = dedication.get("start_date") or ""
    end_str = dedication.get("end_date") or ""
    if not start_str or not end_str:
        return 0.0

    try:
        start = date.fromisoformat(start_str)
        end = date.fromisoformat(end_str)
    except ValueError:
        return 0.0

    # Determinar el inicio de la distribución: max(start, ultima_imputacion)
    last_act_str = get_last_imputation_date(dedication["id"])
    if last_act_str and last_act_str != "-":
        try:
            last_act = date.fromisoformat(last_act_str)
            # El usuario pide repartir desde la fecha de última imputación.
            # Sin embargo, si la última imputación es antes del inicio, usamos el inicio.
            effective_start = max(start, last_act)
        except ValueError:
            effective_start = start
    else:
        effective_start = start

    target_start = date(year, month, 1)
    target_end = date(year, month, _cal.monthrange(year, month)[1])

    # Si el mes actual es totalmente anterior al inicio de distribución o posterior al fin
    if target_end < effective_start or target_start > end:
        return 0.0

    from logic.calendar_engine import months_in_range, get_working_days_range
    
    remaining_months = months_in_range(effective_start, end)
    if not remaining_months or (year, month) not in remaining_months:
        return 0.0

    est_hours = dedication.get("estimated_hours", 0.0)
    if est_hours <= 0:
        return 0.0

    imputed = get_imputed_hours(dedication["id"])
    remaining_hours = max(0.0, est_hours - imputed)
    if remaining_hours == 0:
        return 0.0

    total_wd = 0
    month_wd = {}
    
    for (y, m) in remaining_months:
        m_start = date(y, m, 1)
        m_end = date(y, m, _cal.monthrange(y, m)[1])
        
        # Intersección entre el periodo de distribución [effective_start, end]
        # y los límites del mes [m_start, m_end]
        inter_start = max(effective_start, m_start)
        inter_end = min(end, m_end)
        
        if inter_start <= inter_end:
            wd = get_working_days_range(inter_start, inter_end)
            month_wd[(y, m)] = wd
            total_wd += wd

    if total_wd == 0:
        # Si no hay días laborables en el rango restante pero quedan horas,
        # esto es una anomalía de calendario (ej. fin de semana perpetuo o error fechas).
        return 0.0

    return remaining_hours * (month_wd.get((year, month), 0) / total_wd)


def compute_team_month_load(team_id: int, year: int, month: int) -> dict:
    team = get_team(team_id)
    if not team:
        return {}

    available = available_hours_for_month(team, year, month)

    dedications_raw = get_all_active_dedications()
    team_deds = [d for d in dedications_raw if d["team_id"] == team_id]

    ops_assigned = 0.0
    non_ops_assigned = 0.0
    dedication_details = []

    for ded in team_deds:
        hours = _distribute_hours_linear(ded, year, month)
        if hours <= 0:
            continue
        typology = ded.get("typology", "").lower()
        is_ops = typology == "operacion"
        if is_ops:
            ops_assigned += hours
        else:
            non_ops_assigned += hours
        dedication_details.append({
            "project_id": ded["project_id"],
            "title": ded.get("title", f"P{ded['project_id']}"),
            "description": ded.get("description", ""),
            "typology": typology,
            "hours": hours,
            "is_ops": is_ops,
        })

    ops_load_pct = (ops_assigned / available["ops_hours"] * 100) if available["ops_hours"] > 0 else 0.0
    non_ops_load_pct = (non_ops_assigned / available["non_ops_hours"] * 100) if available["non_ops_hours"] > 0 else 0.0
    total_load_pct = ((ops_assigned + non_ops_assigned) / available["total_hours"] * 100) if available["total_hours"] > 0 else 0.0

    return {
        "available": available,
        "ops_assigned": ops_assigned,
        "non_ops_assigned": non_ops_assigned,
        "ops_load_pct": ops_load_pct,
        "non_ops_load_pct": non_ops_load_pct,
        "total_load_pct": total_load_pct,
        "dedications": dedication_details,
        "team_name": team.get("name", str(team_id)),
    }


def compute_all_teams_year(year: int) -> dict:
    teams = get_all_teams()
    result = {}
    for team in teams:
        result[team["id"]] = {}
        for month in range(1, 13):
            result[team["id"]][month] = compute_team_month_load(team["id"], year, month)
    return result
