"""
logic/capacity_engine.py — Motor de cálculo de capacidad (v7: 3-level).
"""
from datetime import date
import calendar as _cal
from db.models.teams import get_all_teams, team_total_annual_hours, get_team
from db.models.dedications import get_all_active_dedications, get_imputed_hours
from db.models.hours_log import get_last_imputation_date, get_team_month_imputed
from db.models.calendar_config import get_month_availability
from db.models.capacity_snapshots import has_snapshot, save_snapshots, get_team_month_planned
from logic.calendar_engine import get_working_days, months_in_range, get_working_days_range

def _working_days_year(year: int) -> int:
    return sum(get_working_days(year, m) for m in range(1, 13))

def available_hours_for_month(team: dict, year: int, month: int) -> dict:
    avail_pct = get_month_availability(year, month)
    raw_days = get_working_days(year, month)
    eff_days = raw_days * (avail_pct / 100.0)
    annual_total = team_total_annual_hours(team)
    annual_days = _working_days_year(year)
    if annual_days == 0: total_hours = 0.0
    else: total_hours = annual_total * (eff_days / annual_days)
    ops_ratio = team.get("ops_percentage", 0) / 100.0
    ops_hours = total_hours * ops_ratio
    non_ops_hours = total_hours * (1.0 - ops_ratio)
    return {
        "total_hours": total_hours, "ops_hours": ops_hours, "non_ops_hours": non_ops_hours,
        "working_days_raw": raw_days, "effective_working_days": eff_days, "avail_pct": avail_pct
    }

def _distribute_hours_linear(dedication: dict, year: int, month: int) -> dict:
    status_name = dedication.get("status_name", "")
    if status_name == "Detenido": return {"hours": 0.0, "effective_start": None}
    start_str = dedication.get("start_date") or ""
    end_str = dedication.get("end_date") or ""
    if not start_str or not end_str: return {"hours": 0.0, "effective_start": None}
    try:
        start = date.fromisoformat(start_str)
        end = date.fromisoformat(end_str)
    except: return {"hours": 0.0, "effective_start": None}

    last_act_str = get_last_imputation_date(dedication["id"])
    effective_start = start
    if last_act_str and last_act_str != "-":
        try: effective_start = max(start, date.fromisoformat(last_act_str))
        except: pass

    target_start = date(year, month, 1)
    target_end = date(year, month, _cal.monthrange(year, month)[1])
    if target_end < effective_start or target_start > end: return {"hours": 0.0, "effective_start": None}

    remaining_months = months_in_range(effective_start, end)
    if not remaining_months or (year, month) not in remaining_months: return {"hours": 0.0, "effective_start": None}

    est_hours = dedication.get("estimated_hours", 0.0)
    imputed = get_imputed_hours(dedication["id"])
    remaining_hours = max(0.0, est_hours - imputed)
    if remaining_hours == 0: return {"hours": 0.0, "effective_start": None}

    total_wd = 0
    month_wd = 0
    for (y, m) in remaining_months:
        m_start = date(y, m, 1)
        m_end = date(y, m, _cal.monthrange(y, m)[1])
        inter_start = max(effective_start, m_start)
        inter_end = min(end, m_end)
        if inter_start <= inter_end:
            wd = get_working_days_range(inter_start, inter_end)
            total_wd += wd
            if y == year and m == month: month_wd = wd

    if total_wd == 0: return {"hours": 0.0, "effective_start": None}
    hours = remaining_hours * (month_wd / total_wd)
    return {"hours": hours, "effective_start": max(effective_start, target_start)}

def _distribute_hours_full_month(dedication: dict, year: int, month: int) -> float:
    start_str = dedication.get("start_date") or ""
    end_str = dedication.get("end_date") or ""
    if not start_str or not end_str: return 0.0
    try:
        start = date.fromisoformat(start_str)
        end = date.fromisoformat(end_str)
    except: return 0.0
    all_months = months_in_range(start, end)
    if not all_months or (year, month) not in all_months: return 0.0
    est_hours = dedication.get("estimated_hours", 0.0)
    total_wd = 0
    month_wd = 0
    for (y, m) in all_months:
        m_start = date(y, m, 1)
        m_end = date(y, m, _cal.monthrange(y, m)[1])
        inter_start = max(start, m_start)
        inter_end = min(end, m_end)
        if inter_start <= inter_end:
            wd = get_working_days_range(inter_start, inter_end)
            total_wd += wd
            if y == year and m == month: month_wd = wd
    if total_wd == 0: return 0.0
    return est_hours * (month_wd / total_wd)

def compute_team_month_load(team_id: int, year: int, month: int) -> dict:
    team = get_team(team_id)
    if not team: return {}
    available = available_hours_for_month(team, year, month)
    active_deds = [d for d in get_all_active_dedications() if d["team_id"] == team_id]
    
    ops_assigned = 0.0
    non_ops_assigned = 0.0
    details = []
    earliest_eff_start = None
    snapshot_data = []

    today = date.today()
    is_past_or_current = (year < today.year) or (year == today.year and month <= today.month)

    for ded in active_deds:
        res = _distribute_hours_linear(ded, year, month)
        hours = res["hours"]
        eff_start = res["effective_start"]
        planned_hours = _distribute_hours_full_month(ded, year, month)
        
        typology = (ded.get("typology") or "").lower()
        is_ops = typology == "operacion"
        
        if planned_hours > 0:
            snapshot_data.append({"team_id": team_id, "dedication_id": ded["id"], "planned_hours": planned_hours, "typology": typology})
        
        if hours > 0:
            if is_ops: ops_assigned += hours
            else: non_ops_assigned += hours
            if eff_start and (earliest_eff_start is None or eff_start < earliest_eff_start):
                earliest_eff_start = eff_start
            details.append({
                "dedication_id": ded["id"],
                "project_id": ded["project_id"],
                "title": f"#{ded['id_proyecto']} | {ded['project_title']}",
                "typology": typology,
                "hours": hours,
                "is_ops": is_ops
            })

    # Ajuste homogéneo
    month_start = date(year, month, 1)
    month_end = date(year, month, _cal.monthrange(year, month)[1])
    total_wd = available["working_days_raw"]
    if earliest_eff_start and earliest_eff_start > month_start:
        eff_days = get_working_days_range(earliest_eff_start, month_end)
        if total_wd > 0:
            ratio = eff_days / total_wd
            available["total_hours"] *= ratio
            available["ops_hours"] *= ratio
            available["non_ops_hours"] *= ratio

    ops_load_pct = (ops_assigned / available["ops_hours"] * 100) if available["ops_hours"] > 0 else 0.0
    non_ops_load_pct = (non_ops_assigned / available["non_ops_hours"] * 100) if available["non_ops_hours"] > 0 else 0.0
    total_load_pct = ((ops_assigned + non_ops_assigned) / available["total_hours"] * 100) if available["total_hours"] > 0 else 0.0

    planned = {"ops_hours": 0.0, "non_ops_hours": 0.0, "total_hours": 0.0}
    actual = {"ops_hours": 0.0, "non_ops_hours": 0.0, "total_hours": 0.0}
    if is_past_or_current:
        if not has_snapshot(year, month, team_id) and snapshot_data:
            save_snapshots(year, month, snapshot_data)
        planned = get_team_month_planned(team_id, year, month)
        actual = get_team_month_imputed(team_id, year, month)

    return {
        "available": available, "ops_assigned": ops_assigned, "non_ops_assigned": non_ops_assigned,
        "ops_load_pct": ops_load_pct, "non_ops_load_pct": non_ops_load_pct, "total_load_pct": total_load_pct,
        "dedications": details, "team_name": team["name"], "planned": planned, "actual": actual,
        "is_past_or_current": is_past_or_current
    }

def compute_all_teams_year(year: int) -> dict:
    teams = get_all_teams()
    return {t["id"]: {m: compute_team_month_load(t["id"], year, m) for m in range(1, 13)} for t in teams}
