"""
logic/calendar_engine.py — Cálculo de días laborales por mes.

Días NO laborables: viernes (weekday=4) y sábado (weekday=5) 
→ Semana laboral: lunes (0), martes (1), miércoles (2), jueves (3)
También se excluyen los festivos configurados y se aplica el % de disponibilidad mensual.
"""
import calendar
from datetime import date, timedelta
from db.models.calendar_config import get_holiday_dates, get_month_availability

# Días de la semana no laborables (0=lun, 1=mar, 2=mié, 3=jue, 4=vie, 5=sáb, 6=dom)
NON_WORKING_WEEKDAYS = {4, 5}  # viernes=4, sábado=5


def get_working_days(year: int, month: int) -> int:
    """Número de días laborales en un mes (excluye vie/sáb + festivos)."""
    holiday_dates = get_holiday_dates(year)
    _, num_days = calendar.monthrange(year, month)
    count = 0
    for day in range(1, num_days + 1):
        d = date(year, month, day)
        if d.weekday() not in NON_WORKING_WEEKDAYS:
            if d.isoformat() not in holiday_dates:
                count += 1
    return count


def get_effective_working_days(year: int, month: int) -> float:
    """Días laborales ajustados por el % de disponibilidad del mes."""
    base_days = get_working_days(year, month)
    avail_pct = get_month_availability(year, month)
    return base_days * (avail_pct / 100.0)


def get_working_days_range(start: date, end: date, holiday_dates: set = None) -> int:
    """Días laborales entre dos fechas (inclusive), usando el estándar vie/sáb excluidos."""
    if holiday_dates is None:
        # Recopilar festivos de todos los años del rango
        years = set(range(start.year, end.year + 1))
        holiday_dates = set()
        for y in years:
            holiday_dates |= get_holiday_dates(y)
    count = 0
    current = start
    while current <= end:
        if current.weekday() not in NON_WORKING_WEEKDAYS and current.isoformat() not in holiday_dates:
            count += 1
        current += timedelta(days=1)
    return count


def months_in_range(start: date, end: date) -> list[tuple[int, int]]:
    """Lista de (año, mes) entre start y end (inclusive por mes)."""
    result = []
    y, m = start.year, start.month
    while (y, m) <= (end.year, end.month):
        result.append((y, m))
        m += 1
        if m > 12:
            m = 1
            y += 1
    return result
