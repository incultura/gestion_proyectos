"""
logic/report_logic.py — Lógica de agregación y generación de PDFs para informes.
"""
import os
import re
from datetime import date
from fpdf import FPDF
from db.models.teams import get_all_teams, team_total_annual_hours, get_team
from db.models.project_teams import get_all_active_dedications, get_imputed_hours, get_dedications_by_project
from db.models.projects import get_all_projects, get_project, TYPOLOGIES
from db.models.hours_log import get_last_imputation_date
from db.models.annotations import get_annotations_by_project
from db.models.dependencies import get_project_dependencies
from db.models.notes import get_notes_for_report
from logic.capacity_engine import available_hours_for_month, _distribute_hours_linear, _working_days_year
from utils.date_utils import db_to_gui

class ReportPDF(FPDF):
    def header(self):
        self.set_font("helvetica", "B", 15)
        self.cell(0, 10, "Informe de Capacidad de Equipos", border=False, ln=True, align="C")
        self.ln(5)

    def footer(self):
        self.set_y(-15)
        self.set_font("helvetica", "I", 8)
        self.cell(0, 10, f"Pagina {self.page_no()}/{{nb}}", align="C")

    def write_with_links(self, text, height=5):
        """Dectecta URLs y las escribe como enlaces clicables."""
        # Regex simple para detectar URLs
        url_pattern = r'(https?://[^\s,]+|www\.[^\s,]+)'
        parts = re.split(url_pattern, text)
        
        for part in parts:
            if re.match(url_pattern, part):
                url = part if part.startswith("http") else f"http://{part}"
                self.set_text_color(0, 0, 255)
                self.set_font(style="U")
                self.write(height, part, link=url)
                self.set_text_color(0, 0, 0)
                self.set_font(style="")
            else:
                self.write(height, part)

def get_team_report_data(team_id: int, year: int):
    team = get_team(team_id)
    if not team:
        return None

    # 1. Resumen de recursos
    total_hours = team_total_annual_hours(team)
    ops_hours = total_hours * (team.get("ops_percentage", 0) / 100.0)
    non_ops_hours = total_hours - ops_hours

    # 2. Distribución mensual
    monthly_dist = []
    for m in range(1, 13):
        avail = available_hours_for_month(team, year, m)
        monthly_dist.append({
            "month": m,
            "total": avail["total_hours"],
            "ops": avail["ops_hours"],
            "non_ops": avail["non_ops_hours"],
            "days": avail["effective_working_days"]
        })

    # 3. Proyectos Activos (Filtros: fin > hoy, o sin fin, o horas restantes > 0)
    all_deds = get_all_active_dedications()
    team_deds = [d for d in all_deds if d["team_id"] == team_id]
    
    today_str = date.today().isoformat()
    active_projects = []
    for ded in team_deds:
        remaining = max(0.0, ded["estimated_hours"] - get_imputed_hours(ded["id"]))
        is_active = False
        if not ded["end_date"]:
            is_active = True
        elif ded["end_date"] >= today_str:
            is_active = True
        elif remaining > 0:
            is_active = True
        
        if is_active:
            active_projects.append({
                "id": ded["id"],
                "project_title": ded.get("title", f"Project {ded['project_id']}"),
                "start": ded["start_date"],
                "end": ded["end_date"],
                "estimated": ded["estimated_hours"],
                "remaining": remaining,
                "status_name": ded.get("status_name", "Idea"),
                "typology": ded.get("typology", "P")
            })

    # 4. Timeline de carga (desde mes actual)
    current_month = date.today().month
    timeline = []
    for m in range(current_month, 13):
        avail = available_hours_for_month(team, year, m)
        month_non_ops = []
        month_ops = []
        for ded in team_deds:
            h = _distribute_hours_linear(ded, year, m)
            if h <= 0: continue
            
            p_data = {
                "title": ded.get("title", f"P{ded['project_id']}"),
                "hours": h,
                "typology": ded.get("typology", "").lower()
            }
            
            if p_data["typology"] == "operacion":
                month_ops.append(p_data)
            else:
                month_non_ops.append(p_data)
                
        timeline.append({
            "month": m,
            "available_non_ops": avail["non_ops_hours"],
            "available_ops": avail["ops_hours"],
            "projects": month_non_ops,
            "ops_projects": month_ops,
            "total_assigned": sum(p["hours"] for p in month_non_ops),
            "total_ops_assigned": sum(p["hours"] for p in month_ops)
        })

    return {
        "team": team,
        "summary": {
            "total_hours": total_hours,
            "ops_hours": ops_hours,
            "non_ops_hours": non_ops_hours
        },
        "monthly_dist": monthly_dist,
        "active_projects": active_projects,
        "timeline": timeline
    }

def generate_team_pdf(team_id: int, year: int, output_path: str):
    data = get_team_report_data(team_id, year)
    if not data:
        return False

    pdf = ReportPDF()
    pdf.add_page()
    
    # Equipo
    pdf.set_font("helvetica", "B", 12)
    pdf.cell(0, 10, f"Equipo: {data['team']['name']}", ln=True)
    pdf.set_font("helvetica", "", 10)
    pdf.ln(2)

    # 1. Recursos
    pdf.set_font("helvetica", "B", 10)
    pdf.cell(0, 8, "1. RESUMEN DE RECURSOS", ln=True, fill=False)
    pdf.set_font("helvetica", "", 9)
    t = data['team']
    res_text = (f"Internos: {t['internal_people']} ({t['internal_annual_hours']}h) | "
                f"L. Base: {t['baseline_people']} ({t['baseline_annual_hours']}h) | "
                f"Refuerzo: {t['reinforce_people']} ({t['reinforce_annual_hours']}h)")
    pdf.cell(0, 6, res_text, ln=True)
    pdf.cell(0, 6, f"Total Horas Anuales: {data['summary']['total_hours']:.1f}h", ln=True)
    pdf.cell(0, 6, f"Operacion ({t['ops_percentage']}%): {data['summary']['ops_hours']:.1f}h", ln=True)
    pdf.cell(0, 6, f"Proyectos (Resto): {data['summary']['non_ops_hours']:.1f}h", ln=True)
    pdf.ln(5)

    # 2. Distribución mensual
    pdf.set_font("helvetica", "B", 10)
    pdf.cell(0, 8, "2. DISPONIBILIDAD MENSUAL (H)", ln=True)
    pdf.set_font("helvetica", "B", 8)
    pdf.cell(20, 6, "Mes", border=1)
    pdf.cell(30, 6, "Total", border=1)
    pdf.cell(30, 6, "Operacion", border=1)
    pdf.cell(30, 6, "Proyectos", border=1)
    pdf.cell(30, 6, "Dias Ef.", border=1, ln=True)
    
    pdf.set_font("helvetica", "", 8)
    for m in data['monthly_dist']:
        pdf.cell(20, 6, str(m['month']), border=1)
        pdf.cell(30, 6, f"{m['total']:.1f}", border=1)
        pdf.cell(30, 6, f"{m['ops']:.1f}", border=1)
        pdf.cell(30, 6, f"{m['non_ops']:.1f}", border=1)
        pdf.cell(30, 6, f"{m['days']:.1f}", border=1, ln=True)
    pdf.ln(5)

    # 3. Proyectos Activos
    pdf.set_font("helvetica", "B", 10)
    pdf.cell(0, 8, "3. PROYECTOS ACTIVOS Y CARGA PENDIENTE", ln=True)
    pdf.set_font("helvetica", "B", 8)
    pdf.cell(60, 6, "Proyecto", border=1)
    pdf.cell(20, 6, "Tipo", border=1)
    pdf.cell(25, 6, "Fin", border=1)
    pdf.cell(20, 6, "Est. (h)", border=1)
    pdf.cell(20, 6, "Pend. (h)", border=1)
    pdf.cell(25, 6, "Estado", border=1, ln=True)

    pdf.set_font("helvetica", "", 7)
    for p in data['active_projects']:
        pdf.cell(60, 6, p['project_title'][:35], border=1)
        pdf.cell(20, 6, p['typology'], border=1)
        pdf.cell(25, 6, db_to_gui(p['end']) if p['end'] else "-", border=1)
        pdf.cell(20, 6, f"{p['estimated']:.1f}", border=1)
        pdf.cell(20, 6, f"{p['remaining']:.1f}", border=1)
        pdf.cell(25, 6, p['status_name'], border=1, ln=True)
    pdf.ln(5)

    pdf.set_font("helvetica", "B", 10)
    pdf.cell(0, 8, "4. TIMELINE DE CARGA (PROYECTOS)", ln=True)
    for m in data['timeline']:
        pdf.set_font("helvetica", "B", 9)
        pdf.cell(0, 6, f"Mes {m['month']} - Disp. Proyectos: {m['available_non_ops']:.1f}h", ln=True)
        pdf.set_font("helvetica", "", 8)
        
        # Proyectos (No Operación)
        if not m['projects']:
            pdf.cell(0, 5, "   (Sin proyectos asignados)", ln=True)
        else:
            for p in m['projects']:
                pdf.set_x(15) # Identado
                pdf.write_with_links(f"- {p['title']}: {p['hours']:.1f}h")
                pdf.ln(5)
        
        load_projects = (m['total_assigned'] / m['available_non_ops'] * 100) if m['available_non_ops'] > 0 else 0
        pdf.set_font("helvetica", "I", 8)
        pdf.cell(0, 5, f"   Carga Proyectos: {m['total_assigned']:.1f}h ({load_projects:.1f}%)", ln=True)
        
        # Operación (Si hay proyectos adicionales de operación)
        if m['ops_projects']:
            pdf.ln(1)
            pdf.set_font("helvetica", "B", 8)
            pdf.cell(0, 5, f"   Proyectos de Operación Adicionales (Disp: {m['available_ops']:.1f}h):", ln=True)
            pdf.set_font("helvetica", "", 7)
            for p in m['ops_projects']:
                pdf.set_x(20)
                pdf.cell(0, 4, f"* {p['title']}: {p['hours']:.1f}h", ln=True)
            load_ops = (m['total_ops_assigned'] / m['available_ops'] * 100) if m['available_ops'] > 0 else 0
            pdf.set_font("helvetica", "I", 7)
            pdf.cell(0, 4, f"   Carga Extra Operación: {m['total_ops_assigned']:.1f}h ({load_ops:.1f}%)", ln=True)
            
        pdf.ln(2)

    pdf.output(output_path)
    return True

def generate_global_pdf(year: int, output_path: str):
    teams = get_all_teams()
    pdf = ReportPDF()
    pdf.add_page()
    
    pdf.set_font("helvetica", "B", 14)
    pdf.cell(0, 10, f"Resumen Global de Capacidad - Año {year}", ln=True, align="C")
    pdf.ln(5)

    for team in teams:
        data = get_team_report_data(team['id'], year)
        if not data: continue
        
        pdf.set_font("helvetica", "B", 12)
        pdf.set_fill_color(240, 240, 240)
        pdf.cell(0, 8, f"EQUIPO: {team['name']}", ln=True, fill=True)
        pdf.ln(2)

        # 1. Recursos (Resumen)
        pdf.set_font("helvetica", "B", 9)
        pdf.cell(0, 5, "Resumen de Recursos:", ln=True)
        pdf.set_font("helvetica", "", 9)
        t = data['team']
        res_text = (f"Internos: {t['internal_people']} ({t['internal_annual_hours']}h) | "
                    f"L. Base: {t['baseline_people']} ({t['baseline_annual_hours']}h) | "
                    f"Refuerzo: {t['reinforce_people']} ({t['reinforce_annual_hours']}h)")
        pdf.cell(0, 5, res_text, ln=True)
        pdf.cell(0, 5, f"Disp. Proyectos (Año): {data['summary']['non_ops_hours']:.1f}h", ln=True)

        # 2. Carga media
        current_month = date.today().month
        avg_load = 0
        months_count = 0
        for m in data['timeline']:
            if m['available_non_ops'] > 0:
                avg_load += (m['total_assigned'] / m['available_non_ops'] * 100)
                months_count += 1
        
        if months_count > 0:
            avg_load /= months_count
            pdf.set_font("helvetica", "B", 9)
            pdf.cell(0, 5, f"Carga Media proyectada: {avg_load:.1f}%", ln=True)
        
        pdf.ln(2)

        # 3. Proyectos Activos
        pdf.set_font("helvetica", "B", 9)
        pdf.cell(0, 5, f"Proyectos en curso / pendientes ({len(data['active_projects'])}):", ln=True)
        if not data['active_projects']:
            pdf.set_font("helvetica", "I", 8)
            pdf.cell(0, 5, "   (Sin proyectos activos)", ln=True)
        else:
            pdf.set_font("helvetica", "", 8)
            # Cabecera mini-tabla
            pdf.set_x(15)
            pdf.cell(85, 5, "Proyecto", border="B")
            pdf.cell(20, 5, "Tipo", border="B")
            pdf.cell(25, 5, "Fin", border="B")
            pdf.cell(25, 5, "Pendiente", border="B")
            pdf.cell(30, 5, "Estado", border="B", ln=True)
            
            for p in data['active_projects']:
                start_y = pdf.get_y()
                pdf.set_x(15)
                
                # Título con posible link (limitamos ancho visualmente)
                title_text = f"{p['project_title'][:48]}"
                pdf.write_with_links(title_text)
                
                # Volvemos a la misma línea para el resto de columnas
                pdf.set_xy(100, start_y)
                pdf.cell(20, 5, p['typology'], border="B")
                pdf.cell(25, 5, db_to_gui(p['end']) if p['end'] else "-", border="B")
                pdf.cell(25, 5, f"{p['remaining']:.1f}", border="B")
                pdf.cell(30, 5, p['status_name'], border="B", ln=True)
                
                # Línea base para el título para completar el borde de "tabla"
                pdf.line(15, start_y + 5, 100, start_y + 5)
        
        pdf.ln(8)
        
        # Salto de página si queda poco espacio
        if pdf.get_y() > 250:
            pdf.add_page()
        
    pdf.output(output_path)
    return True

def get_project_report_data(project_id: int):
    proj = get_project(project_id)
    if not proj:
        return None
    
    # 1. Info de cabecera ya viene en proj (title, typology, description, request_link, status_name, etc.)
    
    # 2. Dedicaciones de equipos
    deds = get_dedications_by_project(project_id)
    team_assignments = []
    
    for d in deds:
        team_assignments.append({
            "team_name": d["team_name"],
            "start": d["start_date"],
            "end": d["end_date"],
            "estimated": d["estimated_hours"],
            "imputed": get_imputed_hours(d["id"]),
            "remaining": max(0, d["estimated_hours"] - get_imputed_hours(d["id"])),
            "last_activity": get_last_imputation_date(d["id"]),
            "id": d["id"]
        })
        
    # 3. Carga futura por mes y equipo
    current_date = date.today()
    current_year = current_date.year
    current_month = current_date.month
    
    # Encontrar el año/mes máximo de finalización para el timeline
    max_end_str = proj.get("end_date")
    if not max_end_str:
        # Si no hay fin, miramos el máximo de los equipos
        ends = [d["end_date"] for d in deds if d["end_date"]]
        max_end_str = max(ends) if ends else current_date.isoformat()
    
    try:
        max_year = int(max_end_str[:4])
        max_month = int(max_end_str[5:7])
    except:
        max_year = current_year
        max_month = current_month

    future_timeline = []
    y, m = current_year, current_month
    while (y < max_year) or (y == max_year and m <= max_month):
        month_data = {"year": y, "month": m, "teams": []}
        for d in deds:
            h = _distribute_hours_linear(d, y, m)
            if h > 0:
                month_data["teams"].append({"name": d["team_name"], "hours": h})
        
        if month_data["teams"]:
            future_timeline.append(month_data)
            
        m += 1
        if m > 12:
            m = 1
            y += 1
        if len(future_timeline) > 24: break # Safety limit

    # 4. Anotaciones (de más reciente a más antigua)
    annots = get_annotations_by_project(project_id)
    sorted_annots = sorted(annots, key=lambda x: (x['date'], x['annotation_number']), reverse=True)
    
    # 5. Calcular fechas globales del proyecto (min inicio, max fin de los equipos)
    calc_start = None
    calc_end = None
    starts = [d['start_date'] for d in deds if d['start_date']]
    ends = [d['end_date'] for d in deds if d['end_date']]
    if starts: calc_start = min(starts)
    if ends: calc_end = max(ends)

    return {
        "project": proj,
        "assignments": team_assignments,
        "timeline": future_timeline,
        "annotations": sorted_annots,
        "dependencies": get_project_dependencies(project_id),
        "calc_start": calc_start,
        "calc_end": calc_end
    }

def generate_project_pdf(project_id: int, output_path: str):
    data = get_project_report_data(project_id)
    if not data: return False
    
    p = data['project']
    pdf = ReportPDF()
    pdf.add_page()
    pdf.set_font("helvetica", "B", 16)
    pdf.cell(0, 10, f"Proyecto: {p['title']}", ln=True)
    pdf.set_font("helvetica", "B", 12)
    pdf.cell(0, 8, f"Tipología: {p['typology']}  |  Estado: {p['status_name']}", ln=True)
    pdf.ln(2)
    
    # Solicitud (Solo si tiene contenido)
    if p['request_link'] and p['request_link'].strip():
        pdf.set_font("helvetica", "B", 10)
        pdf.cell(30, 6, "Solicitud: ", ln=False)
        pdf.set_font("helvetica", "", 10)
        pdf.write_with_links(p['request_link'])
        pdf.ln(10)
    
    pdf.set_font("helvetica", "B", 10)
    pdf.cell(0, 6, "Descripción:", ln=True)
    pdf.set_font("helvetica", "", 10)
    pdf.multi_cell(0, 5, p['description'] if p['description'] else "(Sin descripción)")
    pdf.ln(5)
    
    # Fechas (Calculadas de los equipos)
    pdf.set_font("helvetica", "B", 10)
    pdf.cell(0, 6, "Calendario del Proyecto:", ln=True)
    pdf.set_font("helvetica", "", 10)
    
    start_disp = db_to_gui(data["calc_start"]) if data["calc_start"] else (db_to_gui(p["start_date"]) if p["start_date"] else "-")
    end_disp = db_to_gui(data["calc_end"]) if data["calc_end"] else (db_to_gui(p["end_date"]) if p["end_date"] else "-")
    
    pdf.cell(60, 6, f"Inicio previsto: {start_disp}")
    pdf.cell(60, 6, f"Fin previsto: {end_disp}")
    if p.get('detention_date'):
        pdf.cell(60, 6, f"Fecha detención: {db_to_gui(p['detention_date'])}")
    pdf.ln(10)
    
    # Tabla deds
    pdf.set_font("helvetica", "B", 12)
    pdf.cell(0, 10, "Equipos y Dedicaciones", ln=True)
    pdf.set_fill_color(240, 240, 240)
    pdf.set_font("helvetica", "B", 9)
    cols = [("Equipo", 50), ("Inicio", 25), ("Fin", 25), ("Est.", 20), ("Imp.", 20), ("Rest.", 20), ("Últ. Act.", 30)]
    for col, w in cols:
        pdf.cell(w, 8, col, border=1, fill=True, align="C")
    pdf.ln()
    
    pdf.set_font("helvetica", "", 9)
    for d in data['assignments']:
        pdf.cell(50, 7, d['team_name'], border=1)
        pdf.cell(25, 7, db_to_gui(d['start']), border=1, align="C")
        pdf.cell(25, 7, db_to_gui(d['end']), border=1, align="C")
        pdf.cell(20, 7, f"{d['estimated']:.0f}h", border=1, align="R")
        pdf.cell(20, 7, f"{d['imputed']:.0f}h", border=1, align="R")
        pdf.set_font("helvetica", "B", 9)
        pdf.cell(20, 7, f"{d['remaining']:.0f}h", border=1, align="R")
        pdf.set_font("helvetica", "", 9)
        pdf.cell(30, 7, db_to_gui(d['last_activity']), border=1, align="C")
        pdf.ln()
    pdf.ln(5)
    
    # Carga mensual futura
    if data['timeline']:
        pdf.set_font("helvetica", "B", 12)
        pdf.cell(0, 10, "Previsión de Carga Mensual (Horas)", ln=True)
        pdf.set_font("helvetica", "B", 9)
        pdf.cell(40, 7, "Mes", border=1, fill=True, align="C")
        pdf.cell(150, 7, "Distribución por Equipo", border=1, fill=True, align="C")
        pdf.ln()
        
        pdf.set_font("helvetica", "", 9)
        for m in data['timeline']:
            pdf.cell(40, 7, f"{m['month']}/{m['year']}", border=1, align="C")
            teams_str = ", ".join([f"{t['name']}: {t['hours']:.1f}h" for t in m['teams']])
            pdf.cell(150, 7, teams_str, border=1)
            pdf.ln()
        pdf.ln(5)
        
    # Dependencias Identificadas
    if data['dependencies']:
        pdf.set_font("helvetica", "B", 12)
        pdf.cell(0, 10, "Dependencias Identificadas (Areas / Aplicaciones)", ln=True)
        pdf.set_font("helvetica", "", 10)
        for d in data['dependencies']:
            pdf.cell(0, 6, f"- {d['name']}", ln=True)
        pdf.ln(5)

    # Anotaciones
    if data['annotations']:
        pdf.set_font("helvetica", "B", 12)
        pdf.cell(0, 10, "Histórico de Anotaciones", ln=True)
        for a in data['annotations']:
            pdf.set_font("helvetica", "B", 9)
            pdf.cell(0, 6, f"Nota #{a['annotation_number']} - {db_to_gui(a['date'])}", ln=True, fill=True)
            pdf.set_font("helvetica", "", 9)
            pdf.multi_cell(0, 5, a['content'])
            pdf.ln(2)
            
    pdf.output(output_path)
    return True


def get_inconsistent_estimates_data():
    """
    Busca proyectos activos donde al menos un equipo ha estimado horas
    y al menos otro equipo en el mismo proyecto no ha estimado.
    """
    all_projects = get_all_projects()
    results = []

    for p in all_projects:
        # Solo proyectos que no estén finalizados o descartados
        if p.get('status_name') in ('Finalizado', 'Descartado'):
            continue

        deds = get_dedications_by_project(p['id'])
        if not deds:
            continue

        teams_with_estimate = [d for d in deds if d['estimated_hours'] > 0]
        teams_without_estimate = [d for d in deds if d['estimated_hours'] == 0]

        if teams_with_estimate and teams_without_estimate:
            results.append({
                "project": p,
                "teams_with": teams_with_estimate,
                "teams_without": teams_without_estimate
            })

    return results


def generate_inconsistent_estimates_pdf(output_path: str):
    data = get_inconsistent_estimates_data()
    pdf = ReportPDF()
    pdf.add_page()

    pdf.set_font("helvetica", "B", 14)
    pdf.cell(0, 10, "Informe: Estimaciones Inconsistentes", ln=True, align="C")
    pdf.set_font("helvetica", "I", 10)
    pdf.cell(0, 8, "Proyectos con equipos estimando y equipos sin estimar", ln=True, align="C")
    pdf.ln(5)

    if not data:
        pdf.set_font("helvetica", "", 12)
        pdf.cell(0, 10, "No se encontraron inconsistencias en las estimaciones.", ln=True)
    else:
        for item in data:
            p = item['project']
            pdf.set_font("helvetica", "B", 12)
            pdf.set_fill_color(230, 230, 230)
            pdf.cell(0, 8, f"PROYECTO: {p['title']} ({p['status_name']})", ln=True, fill=True)
            
            pdf.set_font("helvetica", "B", 10)
            pdf.cell(0, 6, "Equipos con estimación:", ln=True)
            pdf.set_font("helvetica", "", 10)
            for d in item['teams_with']:
                pdf.cell(0, 5, f"   - {d['team_name']}: {d['estimated_hours']}h", ln=True)

            pdf.set_font("helvetica", "B", 10)
            pdf.cell(0, 6, "Equipos SIN estimación:", ln=True)
            pdf.set_font("helvetica", "", 10)
            for d in item['teams_without']:
                pdf.cell(0, 5, f"   - {d['team_name']}", ln=True)
            
            pdf.ln(5)
            if pdf.get_y() > 250:
                pdf.add_page()

    pdf.output(output_path)
    return True

def get_inactive_estimated_projects_data():
    """
    Busca equipos (dedicaciones) que:
    1. Tienen un estado local (en project_teams) distinto de Finalizado, Detenido o Descartado.
    2. Tienen horas estimadas > 0.
    3. No tienen imputaciones (log_date) en los últimos 30 días, o nunca han tenido.
    """
    from db.database import get_connection
    conn = get_connection()
    try:
        # Finalizado (4), Detenido (5), Descartado (6)
        query = """
            SELECT 
                pt.id as pt_id,
                p.title as project_title,
                t.name as team_name,
                pt.estimated_hours,
                s.name as status_name,
                (SELECT MAX(hl.log_date) FROM hours_log hl WHERE hl.project_team_id = pt.id) as last_imputation
            FROM project_teams pt
            JOIN projects p ON pt.project_id = p.id
            JOIN teams t ON pt.team_id = t.id
            JOIN statuses s ON pt.status_id = s.id
            WHERE pt.status_id NOT IN (4, 5, 6)
              AND pt.estimated_hours > 0
        """
        rows = conn.execute(query).fetchall()
        
        results = []
        from datetime import datetime, timedelta
        thirty_days_ago = (datetime.now() - timedelta(days=30)).strftime("%Y-%m-%d")
        
        for r in rows:
            last_date = r["last_imputation"]
            # Si never imputado, o última imputación es anterior a 30 días
            if not last_date or last_date < thirty_days_ago:
                results.append(dict(r))
                
        # Ordenar por proyecto y luego por equipo
        results.sort(key=lambda x: (x['project_title'], x['team_name']))
        return results
    finally:
        conn.close()

def generate_inactive_estimated_projects_pdf(output_path: str):
    data = get_inactive_estimated_projects_data()
    pdf = ReportPDF()
    pdf.add_page()

    pdf.set_font("helvetica", "B", 14)
    pdf.cell(0, 10, "Informe: Inactivos con Estimación", ln=True, align="C")
    pdf.set_font("helvetica", "I", 10)
    pdf.cell(0, 8, "Equipos activos con estimación > 0 y sin imputaciones recientes (>1 mes)", ln=True, align="C")
    pdf.ln(5)

    if not data:
        pdf.set_font("helvetica", "", 12)
        pdf.cell(0, 10, "No se encontraron equipos inactivos con estimaciones en curso.", ln=True)
    else:
        current_project = None
        for item in data:
            if current_project != item['project_title']:
                if current_project is not None:
                    pdf.ln(3)
                current_project = item['project_title']
                pdf.set_font("helvetica", "B", 12)
                pdf.set_fill_color(240, 240, 240)
                pdf.cell(0, 8, f"PROYECTO: {current_project}", ln=True, fill=True)
            
            pdf.set_font("helvetica", "", 10)
            last_imp = db_to_gui(item['last_imputation']) if item['last_imputation'] else "Nunca"
            pdf.cell(0, 6, f"  - Equipo: {item['team_name']}  |  Estado: {item['status_name']}", ln=True)
            pdf.cell(0, 6, f"    Estimado: {item['estimated_hours']}h  |  Última Imputación: {last_imp}", ln=True)
            
            if pdf.get_y() > 250:
                pdf.add_page()
                current_project = None # Force header reprint

    pdf.output(output_path)
    return True

def generate_notes_report_pdf(output_path: str, start_date: str, end_date: str, only_area: bool):
    """
    Genera un informe PDF con las notas en el rango de fechas seleccionado.
    start_date, end_date en formato YYYY-MM-DD
    """
    notes = get_notes_for_report(start_date, end_date, only_area)
    
    pdf = ReportPDF()
    pdf.add_page()
    
    pdf.set_font("helvetica", "B", 14)
    pdf.cell(0, 10, "Informe de Notas", ln=True, align="C")
    
    pdf.set_font("helvetica", "I", 10)
    tipo = "Reunión de Área" if only_area else "Todas"
    rango = f"Desde: {start_date}   Hasta: {end_date}   |   Filtro: {tipo}"
    pdf.cell(0, 8, rango, ln=True, align="C")
    pdf.ln(5)
    
    if not notes:
        pdf.set_font("helvetica", "", 12)
        pdf.cell(0, 10, "No se encontraron notas en este rango de fechas.", ln=True)
    else:
        for idx, n in enumerate(notes, 1):
            pdf.set_font("helvetica", "B", 12)
            pdf.set_fill_color(240, 240, 240)
            area_str = " [Reunión de Área]" if n.get('is_area_meeting') else ""
            
            # Fecha formateada (viene en YYYY-MM-DD HH:MM:SS)
            date_str = n['created_date'][:10]
            if '-' in date_str:
                parts = date_str.split('-')
                if len(parts) == 3:
                    date_str = f"{parts[2]}-{parts[1]}-{parts[0]}"
            
            header_txt = f"{idx}. {n['title']} ({date_str}){area_str}"
            pdf.cell(0, 8, header_txt, ln=True, fill=True)
            
            pdf.set_font("helvetica", "", 10)
            pdf.multi_cell(0, 5, n.get('content', ''))
            pdf.ln(5)
            
    pdf.output(output_path)
    return True
