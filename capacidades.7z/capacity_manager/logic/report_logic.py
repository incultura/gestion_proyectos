"""
logic/report_logic.py — Lógica de agregación y generación de PDFs para informes.
"""
import os
from datetime import date
from fpdf import FPDF
from db.models.teams import get_all_teams, team_total_annual_hours, get_team
from db.models.project_teams import get_all_active_dedications, get_imputed_hours
from db.models.projects import get_project
from logic.capacity_engine import available_hours_for_month, _distribute_hours_linear, _working_days_year
from utils.date_utils import db_to_gui

class ReportPDF(FPDF):
    def header(self):
        self.set_font("helvetica", "B", 15)
        self.cell(0, 10, "Informe de Capacidad de Equipos", border=False, ln=True, align="C")
        self.ln(5)

    def footer(self):
        self.set_y(-15)
        self.set_font("helvetica", "I", 8)
        self.cell(0, 10, f"Pagina {self.page_no()}/{{nb}}", align="C")

def get_team_report_data(team_id: int, year: int):
    team = get_team(team_id)
    if not team:
        return None

    # 1. Resumen de recursos
    total_hours = team_total_annual_hours(team)
    ops_hours = total_hours * (team.get("ops_percentage", 0) / 100.0)
    non_ops_hours = total_hours - ops_hours

    # 2. Distribución mensual
    monthly_dist = []
    for m in range(1, 13):
        avail = available_hours_for_month(team, year, m)
        monthly_dist.append({
            "month": m,
            "total": avail["total_hours"],
            "ops": avail["ops_hours"],
            "non_ops": avail["non_ops_hours"],
            "days": avail["effective_working_days"]
        })

    # 3. Proyectos Activos (Filtros: fin > hoy, o sin fin, o horas restantes > 0)
    all_deds = get_all_active_dedications()
    team_deds = [d for d in all_deds if d["team_id"] == team_id]
    
    today_str = date.today().isoformat()
    active_projects = []
    for ded in team_deds:
        remaining = max(0.0, ded["estimated_hours"] - get_imputed_hours(ded["id"]))
        is_active = False
        if not ded["end_date"]:
            is_active = True
        elif ded["end_date"] >= today_str:
            is_active = True
        elif remaining > 0:
            is_active = True
        
        if is_active:
            active_projects.append({
                "id": ded["id"],
                "project_title": ded.get("title", f"Project {ded['project_id']}"),
                "start": ded["start_date"],
                "end": ded["end_date"],
                "estimated": ded["estimated_hours"],
                "remaining": remaining,
                "status": ded.get("status_name", "Idea")
            })

    # 4. Timeline de carga (desde mes actual)
    current_month = date.today().month
    timeline = []
    for m in range(current_month, 13):
        avail = available_hours_for_month(team, year, m)
        month_deds = []
        for ded in team_deds:
            h = _distribute_hours_linear(ded, year, m)
            if h > 0:
                month_deds.append({
                    "title": ded.get("title", f"P{ded['project_id']}"),
                    "hours": h
                })
        timeline.append({
            "month": m,
            "available_non_ops": avail["non_ops_hours"],
            "projects": month_deds,
            "total_assigned": sum(p["hours"] for p in month_deds)
        })

    return {
        "team": team,
        "summary": {
            "total_hours": total_hours,
            "ops_hours": ops_hours,
            "non_ops_hours": non_ops_hours
        },
        "monthly_dist": monthly_dist,
        "active_projects": active_projects,
        "timeline": timeline
    }

def generate_team_pdf(team_id: int, year: int, output_path: str):
    data = get_team_report_data(team_id, year)
    if not data:
        return False

    pdf = ReportPDF()
    pdf.add_page()
    
    # Equipo
    pdf.set_font("helvetica", "B", 12)
    pdf.cell(0, 10, f"Equipo: {data['team']['name']}", ln=True)
    pdf.set_font("helvetica", "", 10)
    pdf.ln(2)

    # 1. Recursos
    pdf.set_font("helvetica", "B", 10)
    pdf.cell(0, 8, "1. RESUMEN DE RECURSOS", ln=True, fill=False)
    pdf.set_font("helvetica", "", 9)
    t = data['team']
    res_text = (f"Internos: {t['internal_people']} ({t['internal_annual_hours']}h) | "
                f"L. Base: {t['baseline_people']} ({t['baseline_annual_hours']}h) | "
                f"Refuerzo: {t['reinforce_people']} ({t['reinforce_annual_hours']}h)")
    pdf.cell(0, 6, res_text, ln=True)
    pdf.cell(0, 6, f"Total Horas Anuales: {data['summary']['total_hours']:.1f}h", ln=True)
    pdf.cell(0, 6, f"Operacion ({t['ops_percentage']}%): {data['summary']['ops_hours']:.1f}h", ln=True)
    pdf.cell(0, 6, f"Proyectos (Resto): {data['summary']['non_ops_hours']:.1f}h", ln=True)
    pdf.ln(5)

    # 2. Distribución mensual
    pdf.set_font("helvetica", "B", 10)
    pdf.cell(0, 8, "2. DISPONIBILIDAD MENSUAL (H)", ln=True)
    pdf.set_font("helvetica", "B", 8)
    pdf.cell(20, 6, "Mes", border=1)
    pdf.cell(30, 6, "Total", border=1)
    pdf.cell(30, 6, "Operacion", border=1)
    pdf.cell(30, 6, "Proyectos", border=1)
    pdf.cell(30, 6, "Dias Ef.", border=1, ln=True)
    
    pdf.set_font("helvetica", "", 8)
    for m in data['monthly_dist']:
        pdf.cell(20, 6, str(m['month']), border=1)
        pdf.cell(30, 6, f"{m['total']:.1f}", border=1)
        pdf.cell(30, 6, f"{m['ops']:.1f}", border=1)
        pdf.cell(30, 6, f"{m['non_ops']:.1f}", border=1)
        pdf.cell(30, 6, f"{m['days']:.1f}", border=1, ln=True)
    pdf.ln(5)

    # 3. Proyectos Activos
    pdf.set_font("helvetica", "B", 10)
    pdf.cell(0, 8, "3. PROYECTOS ACTIVOS Y CARGA PENDIENTE", ln=True)
    pdf.set_font("helvetica", "B", 8)
    pdf.cell(60, 6, "Proyecto", border=1)
    pdf.cell(25, 6, "Fin", border=1)
    pdf.cell(25, 6, "Est. (h)", border=1)
    pdf.cell(25, 6, "Pend. (h)", border=1)
    pdf.cell(30, 6, "Estado", border=1, ln=True)

    pdf.set_font("helvetica", "", 7)
    for p in data['active_projects']:
        pdf.cell(60, 6, p['project_title'][:35], border=1)
        pdf.cell(25, 6, db_to_gui(p['end']) if p['end'] else "-", border=1)
        pdf.cell(25, 6, f"{p['estimated']:.1f}", border=1)
        pdf.cell(25, 6, f"{p['remaining']:.1f}", border=1)
        pdf.cell(30, 6, p['status'], border=1, ln=True)
    pdf.ln(5)

    pdf.set_font("helvetica", "B", 10)
    pdf.cell(0, 8, "4. TIMELINE DE CARGA (PROYECTOS)", ln=True)
    for m in data['timeline']:
        pdf.set_font("helvetica", "B", 9)
        pdf.cell(0, 6, f"Mes {m['month']} - Disp. Proyectos: {m['available_non_ops']:.1f}h", ln=True)
        pdf.set_font("helvetica", "", 8)
        if not m['projects']:
            pdf.cell(0, 5, "   (Sin proyectos asignados)", ln=True)
        else:
            for p in m['projects']:
                pdf.cell(0, 5, f"   - {p['title']}: {p['hours']:.1f}h", ln=True)
        load = (m['total_assigned'] / m['available_non_ops'] * 100) if m['available_non_ops'] > 0 else 0
        pdf.set_font("helvetica", "I", 8)
        pdf.cell(0, 5, f"   Carga Total: {m['total_assigned']:.1f}h ({load:.1f}%)", ln=True)
        pdf.ln(2)

    pdf.output(output_path)
    return True

def generate_global_pdf(year: int, output_path: str):
    teams = get_all_teams()
    pdf = ReportPDF()
    pdf.add_page()
    
    pdf.set_font("helvetica", "B", 14)
    pdf.cell(0, 10, f"Resumen Global de Capacidad - Año {year}", ln=True, align="C")
    pdf.ln(5)

    for team in teams:
        data = get_team_report_data(team['id'], year)
        if not data: continue
        
        pdf.set_font("helvetica", "B", 12)
        pdf.set_fill_color(240, 240, 240)
        pdf.cell(0, 8, f"EQUIPO: {team['name']}", ln=True, fill=True)
        pdf.ln(2)

        # 1. Recursos (Resumen)
        pdf.set_font("helvetica", "B", 9)
        pdf.cell(0, 5, "Resumen de Recursos:", ln=True)
        pdf.set_font("helvetica", "", 9)
        t = data['team']
        res_text = (f"Internos: {t['internal_people']} ({t['internal_annual_hours']}h) | "
                    f"L. Base: {t['baseline_people']} ({t['baseline_annual_hours']}h) | "
                    f"Refuerzo: {t['reinforce_people']} ({t['reinforce_annual_hours']}h)")
        pdf.cell(0, 5, res_text, ln=True)
        pdf.cell(0, 5, f"Disp. Proyectos (Año): {data['summary']['non_ops_hours']:.1f}h", ln=True)

        # 2. Carga media
        current_month = date.today().month
        avg_load = 0
        months_count = 0
        for m in data['timeline']:
            if m['available_non_ops'] > 0:
                avg_load += (m['total_assigned'] / m['available_non_ops'] * 100)
                months_count += 1
        
        if months_count > 0:
            avg_load /= months_count
            pdf.set_font("helvetica", "B", 9)
            pdf.cell(0, 5, f"Carga Media proyectada: {avg_load:.1f}%", ln=True)
        
        pdf.ln(2)

        # 3. Proyectos Activos
        pdf.set_font("helvetica", "B", 9)
        pdf.cell(0, 5, f"Proyectos en curso / pendientes ({len(data['active_projects'])}):", ln=True)
        if not data['active_projects']:
            pdf.set_font("helvetica", "I", 8)
            pdf.cell(0, 5, "   (Sin proyectos activos)", ln=True)
        else:
            pdf.set_font("helvetica", "", 8)
            # Cabecera mini-tabla
            pdf.cell(80, 5, "   Proyecto", border="B")
            pdf.cell(30, 5, "Fin", border="B")
            pdf.cell(30, 5, "Pendiente (h)", border="B")
            pdf.cell(40, 5, "Estado", border="B", ln=True)
            
            for p in data['active_projects']:
                pdf.cell(80, 5, f"   {p['project_title'][:45]}", border="B")
                pdf.cell(30, 5, db_to_gui(p['end']) if p['end'] else "-", border="B")
                pdf.cell(30, 5, f"{p['remaining']:.1f}", border="B")
                pdf.cell(40, 5, p['status'], border="B", ln=True)
        
        pdf.ln(8)
        
        # Salto de página si queda poco espacio
        if pdf.get_y() > 250:
            pdf.add_page()
        
    pdf.output(output_path)
    return True
