"""
logic/report_logic.py — Lógica de agregación y generación de PDFs para informes.
"""
import os
import re
from datetime import date
from fpdf import FPDF
from db.models.teams import get_all_teams, team_total_annual_hours, get_team
from db.models.projects import get_projects_by_solicitud, get_project
from db.models.dedications import get_all_active_dedications, get_imputed_hours, get_dedication
from db.models.solicitudes import get_all_solicitudes, get_solicitud, TYPOLOGIES
from db.models.hours_log import get_last_imputation_date, get_team_month_imputed, get_logs_by_dedication
from db.models.annotations import get_annotations_by_solicitud
from db.models.dependencies import get_project_dependencies
from db.models.deliverables import get_deliverables_by_solicitud
from db.models.config import get_config
from db.models.notes import get_notes_for_report
from db.models.capacity_snapshots import get_team_month_planned, has_snapshot
from logic.capacity_engine import available_hours_for_month, _distribute_hours_linear, compute_team_month_load
from utils.date_utils import db_to_gui

class ReportPDF(FPDF):
    def header(self):
        self.set_font("helvetica", "B", 15)
        self.cell(0, 10, "Informe de Capacidad de Equipos", border=False, ln=True, align="C")
        self.ln(5)

    def footer(self):
        self.set_y(-15)
        self.set_font("helvetica", "I", 8)
        self.cell(0, 10, f"Pagina {self.page_no()}/{{nb}}", align="C")

    def write_with_links(self, text, height=5):
        """Dectecta URLs y las escribe como enlaces clicables."""
        url_pattern = r'(https?://[^\s,]+|www\.[^\s,]+)'
        parts = re.split(url_pattern, text)
        
        for part in parts:
            if re.match(url_pattern, part):
                url = part if part.startswith("http") else f"http://{part}"
                self.set_text_color(0, 0, 255)
                self.set_font(style="U")
                self.write(height, part, link=url)
                self.set_text_color(0, 0, 0)
                self.set_font(style="")
            else:
                self.write(height, part)

def get_team_report_data(team_id: int, year: int):
    team = get_team(team_id)
    if not team: return None

    total_hours = team_total_annual_hours(team)
    ops_hours = total_hours * (team.get("ops_percentage", 0) / 100.0)
    non_ops_hours = total_hours - ops_hours

    monthly_dist = []
    for m in range(1, 13):
        avail = available_hours_for_month(team, year, m)
        monthly_dist.append({
            "month": m, "total": avail["total_hours"], "ops": avail["ops_hours"],
            "non_ops": avail["non_ops_hours"], "days": avail.get("effective_working_days", 0)
        })

    active_deds = get_all_active_dedications()
    team_deds = [d for d in active_deds if d["team_id"] == team_id]
    
    today_str = date.today().isoformat()
    report_active_deds = []
    for ded in team_deds:
        imputed = get_imputed_hours(ded["id"])
        remaining = max(0.0, ded["estimated_hours"] - imputed)
        is_active = (not ded["end_date"]) or (ded["end_date"] >= today_str) or (remaining > 0)
        
        if is_active:
            report_active_deds.append({
                "id": ded["id"],
                "project_title": ded.get("project_title", ""),
                "id_proyecto": ded.get("id_proyecto", 0),
                "start": ded["start_date"],
                "end": ded["end_date"],
                "estimated": ded["estimated_hours"],
                "remaining": remaining,
                "status_name": ded.get("status_name", "Idea"),
                "typology": ded.get("typology", "P"),
                "entregable": ded.get("entregable", "")
            })

    current_month = date.today().month
    timeline = []
    for m in range(current_month, 13):
        avail = available_hours_for_month(team, year, m)
        month_non_ops = []
        month_ops = []
        for ded in team_deds:
            result = _distribute_hours_linear(ded, year, m)
            h = result["hours"]
            if h <= 0: continue
            
            title = ded['project_title']
            if (ded.get("typology") or "").upper() == "PIPE" and ded.get("entregable"):
                title = ded["entregable"]
            p_title = f"#{ded['id_proyecto']} {title}"
            p_data = {"title": p_title, "hours": h, "typology": (ded.get("typology") or "").lower()}
            
            if p_data["typology"] == "operacion": month_ops.append(p_data)
            else: month_non_ops.append(p_data)
                
        timeline.append({
            "month": m,
            "available_non_ops": avail["non_ops_hours"],
            "available_ops": avail["ops_hours"],
            "projects": month_non_ops,
            "ops_projects": month_ops,
            "total_assigned": sum(p["hours"] for p in month_non_ops),
            "total_ops_assigned": sum(p["hours"] for p in month_ops)
        })

    return {
        "team": team, "summary": {"total_hours": total_hours, "ops_hours": ops_hours, "non_ops_hours": non_ops_hours},
        "monthly_dist": monthly_dist, "active_projects": report_active_deds, "timeline": timeline
    }

def generate_team_pdf(team_id: int, year: int, output_path: str):
    data = get_team_report_data(team_id, year)
    if not data: return False

    pdf = ReportPDF()
    pdf.add_page()
    
    pdf.set_font("helvetica", "B", 12)
    pdf.cell(0, 10, f"Equipo: {data['team']['name']}", ln=True)
    pdf.set_font("helvetica", "", 10)
    pdf.ln(2)

    pdf.set_font("helvetica", "B", 10)
    pdf.cell(0, 8, "1. RESUMEN DE RECURSOS", ln=True, fill=False)
    pdf.set_font("helvetica", "", 9)
    t = data['team']
    res_text = (f"Internos: {t['internal_people']} ({t['internal_annual_hours']}h) | "
                f"L. Base: {t['baseline_people']} ({t['baseline_annual_hours']}h) | "
                f"Refuerzo: {t['reinforce_people']} ({t['reinforce_annual_hours']}h)")
    pdf.cell(0, 6, res_text, ln=True)
    pdf.cell(0, 6, f"Total Horas Anuales: {data['summary']['total_hours']:.1f}h", ln=True)
    pdf.cell(0, 6, f"Operacion ({t['ops_percentage']}%): {data['summary']['ops_hours']:.1f}h", ln=True)
    pdf.cell(0, 6, f"Proyectos (Resto): {data['summary']['non_ops_hours']:.1f}h", ln=True)
    pdf.ln(5)

    pdf.set_font("helvetica", "B", 10)
    pdf.cell(0, 8, "2. DISPONIBILIDAD MENSUAL (H)", ln=True)
    pdf.set_font("helvetica", "B", 8)
    pdf.cell(20, 6, "Mes", border=1)
    pdf.cell(30, 6, "Total", border=1)
    pdf.cell(30, 6, "Operacion", border=1)
    pdf.cell(30, 6, "Proyectos", border=1)
    pdf.cell(30, 6, "Dias Ef.", border=1, ln=True)
    
    pdf.set_font("helvetica", "", 8)
    for m in data['monthly_dist']:
        pdf.cell(20, 6, str(m['month']), border=1)
        pdf.cell(30, 6, f"{m['total']:.1f}", border=1)
        pdf.cell(30, 6, f"{m['ops']:.1f}", border=1)
        pdf.cell(30, 6, f"{m['non_ops']:.1f}", border=1)
        pdf.cell(30, 6, f"{m['days']:.1f}", border=1, ln=True)
    pdf.ln(5)

    pdf.set_font("helvetica", "B", 10)
    pdf.cell(0, 8, "3. PROYECTOS ACTIVOS Y CARGA PENDIENTE", ln=True)
    pdf.set_font("helvetica", "B", 8)
    pdf.cell(60, 6, "Proyecto", border=1)
    pdf.cell(20, 6, "Tipo", border=1)
    pdf.cell(25, 6, "Fin", border=1)
    pdf.cell(20, 6, "Est. (h)", border=1)
    pdf.cell(20, 6, "Pend. (h)", border=1)
    pdf.cell(25, 6, "Estado", border=1, ln=True)

    pdf.set_font("helvetica", "", 7)
    for p in data['active_projects']:
        title = p['project_title']
        if p.get('typology') == "PIPE" and p.get('entregable'):
            title = p['entregable']
        if p.get('id_proyecto', 0) > 0: 
            title = f"#{p['id_proyecto']} {title}"
        pdf.cell(60, 6, title[:35], border=1)
        pdf.cell(20, 6, p['typology'], border=1)
        pdf.cell(25, 6, db_to_gui(p['end']) if p['end'] else "-", border=1)
        pdf.cell(20, 6, f"{p['estimated']:.1f}", border=1)
        pdf.cell(20, 6, f"{p['remaining']:.1f}", border=1)
        pdf.cell(25, 6, p['status_name'], border=1, ln=True)
    pdf.ln(5)

    pdf.set_font("helvetica", "B", 10)
    pdf.cell(0, 8, "4. TIMELINE DE CARGA (PROYECTOS)", ln=True)
    for m in data['timeline']:
        pdf.set_font("helvetica", "B", 9)
        pdf.cell(0, 6, f"Mes {m['month']} - Disp. Proyectos: {m['available_non_ops']:.1f}h", ln=True)
        pdf.set_font("helvetica", "", 8)
        
        if not m['projects']:
            pdf.cell(0, 5, "   (Sin proyectos asignados)", ln=True)
        else:
            for p in m['projects']:
                pdf.set_x(15) 
                pdf.write_with_links(f"- {p['title']}: {p['hours']:.1f}h")
                pdf.ln(5)
        
        load_projects = (m['total_assigned'] / m['available_non_ops'] * 100) if m['available_non_ops'] > 0 else 0
        pdf.set_font("helvetica", "I", 8)
        pdf.cell(0, 5, f"   Carga Proyectos: {m['total_assigned']:.1f}h ({load_projects:.1f}%)", ln=True)
        
        if m['ops_projects']:
            pdf.ln(1)
            pdf.set_font("helvetica", "B", 8)
            pdf.cell(0, 5, f"   Proyectos de Operación Adicionales (Disp: {m['available_ops']:.1f}h):", ln=True)
            pdf.set_font("helvetica", "", 7)
            for p in m['ops_projects']:
                pdf.set_x(20)
                pdf.cell(0, 4, f"* {p['title']}: {p['hours']:.1f}h", ln=True)
            load_ops = (m['total_ops_assigned'] / m['available_ops'] * 100) if m['available_ops'] > 0 else 0
            pdf.set_font("helvetica", "I", 7)
            pdf.cell(0, 4, f"   Carga Extra Operación: {m['total_ops_assigned']:.1f}h ({load_ops:.1f}%)", ln=True)
            
        pdf.ln(2)

    pdf.output(output_path)
    return True

def generate_global_pdf(year: int, output_path: str):
    teams = get_all_teams()
    pdf = ReportPDF()
    pdf.add_page()
    
    pdf.set_font("helvetica", "B", 14)
    pdf.cell(0, 10, f"Resumen Global de Capacidad - Año {year}", ln=True, align="C")
    pdf.ln(5)

    for team in teams:
        data = get_team_report_data(team['id'], year)
        if not data: continue
        
        pdf.set_font("helvetica", "B", 12)
        pdf.set_fill_color(240, 240, 240)
        pdf.cell(0, 8, f"EQUIPO: {team['name']}", ln=True, fill=True)
        pdf.ln(2)

        pdf.set_font("helvetica", "B", 9)
        pdf.cell(0, 5, "Resumen de Recursos:", ln=True)
        pdf.set_font("helvetica", "", 9)
        t = data['team']
        res_text = (f"Internos: {t['internal_people']} ({t['internal_annual_hours']}h) | "
                    f"L. Base: {t['baseline_people']} ({t['baseline_annual_hours']}h) | "
                    f"Refuerzo: {t['reinforce_people']} ({t['reinforce_annual_hours']}h)")
        pdf.cell(0, 5, res_text, ln=True)
        pdf.cell(0, 5, f"Disp. Proyectos (Año): {data['summary']['non_ops_hours']:.1f}h", ln=True)

        current_month = date.today().month
        avg_load = 0
        months_count = 0
        for m in data['timeline']:
            if m['available_non_ops'] > 0:
                avg_load += (m['total_assigned'] / m['available_non_ops'] * 100)
                months_count += 1
        
        if months_count > 0:
            avg_load /= months_count
            pdf.set_font("helvetica", "B", 9)
            pdf.cell(0, 5, f"Carga Media proyectada: {avg_load:.1f}%", ln=True)
        
        pdf.ln(2)

        pdf.set_font("helvetica", "B", 9)
        pdf.cell(0, 5, f"Proyectos en curso / pendientes ({len(data['active_projects'])}):", ln=True)
        if not data['active_projects']:
            pdf.set_font("helvetica", "I", 8)
            pdf.cell(0, 5, "   (Sin proyectos activos)", ln=True)
        else:
            pdf.set_font("helvetica", "", 8)
            pdf.set_x(15)
            pdf.cell(85, 5, "Proyecto", border="B")
            pdf.cell(20, 5, "Tipo", border="B")
            pdf.cell(25, 5, "Fin", border="B")
            pdf.cell(25, 5, "Pendiente", border="B")
            pdf.cell(30, 5, "Estado", border="B", ln=True)
            
            for p in data['active_projects']:
                start_y = pdf.get_y()
                pdf.set_x(15)
                
                title_text = p['project_title']
                if p['id_proyecto'] > 0: title_text = f"#{p['id_proyecto']} {title_text}"
                title_text = title_text[:48]
                pdf.write_with_links(title_text)
                
                pdf.set_xy(100, start_y)
                pdf.cell(20, 5, p['typology'], border="B")
                pdf.cell(25, 5, db_to_gui(p['end']) if p['end'] else "-", border="B")
                pdf.cell(25, 5, f"{p['remaining']:.1f}", border="B")
                pdf.cell(30, 5, p['status_name'], border="B", ln=True)
                
                pdf.line(15, start_y + 5, 100, start_y + 5)
        
        pdf.ln(8)
        
        if pdf.get_y() > 250:
            pdf.add_page()
        
    pdf.output(output_path)
    return True

def get_solicitud_report_data(solicitud_id: int):
    sol = get_solicitud(solicitud_id)
    if not sol: return None
    
    from db.models.dedications import get_dedications_by_project
    projs = get_projects_by_solicitud(solicitud_id)
    
    hierarchy_data = []
    all_deds = []
    for p in projs:
        p_deds = get_dedications_by_project(p["id"])
        p_data = {
            "id": p["id"], "id_proyecto": p["id_proyecto"], "title": p["title"],
            "description": p["description"], "entregable": p["entregable"],
            "dependencies": get_project_dependencies(p["id"]),
            "dedications": []
        }
        for d in p_deds:
            d["id_proyecto"] = p["id_proyecto"] # Enriquecer con ID de proyecto para el timeline
            d_info = {
                "id": d["id"], "team_name": d["team_name"], "status_name": d["status_name"],
                "start": d["start_date"], "end": d["end_date"], "estimated": d["estimated_hours"],
                "imputed": get_imputed_hours(d["id"]),
                "remaining": max(0, d["estimated_hours"] - get_imputed_hours(d["id"])),
                "last_activity": get_last_imputation_date(d["id"])
            }
            p_data["dedications"].append(d_info)
            all_deds.append(d)
        hierarchy_data.append(p_data)

    current_date = date.today()
    current_year, current_month = current_date.year, current_date.month
    
    future_timeline = []
    y, m = current_year, current_month
    for _ in range(24):
        month_data = {"year": y, "month": m, "teams": []}
        for d in all_deds:
            res = _distribute_hours_linear(d, y, m)
            if res["hours"] > 0:
                p_label = f" (P#{d['id_proyecto']})" if d.get('id_proyecto', 0) > 0 else ""
                month_data["teams"].append({"name": f"{d['team_name']}{p_label}", "hours": res["hours"]})
        if month_data["teams"]:
            future_timeline.append(month_data)
        m += 1
        if m > 12: m = 1; y += 1

    annots = get_annotations_by_solicitud(solicitud_id)
    sorted_annots = sorted(annots, key=lambda x: (x['date'], x['annotation_number']), reverse=True)
    
    return {
        "solicitud": sol, "hierarchy": hierarchy_data, "timeline": future_timeline,
        "annotations": sorted_annots,
        "deliverables": get_deliverables_by_solicitud(solicitud_id) if sol["typology"] == "PIPE" else []
    }

def generate_solicitud_pdf(solicitud_id: int, output_path: str):
    data = get_solicitud_report_data(solicitud_id)
    if not data: return False
    
    s = data['solicitud']
    pdf = ReportPDF()
    pdf.add_page()
    pdf.set_font("helvetica", "B", 16)
    pdf.cell(0, 10, f"Solicitud: {s['title']}", ln=True)
    pdf.set_font("helvetica", "B", 12)
    pdf.cell(0, 8, f"Tipología: {s['typology']}  |  Estado: {s['status_name']}", ln=True)
    pdf.ln(2)
    
    if s['id_solicitud'] > 0:
        base_url = get_config("base_url_solicitud", "").strip()
        link = base_url + str(s['id_solicitud']) if base_url else str(s['id_solicitud'])
        pdf.set_font("helvetica", "B", 10)
        pdf.cell(30, 6, "ID Solicitud: ", ln=False)
        pdf.set_font("helvetica", "", 10)
        pdf.write_with_links(link)
        pdf.ln(10)
    
    pdf.set_font("helvetica", "B", 10)
    pdf.cell(0, 6, "Descripción:", ln=True)
    pdf.set_font("helvetica", "", 10)
    pdf.write_with_links(s['description'] if s['description'] else "(Sin descripción)")
    pdf.ln(8)
    
    pdf.set_font("helvetica", "B", 10)
    pdf.cell(0, 6, "Calendario Mensual Proyectado (Próximos 24 meses):", ln=True)
    pdf.ln(2)
    
    pdf.set_font("helvetica", "B", 12)
    pdf.cell(0, 10, "Proyectos y Dedicaciones", ln=True)
    
    for p in data['hierarchy']:
        pdf.set_font("helvetica", "B", 10)
        pdf.set_fill_color(245, 245, 245)
        
        id_val = p.get('id_proyecto', 0)
        title_text = p['title']
        if id_val > 0:
            header_txt = f"PROYECTO #{id_val}: {title_text}"
            base_url = get_config("base_url_solicitud", "").strip()
            p_link = (base_url + str(id_val)) if base_url else ""
            pdf.cell(0, 8, header_txt, ln=True, fill=True, link=p_link)
        else:
            pdf.cell(0, 8, f"PROYECTO: {title_text}", ln=True, fill=True)

        if p.get('description'):
            pdf.set_font("helvetica", "", 9)
            pdf.write_with_links(f"   {p['description']}")
            pdf.ln(5)

        if p['entregable']:
            pdf.set_font("helvetica", "I", 9)
            pdf.cell(0, 6, f"   Entregable: {p['entregable']}", ln=True)
        
        if p['dependencies']:
            pdf.set_font("helvetica", "I", 9)
            deps_str = "Dependencias: " + ", ".join([d["name"] for d in p['dependencies']])
            pdf.multi_cell(0, 6, f"   {deps_str}")
        
        pdf.set_font("helvetica", "B", 8)
        cols = [("Equipo", 40), ("Estado", 25), ("Inicio", 20), ("Fin", 20), ("Est.", 15), ("Imp.", 15), ("Rest.", 15), ("Últ. Act.", 25)]
        for col, w in cols:
            pdf.cell(w, 7, col, border=1, align="C")
        pdf.ln()
        
        pdf.set_font("helvetica", "", 8)
        for d in p['dedications']:
            pdf.cell(40, 6, d['team_name'][:25], border=1)
            pdf.cell(25, 6, d['status_name'], border=1, align="C")
            pdf.cell(20, 6, db_to_gui(d['start']), border=1, align="C")
            pdf.cell(20, 6, db_to_gui(d['end']), border=1, align="C")
            pdf.cell(15, 6, f"{d['estimated']:.0f}h", border=1, align="R")
            pdf.cell(15, 6, f"{d['imputed']:.0f}h", border=1, align="R")
            pdf.cell(15, 6, f"{d['remaining']:.0f}h", border=1, align="R")
            pdf.cell(25, 6, db_to_gui(d['last_activity']), border=1, align="C")
            pdf.ln()
        pdf.ln(3)
    pdf.ln(5)
    
    if data['timeline']:
        pdf.set_font("helvetica", "B", 12)
        pdf.cell(0, 10, "Previsión de Carga Mensual (Horas)", ln=True)
        pdf.set_font("helvetica", "B", 9)
        pdf.cell(40, 7, "Mes", border=1, fill=True, align="C")
        pdf.cell(150, 7, "Distribución por Proyecto (Equipo)", border=1, fill=True, align="C")
        pdf.ln()
        
        pdf.set_font("helvetica", "", 8)
        for m in data['timeline']:
            pdf.cell(40, 7, f"{m['month']}/{m['year']}", border=1, align="C")
            teams_str = ", ".join([f"{t['name']}: {t['hours']:.1f}h" for t in m['teams']])
            pdf.cell(150, 7, teams_str, border=1)
            pdf.ln()
        pdf.ln(5)
        

    if data.get('deliverables'):
        pdf.set_font("helvetica", "B", 12)
        pdf.cell(0, 10, "Maestro de Entregables (PIPE)", ln=True)
        pdf.set_font("helvetica", "", 10)
        for d in data['deliverables']:
            pdf.cell(0, 6, f"- {d['name']}", ln=True)
        pdf.ln(5)

    if data['annotations']:
        pdf.set_font("helvetica", "B", 12)
        pdf.cell(0, 10, "Histórico de Anotaciones", ln=True)
        for a in data['annotations']:
            pdf.set_font("helvetica", "B", 9)
            pdf.cell(0, 6, f"Nota #{a['annotation_number']} - {db_to_gui(a['date'])}", ln=True, fill=True)
            pdf.set_font("helvetica", "", 9)
            pdf.multi_cell(0, 5, a['content'])
            pdf.ln(2)
            
    pdf.output(output_path)
    return True

def get_project_report_data(project_id: int):
    p = get_project(project_id)
    if not p: return None
    
    from db.models.dedications import get_dedications_by_project
    p_deds = get_dedications_by_project(project_id)
    
    p["dedication_details"] = []
    for d in p_deds:
        d_info = {
            "id": d["id"], "team_name": d["team_name"], "status_name": d["status_name"],
            "start": d["start_date"], "end": d["end_date"], "estimated": d["estimated_hours"],
            "imputed": get_imputed_hours(d["id"]),
            "remaining": max(0, d["estimated_hours"] - get_imputed_hours(d["id"])),
            "last_activity": get_last_imputation_date(d["id"])
        }
        p["dedication_details"].append(d_info)
    
    current_date = date.today()
    y, m = current_date.year, current_date.month
    future_timeline = []
    for _ in range(24):
        month_data = {"year": y, "month": m, "teams": []}
        for d in p_deds:
            res = _distribute_hours_linear(d, y, m)
            if res["hours"] > 0:
                month_data["teams"].append({"name": d["team_name"], "hours": res["hours"]})
        if month_data["teams"]:
            future_timeline.append(month_data)
        m += 1
        if m > 12: m = 1; y += 1

    return {
        "project": p,
        "timeline": future_timeline,
        "dependencies": get_project_dependencies(project_id)
    }

def generate_project_pdf(project_id: int, output_path: str):
    data = get_project_report_data(project_id)
    if not data: return False
    
    p = data['project']
    pdf = ReportPDF()
    pdf.add_page()
    
    # Proyecto
    pdf.set_font("helvetica", "B", 16)
    id_pry = p.get('id_proyecto', 0)
    if id_pry > 0:
        header_p = f"Proyecto #{id_pry}: {p['title']}"
        base_url = get_config("base_url_solicitud", "").strip()
        p_link = (base_url + str(id_pry)) if base_url else ""
        pdf.cell(0, 10, header_p, ln=True, link=p_link)
    else:
        pdf.cell(0, 10, f"Proyecto: {p['title']}", ln=True)

    # Solicitud Relacionada
    pdf.set_font("helvetica", "B", 11)
    pdf.set_text_color(100, 100, 100)
    sol_title = p.get('solicitud_title', 'N/A')
    sol_id = p.get('id_solicitud', 0)
    
    if sol_id > 0:
        base_url = get_config("base_url_solicitud", "").strip()
        s_link = (base_url + str(sol_id)) if base_url else ""
        pdf.cell(0, 8, f"Solicitud Asociada: #{sol_id} - {sol_title}", ln=True, link=s_link)
    else:
        pdf.cell(0, 8, f"Solicitud Asociada: {sol_title}", ln=True)
    
    pdf.set_text_color(0, 0, 0)
    pdf.ln(5)
    
    # Descripción
    pdf.set_font("helvetica", "B", 10)
    pdf.cell(0, 6, "Descripción del Proyecto:", ln=True)
    pdf.set_font("helvetica", "", 10)
    pdf.write_with_links(p['description'] if p['description'] else "(Sin descripción)")
    pdf.ln(8)

    if p['entregable']:
        pdf.set_font("helvetica", "I", 10)
        pdf.cell(0, 6, f"Entregable: {p['entregable']}", ln=True)
        pdf.ln(2)

    if data['dependencies']:
        pdf.set_font("helvetica", "B", 10)
        pdf.cell(0, 6, "Dependencias:", ln=True)
        pdf.set_font("helvetica", "", 10)
        deps_str = ", ".join([d["name"] for d in data['dependencies']])
        pdf.multi_cell(0, 6, deps_str)
        pdf.ln(4)

    # Tabla de Dedicaciones
    pdf.set_font("helvetica", "B", 12)
    pdf.cell(0, 10, "Equipos y Dedicaciones", ln=True)
    
    pdf.set_font("helvetica", "B", 8)
    cols = [("Equipo", 40), ("Estado", 25), ("Inicio", 20), ("Fin", 20), ("Est.", 15), ("Imp.", 15), ("Rest.", 15), ("Últ. Act.", 25)]
    for col, w in cols:
        pdf.cell(w, 7, col, border=1, align="C", fill=True)
    pdf.ln()
    
    pdf.set_font("helvetica", "", 8)
    for d in p['dedication_details']:
        pdf.cell(40, 6, d['team_name'][:25], border=1)
        pdf.cell(25, 6, d['status_name'], border=1, align="C")
        pdf.cell(20, 6, db_to_gui(d['start']), border=1, align="C")
        pdf.cell(20, 6, db_to_gui(d['end']), border=1, align="C")
        pdf.cell(15, 6, f"{d['estimated']:.0f}h", border=1, align="R")
        pdf.cell(15, 6, f"{d['imputed']:.0f}h", border=1, align="R")
        pdf.cell(15, 6, f"{d['remaining']:.0f}h", border=1, align="R")
        pdf.cell(25, 6, db_to_gui(d['last_activity']), border=1, align="C")
        pdf.ln()
    pdf.ln(8)

    # Calendario Proyectado
    if data['timeline']:
        pdf.set_font("helvetica", "B", 12)
        pdf.cell(0, 10, "Previsión de Carga Mensual (Horas)", ln=True)
        pdf.set_font("helvetica", "B", 9)
        pdf.cell(40, 7, "Mes", border=1, fill=True, align="C")
        pdf.cell(150, 7, "Distribución por Equipo", border=1, fill=True, align="C")
        pdf.ln()
        
        pdf.set_font("helvetica", "", 8)
        for m in data['timeline']:
            pdf.cell(40, 7, f"{m['month']}/{m['year']}", border=1, align="C")
            teams_str = ", ".join([f"{t['name']}: {t['hours']:.1f}h" for t in m['teams']])
            pdf.cell(150, 7, teams_str, border=1)
            pdf.ln()

    pdf.output(output_path)
    return True

def get_inconsistent_estimates_data():
    from db.models.dedications import get_dedications_by_project
    all_sols = get_all_solicitudes()
    results = []

    for s in all_sols:
        if s.get('status_name') in ('Finalizado', 'Descartado'): continue
        projs = get_projects_by_solicitud(s['id'])
        if not projs: continue

        all_sol_deds = []
        for p in projs:
            deds = get_dedications_by_project(p['id'])
            all_sol_deds.extend(deds)
        
        if not all_sol_deds: continue

        with_est = []
        without_est = []
        for d in all_sol_deds:
            # Reconstruct title for the report
            proj = next((p for p in projs if p['id'] == d['project_id']), None)
            d_name = f"{d['team_name']}"
            if proj:
                d_name = f"{proj['id_proyecto']} {d_name}"
            
            d_info = {"team_name": d_name, "estimated_hours": d['estimated_hours'], "id_proyecto": proj['id_proyecto'] if proj else 0}
            
            if d['estimated_hours'] > 0:
                with_est.append(d_info)
            else:
                without_est.append(d_info)

        if with_est and without_est:
            results.append({
                "solicitud": s,
                "projs_with": with_est,
                "projs_without": without_est
            })
    return results

def generate_inconsistent_estimates_pdf(output_path: str):
    data = get_inconsistent_estimates_data()
    pdf = ReportPDF()
    pdf.add_page()
    pdf.set_font("helvetica", "B", 14)
    pdf.cell(0, 10, "Informe: Estimaciones Inconsistentes", ln=True, align="C")
    pdf.ln(5)

    if not data:
        pdf.cell(0, 10, "No se encontraron inconsistencias.", ln=True)
    else:
        for item in data:
            s = item['solicitud']
            pdf.set_font("helvetica", "B", 12)
            pdf.set_fill_color(230, 230, 230)
            pdf.cell(0, 8, f"SOLICITUD: {s['title']} ({s['status_name']})", ln=True, fill=True)
            
            pdf.set_font("helvetica", "B", 10)
            pdf.cell(0, 6, "Proyectos con estimación:", ln=True)
            pdf.set_font("helvetica", "", 10)
            for p in item['projs_with']:
                name = p['team_name']
                if p.get('id_proyecto', 0) > 0: name = f"#{p['id_proyecto']} {name}"
                pdf.cell(0, 5, f"   - {name}: {p['estimated_hours']}h", ln=True)

            pdf.set_font("helvetica", "B", 10)
            pdf.cell(0, 6, "Proyectos SIN estimación:", ln=True)
            pdf.set_font("helvetica", "", 10)
            for p in item['projs_without']:
                name = p['team_name']
                if p.get('id_proyecto', 0) > 0: name = f"#{p['id_proyecto']} {name}"
                pdf.cell(0, 5, f"   - {name}", ln=True)
            pdf.ln(5)
    pdf.output(output_path)
    return True

def get_inactive_estimated_projects_data():
    from db.database import get_connection
    conn = get_connection()
    try:
        query = """
            SELECT 
                d.id as dedication_id,
                s.title as solicitud_title,
                t.name as team_name,
                p.id_proyecto,
                d.estimated_hours,
                st.name as status_name,
                (SELECT MAX(hl.log_date) FROM hours_log hl WHERE hl.dedication_id = d.id) as last_imputation
            FROM dedications d
            JOIN projects p ON d.project_id = p.id
            JOIN solicitudes s ON p.solicitud_id = s.id
            JOIN teams t ON d.team_id = t.id
            JOIN statuses st ON d.status_id = st.id
            WHERE d.status_id NOT IN (4, 5, 6)
              AND d.estimated_hours > 0
        """
        rows = conn.execute(query).fetchall()
        
        results = []
        from datetime import datetime, timedelta
        thirty_days_ago = (datetime.now() - timedelta(days=30)).strftime("%Y-%m-%d")
        
        for r in rows:
            last_date = r["last_imputation"]
            if not last_date or last_date < thirty_days_ago:
                results.append(dict(r))
        results.sort(key=lambda x: (x['solicitud_title'], x['team_name']))
        return results
    finally:
        conn.close()

def generate_inactive_estimated_projects_pdf(output_path: str):
    data = get_inactive_estimated_projects_data()
    pdf = ReportPDF()
    pdf.add_page()
    pdf.set_font("helvetica", "B", 14)
    pdf.cell(0, 10, "Informe: Proyectos Inactivos con Estimación", ln=True, align="C")
    pdf.ln(5)

    if not data:
        pdf.cell(0, 10, "No se encontraron proyectos inactivos.", ln=True)
    else:
        current_sol = None
        for item in data:
            if current_sol != item['solicitud_title']:
                current_sol = item['solicitud_title']
                pdf.set_font("helvetica", "B", 12)
                pdf.set_fill_color(240, 240, 240)
                pdf.cell(0, 8, f"SOLICITUD: {current_sol}", ln=True, fill=True)
            
            pdf.set_font("helvetica", "", 10)
            last_imp = db_to_gui(item['last_imputation']) if item['last_imputation'] else "Nunca"
            name = item['team_name']
            if item['id_proyecto'] > 0: name = f"#{item['id_proyecto']} {name}"
            pdf.cell(0, 6, f"  - {name} | Estado: {item['status_name']}", ln=True)
            pdf.cell(0, 6, f"    Estimado: {item['estimated_hours']}h | Última Imp: {last_imp}", ln=True)
    pdf.output(output_path)
    return True

def generate_notes_report_pdf(output_path: str, start_date: str, end_date: str, only_area: bool):
    notes = get_notes_for_report(start_date, end_date, only_area)
    pdf = ReportPDF()
    pdf.add_page()
    pdf.set_font("helvetica", "B", 14)
    pdf.cell(0, 10, "Informe de Notas", ln=True, align="C")
    pdf.ln(5)
    if not notes:
        pdf.cell(0, 10, "No se encontraron notas.", ln=True)
    else:
        for idx, n in enumerate(notes, 1):
            pdf.set_font("helvetica", "B", 12)
            pdf.set_fill_color(240, 240, 240)
            date_str = n['created_date'][:10]
            header_txt = f"{idx}. {n['title']} ({date_str})"
            pdf.cell(0, 8, header_txt, ln=True, fill=True)
            pdf.set_font("helvetica", "", 10)
            pdf.multi_cell(0, 5, n.get('content', ''))
            pdf.ln(5)
    pdf.output(output_path)
    return True

MONTHS_ES = ["Ene", "Feb", "Mar", "Abr", "May", "Jun", "Jul", "Ago", "Sep", "Oct", "Nov", "Dic"]

def get_capacity_deviation_data(year: int) -> list:
    teams = get_all_teams()
    today = date.today()
    results = []
    for team in teams:
        team_data = {"team_id": team["id"], "team_name": team["name"], "months": []}
        for month in range(1, 13):
            is_past = (year < today.year) or (year == today.year and month <= today.month)
            planned = get_team_month_planned(team["id"], year, month)
            actual = get_team_month_imputed(team["id"], year, month)
            p_total = planned["total_hours"]
            a_total = actual["total_hours"]
            deviation = a_total - p_total
            deviation_pct = (deviation / p_total * 100) if p_total > 0 else 0.0
            team_data["months"].append({
                "month": month, "is_past": is_past,
                "planned_total": p_total, "planned_ops": planned["ops_hours"], "planned_non_ops": planned["non_ops_hours"],
                "actual_total": a_total, "actual_ops": actual["ops_hours"], "actual_non_ops": actual["non_ops_hours"],
                "deviation": deviation, "deviation_pct": deviation_pct,
            })
        results.append(team_data)
    return results

def generate_capacity_deviation_pdf(year: int, output_path: str) -> bool:
    data = get_capacity_deviation_data(year)
    pdf = ReportPDF()
    pdf.add_page("L")
    pdf.set_font("helvetica", "B", 14)
    pdf.cell(0, 10, f"Informe de Desviaciones - Año {year}", ln=True, align="C")
    for team_data in data:
        pdf.set_font("helvetica", "B", 11)
        pdf.set_fill_color(220, 220, 220)
        pdf.cell(0, 8, f"EQUIPO: {team_data['team_name']}", ln=True, fill=True)
        pdf.set_font("helvetica", "B", 8)
        pdf.cell(20, 6, "Mes", border=1); pdf.cell(30, 6, "Prev. Total", border=1); pdf.cell(30, 6, "Real Total", border=1); pdf.cell(25, 6, "Desv.", border=1); pdf.cell(25, 6, "%", border=1); pdf.ln()
        pdf.set_font("helvetica", "", 8)
        for m in team_data["months"]:
            if not m["is_past"]: continue
            pdf.cell(20, 5, MONTHS_ES[m["month"]-1], border=1)
            pdf.cell(30, 5, f"{m['planned_total']:.1f}", border=1)
            pdf.cell(30, 5, f"{m['actual_total']:.1f}", border=1)
            pdf.cell(25, 5, f"{m['deviation']:.1f}", border=1)
            pdf.cell(25, 5, f"{m['deviation_pct']:.1f}%", border=1); pdf.ln()
        pdf.ln(5)
    pdf.output(output_path)
    return True

def get_stopped_projects_data() -> list:
    all_deds = get_all_active_dedications()
    stopped = [d for d in all_deds if d.get("status_name") == "Detenido"]
    results = []
    for d in stopped:
        imputed = get_imputed_hours(d["id"])
        remaining = max(0.0, d["estimated_hours"] - imputed)
        title = f"#{d['id_proyecto']} {d['project_title']}"
        results.append({
            "project_title": title,
            "team_name": d.get("team_name", str(d["team_id"])),
            "estimated_hours": d["estimated_hours"],
            "imputed_hours": imputed,
            "remaining_hours": remaining,
            "last_imputation": get_last_imputation_date(d["id"]),
        })
    results.sort(key=lambda x: (x["project_title"], x["team_name"]))
    return results

def generate_stopped_projects_pdf(output_path: str) -> bool:
    data = get_stopped_projects_data()
    pdf = ReportPDF()
    pdf.add_page()
    pdf.set_font("helvetica", "B", 14)
    pdf.cell(0, 10, "Informe: Proyectos Detenidos", ln=True, align="C")
    if not data:
        pdf.cell(0, 10, "No hay proyectos detenidos.", ln=True)
    else:
        pdf.set_font("helvetica", "B", 8)
        pdf.cell(60, 6, "Proyecto", border=1); pdf.cell(40, 6, "Equipo", border=1); pdf.cell(25, 6, "Rest. (h)", border=1); pdf.cell(25, 6, "Últ. Imp.", border=1); pdf.ln()
        pdf.set_font("helvetica", "", 8)
        for item in data:
            pdf.cell(60, 5, item["project_title"][:35], border=1)
            pdf.cell(40, 5, item["team_name"][:20], border=1)
            pdf.cell(25, 5, f"{item['remaining_hours']:.1f}", border=1)
            pdf.cell(25, 5, db_to_gui(item["last_imputation"]), border=1); pdf.ln()
    pdf.output(output_path)
    return True
