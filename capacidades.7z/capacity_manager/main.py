"""
main.py — Punto de entrada de la aplicación.
"""
import sys
import os

# Asegurar que el directorio raíz del proyecto esté en el path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from db.database import initialize_db
from gui.app import App


def main():
    # Inicializar la base de datos (crea las tablas si no existen)
    initialize_db()

    # Lanzar la GUI
    app = App()
    app.mainloop()


if __name__ == "__main__":
    main()
