
import os
import sys
# Añadir el directorio actual al path para importar db
sys.path.append(os.getcwd())
from db.database import get_connection

conn = get_connection()
try:
    rows = conn.execute("SELECT * FROM statuses;").fetchall()
    for r in rows:
        print(f"{r['id']}: {r['name']}")
finally:
    conn.close()
