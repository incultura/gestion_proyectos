import sqlite3
import os

db_path = "capacity.db"
if os.path.exists(db_path):
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    try:
        rows = conn.execute("SELECT * FROM statuses").fetchall()
        for r in rows:
            print(f"{r['id']}: {r['name']}")
    finally:
        conn.close()
else:
    print(f"Error: {db_path} not found")
